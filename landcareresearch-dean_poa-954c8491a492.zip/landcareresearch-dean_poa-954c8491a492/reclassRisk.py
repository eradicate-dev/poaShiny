#!/usr/bin/env python

import sys
import numpy as np
from rios import applier

infiles = applier.FilenameAssociations()
infiles.riskIn = sys.argv[1]

outfiles = applier.FilenameAssociations()
outfiles.newArray = sys.argv[2]

def indxRisk(info, inputs, outputs):
    # empty array to populate
    newRiskArray = np.zeros_like(inputs.riskIn).astype(np.uint8)
    # put into a numpy array and loop thru to reclass risk
    habRisk = np.array([3, 10, 25, 50])
    newRisk = np.array([1, 20, 75, 200])
    for i in range(len(habRisk)):
        # find values in risk == i
        mask_i = np.in1d(inputs.riskIn, habRisk[i]).reshape(np.shape(inputs.riskIn))
        newRiskArray[mask_i] = newRisk[i]
    outputs.newArray = newRiskArray


applier.apply(indxRisk, infiles, outfiles)

##  call on command line:
##  ./reclassRisk.py poa/EAScenario1/EA_data/Risk10m.tif poa/EAScenario1/EA_data/risk234.img


