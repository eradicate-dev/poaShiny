#!/usr/bin/env python

import os
import numpy as np
#from scipy.stats.mstats import mquantiles
#import prettytable
#import pickle
import gdal
import pylab as P

def distFX(x1, y1, x2, y2):
    """
    calc distance matrix between 2 sets of points
    resulting matrix dimensions = (len(x1), len(x2))
    """
    deltaX = np.add.outer(x1, -x2)
    deltaX_sq = deltaX**2
    deltaY = np.add.outer(y1, -y2)
    deltaY_sq = deltaY**2
    dist_2D = np.sqrt(deltaX_sq + deltaY_sq)
    return dist_2D


class Params(object):
    def __init__(self):
        self.nG0 = 1000
        self.g0 = np.linspace(0.01, 0.15, num=self.nG0)
#        self.nLoc = 4 
        self.sigma = 100.0  # 50 acres = 20 ha 
        self.dogG0 = 0.14
        self.personG0 = 0.02  

class ProcessData(object):
    def __init__(self, params, hrFName, surveyFName, plotFName):

        self.params = params
        self.readLocs(hrFName, surveyFName)
        self.loopLocations()
        self.plotDetect(plotFName)
        self.getG0()

    def readLocs(self, hrFName, surveyFName):
        # READ HR LOC
        hrdat = np.genfromtxt(hrFName,  delimiter=',', names=True,
            dtype=['S10', 'f8', 'f8'])
        self.hrX = hrdat['X']
        self.hrY = hrdat['Y']
        # READ SURVEY LOCS
        surveydat = np.genfromtxt(surveyFName,  delimiter=',', names=True,
            dtype=['S10', 'f8', 'f8'])
        self.surveyX = surveydat['X']
        self.surveyY = surveydat['Y']



    def loopLocations(self):
        self.nHR = len(self.hrX)
        self.nSurvey = len(self.surveyX)
        self.detectArray = np.zeros((4, self.params.nG0))
        self.maxDist = 4.0 * self.params.sigma
        for i in range(self.nHR):
            xhri = self.hrX[i]
            yhri = self.hrY[i]
            distij = distFX(xhri, yhri, self.surveyX, self.surveyY)
            maskDist = distij <= self.maxDist
            distij = distij[maskDist]
            # LOOP THRU G0 VALUES
            for k in range(self.params.nG0):
                pDetect = 1.0 - np.prod(1.0 - self.params.g0[k] * 
                    np.exp(-distij**2 / 2.0 / self.params.sigma**2))
                self.detectArray[i, k] = pDetect

    def plotDetect(self, plotFName):
        # graph detection results
        P.figure(figsize=(16, 10))
        ax1 = P.gca()
        lns0 = ax1.plot(self.params.g0, self.detectArray[0], color='k', label='Homerange 1', 
            linewidth = 3.0)
        lns1 = ax1.plot(self.params.g0, self.detectArray[1], color='b', label='Homerange 2', 
            linewidth = 3.0)
        lns2 = ax1.plot(self.params.g0, self.detectArray[2], color='r', label='Homerange 3', 
            linewidth = 3.0)
        lns3 = ax1.plot(self.params.g0, self.detectArray[3], color='y', label='Homerange 4', 
            linewidth = 3.0)
        lns = lns0 + lns1 + lns2 + lns3
        labs = [l.get_label() for l in lns]

        for tick in ax1.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax1.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        ax1.set_xlabel('g0', fontsize = 17)
        ax1.set_ylabel('Prob. detection', fontsize = 17)
        ax1.legend(lns, labs, loc = 'upper left')
        P.ylim([0.0, 1.0])

        P.savefig(plotFName, format='png', dpi= 600)
        P.show()

    def getG0(self):
        diffAbs = np.abs(self.params.g0 - self.params.dogG0)
        minDiffAbs = np.min(diffAbs)
        g0Obs = np.where(diffAbs == minDiffAbs)
        pDetectDog = self.detectArray[:, g0Obs]
        print('pDetectDog', pDetectDog)

        diffAbs = np.abs(self.params.g0 - self.params.personG0)
        minDiffAbs = np.min(diffAbs)
        g0Obs = np.where(diffAbs == minDiffAbs)
        pDetectPerson = self.detectArray[:, g0Obs]
        print('pDetectPerson', pDetectPerson)



######################
# Main function
def main():
    # datapath
    dataPath = os.path.join(os.getenv('POFPROJDIR', default='.'), 
        'poa', 'Nutria', 'Data')
    resultPath = os.path.join(os.getenv('POFPROJDIR', default='.'), 
        'poa', 'Nutria', 'Results', 'mod0')

    hrFName = os.path.join(dataPath, 'HRLoc.csv')
    surveyFName = os.path.join(dataPath, 'focalDogPoints2019.csv')
    plotFName = os.path.join(resultPath, 'detectPlots.png')
    params = Params()
    processData = ProcessData(params, hrFName, surveyFName, plotFName)




if __name__ == '__main__':
    main()

