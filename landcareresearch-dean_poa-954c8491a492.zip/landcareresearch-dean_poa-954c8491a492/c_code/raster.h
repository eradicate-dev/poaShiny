
#ifndef __RASTER_H__
#define __RASTER_H__

/* Contains the sRaster structure and some functions to operate on it */
/* sRaster is basically the contents of an ASCII grid loaded into memory */
struct sRaster
{
    int nRows;
    int nColumns;
    double xllcorner;
    double yllcorner;
    double resolution;
    double halfresolution;
    double *pData;
};

/* same as sRaster, but for masks */
struct sMaskRaster
{
    int nRows;
    int nColumns;
    double xllcorner;
    double yllcorner;
    double resolution;
    double halfresolution;
    char *pData;
};

struct sRaster* createRaster( int nColumns, int nRows, double xllcorner, double yllcorner, double resolution );
struct sMaskRaster* createMaskRaster( int nColumns, int nRows, double xllcorner, double yllcorner, double resolution );

int rasterWriteToFile( struct sRaster *pRaster, const char *pszFilename );
int maskRasterWriteToFile( struct sMaskRaster *pRaster, const char *pszFilename );
int rasterWriteToCSV( struct sRaster *pRaster, const char *pszFilename );

struct sRaster* createRasterFromFile( const char *pszFilename );
struct sMaskRaster* createMaskRasterFromFile( const char *pszFilename );

struct sMaskRaster* duplicateMaskRaster( struct sMaskRaster *pRaster);

void destroyRaster( struct sRaster *pRaster );
void destroyMaskRaster( struct sMaskRaster *pRaster );

void rasterSetValue( struct sRaster *pRaster, int x, int y, double dVal );
void maskRasterSetValue( struct sMaskRaster *pRaster, int x, int y, char val);
double rasterGetValue( struct sRaster *pRaster, int x, int y );
char maskRasterGetValue( struct sMaskRaster *pRaster, int x, int y );
int rasterGetXY( struct sRaster *pRaster, double easting, double northing,  int *pX, int *pY );
void rasterGetNorthingEasting( struct sRaster *pRaster, int X, int Y, double *pdEasting, double *pdNorthing );

double rasterTotal( struct sRaster *pRaster );
int maskRasterTotal( struct sMaskRaster *pRaster );
double rasterMinimum( struct sRaster *pRaster );
double rasterMaximumWithMask( struct sRaster *pRaster, struct sMaskRaster *pMaskRaster );
void addRasters( struct sRaster *pRaster1, struct sRaster *pRaster2 );
void divideRasterByConstant( struct sRaster *pRaster, double dConst );


#endif /*__RASTER_H__*/

