
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#include "raster.h"
#include "types.h"

/* may need to be bigger */
#define MAXLINE 10240

#ifdef _WIN32
   /* Windows has a different name */
   #define strcasecmp _stricmp 
#endif
   
/* Contains the sRaster structure and some functions to operate on it */

/* creates a blank raster of required size */
struct sRaster* createRaster( int nColumns, int nRows, double xllcorner, double yllcorner, double resolution )
{
    struct sRaster *pRaster;
    pRaster = calloc( 1, sizeof( struct sRaster ) );
    if( pRaster == NULL )
    {
        fprintf( stderr, "Unable to allocate memory\n" );
        exit( 1 );
    }
    pRaster->nRows = nRows;
    pRaster->nColumns = nColumns;
    pRaster->xllcorner = xllcorner;
    pRaster->yllcorner = yllcorner;
    pRaster->resolution = resolution;
    pRaster->halfresolution = resolution / 2.0;
    pRaster->pData = calloc( nRows * nColumns, sizeof( double ) );
    if( pRaster->pData == NULL )
    {
        fprintf( stderr, "Unable to allocate memory\n" );
        exit( 1 );
    }
    return pRaster;
}

/* creates a blank raster of required size */
struct sMaskRaster* createMaskRaster( int nColumns, int nRows, double xllcorner, double yllcorner, double resolution )
{
    struct sMaskRaster *pRaster;
    pRaster = calloc( 1, sizeof( struct sMaskRaster ) );
    if( pRaster == NULL )
    {
        fprintf( stderr, "Unable to allocate memory\n" );
        exit( 1 );
    }
    pRaster->nRows = nRows;
    pRaster->nColumns = nColumns;
    pRaster->xllcorner = xllcorner;
    pRaster->yllcorner = yllcorner;
    pRaster->resolution = resolution;
    pRaster->halfresolution = resolution / 2.0;
    pRaster->pData = calloc( nRows * nColumns, sizeof( char ) );
    if( pRaster->pData == NULL )
    {
        fprintf( stderr, "Unable to allocate memory\n" );
        exit( 1 );
    }
    return pRaster;
}

/* Writes contents of raster to ASCII grid file */
int rasterWriteToFile( struct sRaster *pRaster, const char *pszFilename )
{
    int xcount, ycount;
    double dVal;
    FILE *fh = fopen( pszFilename, "w" );
    if( fh != NULL )
    {
        fprintf( fh, "ncols         %d\n", pRaster->nColumns );
        fprintf( fh, "nrows         %d\n", pRaster->nRows );
        fprintf( fh, "xllcorner     %.8f\n", pRaster->xllcorner );
        fprintf( fh, "yllcorner     %.8f\n", pRaster->yllcorner );
        fprintf( fh, "cellsize      %f\n", pRaster->resolution );
        fprintf( fh, "NODATA_value  -9999\n" );
        for( ycount = 0; ycount < pRaster->nRows; ycount++ )
        {
            for( xcount = 0; xcount < pRaster->nColumns; xcount++ )
            {
                dVal = rasterGetValue( pRaster, xcount, ycount );
                fprintf( fh, "%.5f", dVal );
                if( xcount < ( pRaster->nColumns - 1 ) )
                    fprintf( fh, " " );
                else
                    fprintf( fh, "\n" );
            }
        }
        fclose( fh );
    }
    else
    {
        fprintf( stderr, "Unable to create %s\n", pszFilename );
        return 0;
    }
    return 1;
}

int maskRasterWriteToFile( struct sMaskRaster *pRaster, const char *pszFilename )
{
    int xcount, ycount;
    int nVal;
    FILE *fh = fopen( pszFilename, "w" );
    if( fh != NULL )
    {
        fprintf( fh, "ncols         %d\n", pRaster->nColumns );
        fprintf( fh, "nrows         %d\n", pRaster->nRows );
        fprintf( fh, "xllcorner     %.8f\n", pRaster->xllcorner );
        fprintf( fh, "yllcorner     %.8f\n", pRaster->yllcorner );
        fprintf( fh, "cellsize      %f\n", pRaster->resolution );
        fprintf( fh, "NODATA_value  -9999\n" );
        for( ycount = 0; ycount < pRaster->nRows; ycount++ )
        {
            for( xcount = 0; xcount < pRaster->nColumns; xcount++ )
            {
                nVal = maskRasterGetValue( pRaster, xcount, ycount );
                fprintf( fh, "%2d", nVal );
                if( xcount < ( pRaster->nColumns - 1 ) )
                    fprintf( fh, " " );
                else
                    fprintf( fh, "\n" );
            }
        }
        fclose( fh );
    }
    else
    {
        fprintf( stderr, "Unable to create %s\n", pszFilename );
        return 0;
    }
    return 1;
}

/* Writes contents of raster to .csv file */
int rasterWriteToCSV( struct sRaster *pRaster, const char *pszFilename )
{
    int xcount, ycount;
    double dVal;
    FILE *fh = fopen( pszFilename, "w" );
    if( fh != NULL )
    {
        for( ycount = 0; ycount < pRaster->nRows; ycount++ )
        {
            for( xcount = 0; xcount < pRaster->nColumns; xcount++ )
            {
                dVal = rasterGetValue( pRaster, xcount, ycount );
                fprintf( fh, "%.5f", dVal );
                if( xcount < ( pRaster->nColumns - 1 ) )
                    fprintf( fh, "," );
                else
                    fprintf( fh, "\n" );
            }
        }
        fclose( fh );
    }
    else
    {
        fprintf( stderr, "Unable to create %s\n", pszFilename );
        return 0;
    }
    return 1;
}

/* Reads the contents of an ASCII grid into memory as a sRaster */
struct sRaster* createRasterFromFile( const char *pszFilename )
{
    struct sRaster *pRaster = NULL;
    int nColumns = 0, nRows = 0, i;
    double xllcorner = 0, yllcorner = 0, resolution = 0;
    char szBuffer[MAXLINE];
    char *pszCurrent;
    int xcount = 0, ycount = 0;
    double dVal;
    FILE *fh = fopen( pszFilename, "r" );
    if( fh != NULL )
    {
        while( fgets( szBuffer, MAXLINE, fh ) != NULL )
        {
            if( pRaster == NULL )
            {
                /* still reading the header */
                pszCurrent = strtok( szBuffer, " " );

                i = 0;
                while( pszCurrent[i] != '\0' )
                {
                    pszCurrent[i] = tolower( pszCurrent[i] );
                    i++;
                }

                if( strcasecmp( pszCurrent, "ncols" ) == 0 )
                    nColumns = atol( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "nrows" ) == 0 )
                    nRows = atol( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "xllcorner" ) == 0 )
                    xllcorner = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "yllcorner" ) == 0 )
                    yllcorner = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "cellsize" ) == 0 )
                    resolution = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "nodata_value" ) == 0 )
                {
                    /* we don't deal with this but we should be at the end of */
                    /* the header so create the raster */
                    pRaster = createRaster( nColumns, nRows, xllcorner, yllcorner, resolution );
                }
            }
            else
            {
                /* deal with the current line */
                xcount = 0;
                pszCurrent = strtok( szBuffer, " " );
                while( pszCurrent != NULL )
                {
                    /* Do a bounds check */
                    if( ( xcount < nColumns ) && ( ycount < nRows ) )
                    {
                        dVal = atof( pszCurrent );
                        rasterSetValue( pRaster, xcount, ycount, dVal );    
                    }
                    pszCurrent = strtok( NULL, " " );
                    xcount++;
                }
                ycount++;
            }
        }
        fclose( fh );
    }
    return pRaster;
}

/* Reads the contents of an ASCII grid into memory as a sMaskRaster */
struct sMaskRaster* createMaskRasterFromFile( const char *pszFilename )
{
    struct sMaskRaster *pRaster = NULL;
    int nColumns = 0, nRows = 0, i;
    double xllcorner = 0, yllcorner = 0, resolution = 0;
    char szBuffer[MAXLINE];
    char *pszCurrent;
    int xcount = 0, ycount = 0;
    int nVal;
    FILE *fh = fopen( pszFilename, "r" );
    if( fh != NULL )
    {
        while( fgets( szBuffer, MAXLINE, fh ) != NULL )
        {
            if( pRaster == NULL )
            {
                /* still reading the header */
                pszCurrent = strtok( szBuffer, " " );

                i = 0;
                while( pszCurrent[i] != '\0' )
                {
                    pszCurrent[i] = tolower( pszCurrent[i] );
                    i++;
                }

                if( strcasecmp( pszCurrent, "ncols" ) == 0 )
                    nColumns = atol( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "nrows" ) == 0 )
                    nRows = atol( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "xllcorner" ) == 0 )
                    xllcorner = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "yllcorner" ) == 0 )
                    yllcorner = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "cellsize" ) == 0 )
                    resolution = atof( strtok( NULL, " " ) );
                else if( strcasecmp( pszCurrent, "nodata_value" ) == 0 )
                {
                    /* we don't deal with this but we should be at the end of */
                    /* the header so create the raster */
                    pRaster = createMaskRaster( nColumns, nRows, xllcorner, yllcorner, resolution );
                }
            }
            else
            {
                /* deal with the current line */
                xcount = 0;
                pszCurrent = strtok( szBuffer, " " );
                while( pszCurrent != NULL )
                {
                    /* Do a bounds check */
                    if( ( xcount < nColumns ) && ( ycount < nRows ) )
                    {
                        nVal = atol( pszCurrent );
                        /* Interpret nodata value as 0 */
                        if( nVal == -9999 )
                            nVal = 0;
                        maskRasterSetValue( pRaster, xcount, ycount, nVal );    
                    }
                    pszCurrent = strtok( NULL, " " );
                    xcount++;
                }
                ycount++;
            }
        }
        fclose( fh );
    }
    return pRaster;
}

struct sMaskRaster* duplicateMaskRaster( struct sMaskRaster *pRaster)
{
struct sMaskRaster* pNewRaster;

    pNewRaster = createMaskRaster(pRaster->nColumns, pRaster->nRows,
                        pRaster->xllcorner, pRaster->yllcorner, pRaster->resolution);

    memcpy(pNewRaster->pData, pRaster->pData, pRaster->nColumns * pRaster->nRows * sizeof(char));
                      
    return pNewRaster;
}

/* Remove a raster from memory. Pointer will be invalid after call */
void destroyRaster( struct sRaster *pRaster )
{
    free( pRaster->pData );
    free( pRaster );
}

void destroyMaskRaster( struct sMaskRaster *pRaster )
{
    free( pRaster->pData );
    free( pRaster );
}

/* Sets a value at a particular x and y in the raster */
void rasterSetValue( struct sRaster *pRaster, int x, int y, double dVal )
{
    int idx = ( y * pRaster->nColumns ) + x;
    pRaster->pData[idx] = dVal;
}

void maskRasterSetValue( struct sMaskRaster *pRaster, int x, int y, char val )
{
    int idx = ( y * pRaster->nColumns ) + x;
    pRaster->pData[idx] = val;
}

/* Gets a value from a particular x and y in the raster */
double rasterGetValue( struct sRaster *pRaster, int x, int y )
{
    int idx = ( y * pRaster->nColumns ) + x;
    return pRaster->pData[idx];
}

char maskRasterGetValue( struct sMaskRaster *pRaster, int x, int y )
{
    int idx = ( y * pRaster->nColumns ) + x;
    return pRaster->pData[idx];
}

/* For a given easting and northing find the x and y that would be in on this raster */
/* Returns 1 if within the raster, 0 otherwise */
int rasterGetXY( struct sRaster *pRaster, double easting, double northing,  int *pX, int *pY )
{
    /* do adjustment from centre of pixel to edge  */
    /* to match the R. Might have to revisit */
    *pX = (int)round(( easting - pRaster->xllcorner - pRaster->halfresolution ) / pRaster->resolution);
    /* adjust for lower left y coord */
    *pY = pRaster->nRows - (int)round(( northing - pRaster->yllcorner - pRaster->halfresolution ) / pRaster->resolution);
    if( ( *pX < pRaster->nColumns ) && ( *pY < pRaster->nRows ) && ( *pX >= 0 ) && ( *pY >= 0 ) )
        return 1;
    return 0;
}

void rasterGetNorthingEasting( struct sRaster *pRaster, int X, int Y, double *pdEasting, double *pdNorthing )
{
    *pdEasting = pRaster->xllcorner + pRaster->halfresolution + (X * pRaster->resolution);
    *pdNorthing = pRaster->yllcorner - pRaster->halfresolution + ((pRaster->nRows - Y) * pRaster->resolution);
}

/* Finds the total of the raster */
double rasterTotal( struct sRaster *pRaster )
{
    double dTotal = 0;
    int i, Ni;
    Ni = pRaster->nColumns * pRaster->nRows;
    for( i = 0; i < Ni; i++ )
        dTotal += pRaster->pData[i];
    return dTotal;
}

int maskRasterTotal( struct sMaskRaster *pRaster )
{
    int nTotal = 0;
    int i, Ni;
    Ni = pRaster->nColumns * pRaster->nRows;
    for( i = 0; i < Ni; i++ )
        nTotal += pRaster->pData[i];
    return nTotal;
}

/* Finds the smallest value in the raster */
double rasterMinimum( struct sRaster *pRaster )
{
    int i, Ni;
    double dMinimum = pRaster->pData[0];
    Ni = pRaster->nColumns * pRaster->nRows;
    for( i = 1; i < Ni; i++ )
        if( pRaster->pData[i] < dMinimum )
            dMinimum = pRaster->pData[i];
    return dMinimum;
}

/* Finds the largest value where mask!=0 */
double rasterMaximumWithMask( struct sRaster *pRaster, struct sMaskRaster *pMaskRaster )
{
    int i, Ni;
    double dMaximum = -1;
    if( ( pRaster->nColumns != pMaskRaster->nColumns ) ||
        ( pRaster->nRows != pMaskRaster->nRows ) )
    {
        fprintf( stderr, "Rasters do not match in size" );
    }
    Ni = pRaster->nColumns * pRaster->nRows;
    for( i = 0; i < Ni; i++ )
    {
        if( pMaskRaster->pData[i] != 0 )
        {
            if( pRaster->pData[i] > dMaximum )
                dMaximum = pRaster->pData[i];
        }
    }
    return dMaximum;
}

/* Adds pRaster2 onto pRaster1 */
void addRasters( struct sRaster *pRaster1, struct sRaster *pRaster2 )
{
    int i, Ni;
    if( ( pRaster1->nColumns != pRaster2->nColumns ) ||
        ( pRaster1->nRows != pRaster2->nRows ) )
    {
        fprintf( stderr, "Rasters do not match in size" );
    }

    Ni = pRaster1->nColumns * pRaster1->nRows;
    for( i = 0; i < Ni; i++ )
    {
        pRaster1->pData[i] += pRaster2->pData[i];
    }
}

/* Divides whole raster by a single value */
void divideRasterByConstant( struct sRaster *pRaster, double dConst )
{
    int i, Ni;
    Ni = pRaster->nColumns * pRaster->nRows;
    for( i = 0; i < Ni; i++ )
    {
        pRaster->pData[i] = pRaster->pData[i] / dConst;
    }
}
