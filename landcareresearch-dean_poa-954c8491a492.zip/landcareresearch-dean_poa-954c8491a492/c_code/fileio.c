
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef _WIN32
    /* Windows needs this for some reason */
    #define snprintf _snprintf
#endif

#include "types.h"

/* Contains functions for reading data files */

/* Reads a parameter file which is a comma seperated file of parameters for each species */
/* Order of columns: */
/* "meansig","sd_sig","mean_CC","sd_CC","mean_capt","sd_capt","mean_test","sd_test","mean_infect","sd_infect" */
/* Order of rows: */ 
/* "POSSUM","POSSTRAP","CHEWCARD","FERRET","PIG","REDDEER" */
int readParameters( const char *pszFilename, struct sParameter **ppParameters )
{
    char szBuffer[512];
    struct sParameter *pCurrParameter;
    char *pszCurrent;
    int nCurrField, nCount = 0;
    FILE *fh = fopen( pszFilename, "r" );
    if( fh != NULL )
    {
        *ppParameters = calloc( NSPECIES, sizeof( struct sParameter ) );
        if( *ppParameters == NULL )
        {
            fprintf( stderr, "Unable to allocate enough memory\n" );
            exit( 1 );
        }
        while( fgets( szBuffer, 512, fh ) != NULL )
        {
            if( nCount > NSPECIES )
            {
                fprintf( stderr, "Error: number of lines in parameter file %s greater than NSPECIES\n", pszFilename);
                exit( 1 );
            }

            pCurrParameter = &(*ppParameters)[nCount];
            nCurrField = 0;
            pszCurrent = strtok( szBuffer, "," );
            while( pszCurrent != NULL )
            {
                switch( nCurrField )
                {
                    case 0:
                        pCurrParameter->mean_sig = atof( pszCurrent );
                        break;
                    case 1:
                        pCurrParameter->sd_sig = atof( pszCurrent );
                        break;
                    case 2:
                        pCurrParameter->mean_CC = atof( pszCurrent );
                        break;
                    case 3:
                        pCurrParameter->sd_CC = atof( pszCurrent );
                        break;
                    case 4:
                        pCurrParameter->mean_capt = atof( pszCurrent );
                        break;
                    case 5:
                        pCurrParameter->sd_capt = atof( pszCurrent );
                        break;
                    case 6:
                        pCurrParameter->mean_test = atof( pszCurrent );
                        break;
                    case 7:
                        pCurrParameter->sd_test = atof( pszCurrent );
                        break;
                    case 8:
                        pCurrParameter->mean_infect = atof( pszCurrent );
                        break;
                    case 9:
                        pCurrParameter->sd_infect = atof( pszCurrent );
                        break;
                }
                pszCurrent = strtok( NULL, "," );
                nCurrField++;
            }
            /* calculate beta distributions */
            findBeta( pCurrParameter->mean_CC, pCurrParameter->sd_CC, 
                        &pCurrParameter->a_CC, &pCurrParameter->b_CC );
            findBeta( pCurrParameter->mean_capt, pCurrParameter->sd_capt, 
                        &pCurrParameter->a_capt, &pCurrParameter->b_capt );
            findBeta( pCurrParameter->mean_test, pCurrParameter->sd_test, 
                        &pCurrParameter->a_test, &pCurrParameter->b_test );
            findBeta( pCurrParameter->mean_infect, pCurrParameter->sd_infect, 
                        &pCurrParameter->a_infect, &pCurrParameter->b_infect );
            nCount++;
        }
        fclose( fh );
        return 1;
    }
    return 0;
}

void printParameters(struct sParameter *pParameters)
{
int i;
struct sParameter *pCurrentParam;
    for( i = 0; i < NSPECIES; i++ )
    {
        switch(i)
        {
        case possum:
            printf( "Possum\n" );
            break;
        case posstrap:
            printf( "Trap\n" );
            break;
        case chewcard:
            printf( "Chewcard\n" );
            break;
        case ferret:
            printf( "ferret\n" );
            break;
        case pig:
            printf( "pig\n" );
            break;
        case reddeer:
            printf( "reddeer\n" );
            break;
        }
        printf( "---------------------\n" );
        pCurrentParam = &pParameters[i];
        printf( "sig %f %f\n", pCurrentParam->mean_sig, pCurrentParam->sd_sig );
        printf( "CC %f %f %f %f\n", pCurrentParam->mean_CC, pCurrentParam->sd_CC, pCurrentParam->a_CC, pCurrentParam->b_CC );
        printf( "capt %f %f %f %f\n", pCurrentParam->mean_capt, pCurrentParam->sd_capt, pCurrentParam->a_capt, pCurrentParam->b_capt );
        printf( "test %f %f %f %f\n", pCurrentParam->mean_test, pCurrentParam->sd_test, pCurrentParam->a_test, pCurrentParam->b_test );
        printf( "infect %f %f %f %f\n", pCurrentParam->mean_infect, pCurrentParam->sd_infect, pCurrentParam->a_infect, pCurrentParam->b_infect );
    }
}

int isNumber(const char *psz)
{
int i = 0;
int valid = 1;
    /* remove leading whitespace*/
    while( (psz[i] == ' ') && (psz[i] != '\0'))
        i++;
        
    /* never got to any chars */
    if( psz[i] == '\0' )
        return 0;
    
    for( i = 0; (psz[i] != '\0') && (psz[i] != '\n') && valid; i++)
    {
        if( !isdigit(psz[i]) && (psz[i] != '.'))
            valid = 0;
    }
    return valid;
}

#define MAX_YEARSEQ 100

/* Reads the trap's CSV file which is actually a mix of traps, chewcards and species */
/* Order of columns: year, species, easting, northing, age, sex, trapnights */
int readTrapCSV(const char *pszFilename, struct sTrapData **ppTrapData, 
                    int **ppnSurveillanceYearSeq, int *pnSurveillanceYears, char **ppszMessage )
{
    int nCurrLine = 0;
    int nTotalLines = 0;
    int nCurrField;
    FILE *fh;
    char szBuffer[512];
    char *pszCurrent;
    struct sTrapData *pCurrData;
    int i, nChars;
    char *pszFormat;

    *ppszMessage = NULL;

    fh = fopen( pszFilename, "r" );
    if( fh != NULL )
    {
        /* first read through the file so we know how many lines there are */
        while( fgets( szBuffer, 512, fh ) != NULL )
        {
            nTotalLines++;
        }
        /* take one off for the header */
        nTotalLines--;
        /* go back to the beginning of the file so we can start reading for real */
        fseek( fh, 0, SEEK_SET );

        /* allocate space for the data */
        *ppTrapData = calloc( nTotalLines, sizeof( struct sTrapData ) );
        if( *ppTrapData == NULL )
        {
            /* just bail - not worth trying to deal with */
            fprintf( stderr, "Unable to allocate enough memory\n" );
            return 0;
        }

        /* allocate space for the surveillance year sequence */
        /* Don't have a good way of knowing how many */
        *ppnSurveillanceYearSeq = calloc( MAX_YEARSEQ, sizeof( int ) );
        if( *ppnSurveillanceYearSeq == NULL )
        {
            /* just bail - not worth trying to deal with */
            fprintf( stderr, "Unable to allocate enough memory\n" );
            return 0;
        }
        *pnSurveillanceYears = 0;

        while( fgets( szBuffer, 512, fh ) != NULL )
        {
            /* ignore header */
            if( nCurrLine != 0 )
            {
                pCurrData = &((*ppTrapData)[nCurrLine - 1]);
                nCurrField = 0;
                pszCurrent = strtok( szBuffer, "," );
                while( pszCurrent != NULL )
                {
                    switch( nCurrField )
                    {
                        case 0:
                            pCurrData->year = atol( pszCurrent );
                            if( inList( pCurrData->year, *ppnSurveillanceYearSeq, *pnSurveillanceYears ) == -1 )
                            {
                                /* Don't have this year */
                                (*ppnSurveillanceYearSeq)[*pnSurveillanceYears] = pCurrData->year;
                                (*pnSurveillanceYears)++;
                                if( *pnSurveillanceYears > MAX_YEARSEQ )
                                {
                                    fprintf( stderr, "must increase MAX_YEARSEQ\n" );
                                    return 0;
                                }
                            }
                            break;
                        case 1:
                            /* convert to upper case */
                            i = 0;
                            while( pszCurrent[i] != '\0' )
                            {
                                pszCurrent[i] = toupper( pszCurrent[i] );
                                i++;
                            }
                            if( strcmp( pszCurrent, "POSSUM" ) == 0 )
                                pCurrData->species = possum;
                            else if( strcmp( pszCurrent, "POSSTRAP" ) == 0 )
                                pCurrData->species = posstrap;
                            else if( strcmp( pszCurrent, "CHEWCARD" ) == 0 )
                                pCurrData->species = chewcard;
                            else if( strcmp( pszCurrent, "FERRET" ) == 0 )
                                pCurrData->species = ferret;
                            else if( strcmp( pszCurrent, "PIG" ) == 0 )
                                pCurrData->species = pig;
                            else if( strcmp( pszCurrent, "REDDEER" ) == 0 )
                                pCurrData->species = reddeer;
                            else
                            {
                                pszFormat = "Unknown species %s\n";
                                nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                *ppszMessage = (char*)malloc( nChars + 1 );
                                snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                return 0;
                            }
                            break;
                        case 2:
                            if( !isNumber(pszCurrent) )
                            {
                                pszFormat = "Invalid Easting %s\n";
                                nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                *ppszMessage = (char*)malloc( nChars + 1 );
                                snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                return 0;                                
                            }
                            pCurrData->easting = atof( pszCurrent );
                            break;
                        case 3:
                            if( !isNumber(pszCurrent) )
                            {
                                pszFormat = "Invalid Northing %s\n";
                                nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                *ppszMessage = (char*)malloc( nChars + 1 );
                                snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                return 0;                                
                            }
                            pCurrData->northing = atof( pszCurrent );
                            break;
                        case 4:
                            if( (pCurrData->species == posstrap) || 
                                (pCurrData->species == chewcard) )
                            {
                                /* ignore */
                                pCurrData->age = -1;
                            }
                            else
                            {
                                if( !isNumber(pszCurrent) )
                                {
                                    pszFormat = "Invalid Age %s\n";
                                    nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                    *ppszMessage = (char*)malloc( nChars + 1 );
                                    snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                    return 0;                                
                                }
                                pCurrData->age = atof( pszCurrent );
                                if( pCurrData->age <= 0 )
                                {
                                    pszFormat = "Age must be positive (found %s)\n";
                                    nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                    *ppszMessage = (char*)malloc( nChars + 1 );
                                    snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                    return 0;                                
                                }
                            }
                            break;
                        case 5:
                            if( (pCurrData->species == posstrap) || 
                                (pCurrData->species == chewcard) )
                            {
                                /* ignore */
                                pCurrData->sex = male;
                            }
                            else
                            {
                                pszCurrent[0] = toupper( pszCurrent[0] );
                                if( pszCurrent[0] == 'M' )
                                    pCurrData->sex = male;
                                else if( pszCurrent[0] == 'F' )
                                    pCurrData->sex = female;
                                else
                                {
                                    pszFormat = "Unknown sex %s\n";
                                    nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                    *ppszMessage = (char*)malloc( nChars + 1 );
                                    snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                    return 0;
                                }
                            }
                            break;
                        case 6:
                            if( (pCurrData->species == ferret) || 
                                (pCurrData->species == pig) ||
                                (pCurrData->species == reddeer) )
                            {
                                /* ignore */
                                pCurrData->trapnights = -1;
                            }
                            else
                            {
                                if( !isNumber(pszCurrent) )
                                {
                                    pszFormat = "Invalid Trapnight %s\n";
                                    nChars = snprintf( NULL, 0, pszFormat, pszCurrent );
                                    *ppszMessage = (char*)malloc( nChars + 1 );
                                    snprintf( *ppszMessage, nChars + 1, pszFormat, pszCurrent );
                                    return 0;                                
                                }
                                pCurrData->trapnights = atol( pszCurrent );
                            }
                            break;
                    }
                    pszCurrent = strtok( NULL, "," );
                    nCurrField++;
                }
            }
            nCurrLine++;
        }
        fclose( fh );
    }
    else
    {
        pszFormat = "Cannot open file %s\n";
        nChars = snprintf( NULL, 0, pszFormat, pszFilename );
        *ppszMessage = (char*)malloc( nChars + 1 );
        snprintf( *ppszMessage, nChars + 1, pszFormat, pszFilename );
    }
    return nTotalLines;
}
