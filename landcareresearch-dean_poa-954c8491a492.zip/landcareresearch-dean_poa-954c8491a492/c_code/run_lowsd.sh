#!/bin/sh

GDALVER=`python -c "from osgeo import gdal;print(gdal.__version__[0])"`

./proffreedom data/surveyData.csv data/params_lowsd.csv 2007,2008,2009,2010,2011 \
    5 3 data/extentMask.asc data/relRiskRaster_gdal${GDALVER}.asc 2.0 5 100 0.009999 0.01 0.0100001 \
    0.499999 0.5 0.5000001


#./proffreedom data/surveyData.csv data/params_lowsd.csv 2007,2008,2009,2010,2011 5 3 data/mask.asc data/kres.asc 2.0 5 100 0.009999 0.01 0.0100001 0.499999 0.5 0.5000001