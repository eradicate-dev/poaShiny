
#include <math.h>

/* Some handy functions used elsewhere */

/* Find a and b of a Beta distribution given mean and standard deviation */
void findBeta( double mu, double sdev, double *pA, double *pB )
{
    double sdevsq = sdev * sdev;
    *pA = mu * ( ( mu * (1.0 - mu) ) / sdevsq - 1.0);
    *pB = ( 1.0 - mu ) * ( ( mu * ( 1.0 - mu ) ) / sdevsq - 1.0);
}

/* Find a and b of a Beta distribution given the information for a Pert distribution */
/* (min, mode, max) */
/* see http://rgm2.lab.nig.ac.jp/RGM2/func.php?rd_id=mc2d:pert */
void findBetaPert(double min, double mode, double max, double shape, double *pShape1, double *pShape2)
{
double mu;
    mu = (min + max + shape * mode)/(shape + 2.0);

    if( mu == mode)
        *pShape1 = 1.0 + shape / 2.0;
    else
        *pShape1 = (mu - min) * (2.0 * mode - min - max)/((mode-mu)*(max - min));

    *pShape2 = *pShape1 * (max - mu)/(mu - min);
}

/* Check if a certain value is in a list of integers */
/* returns index if found, -1 otherwise */
int inList( int nValue, int *pList, int nLength )
{
    int nCount;
    for( nCount = 0; nCount < nLength; nCount++ )
    {
        if( pList[nCount] == nValue )
            return nCount;
    }
    return -1;
}


