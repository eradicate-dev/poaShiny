
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include "types.h"
#include "raster.h"

#ifdef _WIN32
#define strdup _strdup
#endif

/* It turns out that when we start doing some processing */
/* We don't need the K values - just the ARi */
/* So we do an in-place conversion */
/* Need to make sure we are only including areas where the mask is 1 */
void convertRasterToARi( struct sRaster *pKRaster, struct sMaskRaster *pMask, int nTotalCells )
{
    int i;
    double dTotalRRi = 0;
    int n = pKRaster->nColumns * pKRaster->nRows;
    double dMinK = 100000;

    /* find minimum k */
    for( i = 0; i < n; i++ )
    {
        if( ( pMask->pData[i] != 0 ) && ( pKRaster->pData[i] < dMinK ) )
            dMinK = pKRaster->pData[i];
    }   

    /* first convert to RRi */
    /* Equation 7 */
    for( i = 0; i < n; i++ )
    {
        if( pMask->pData[i] != 0 )
        {
            pKRaster->pData[i] = pKRaster->pData[i] / dMinK;
            dTotalRRi += pKRaster->pData[i];
        }
    }

    /* Equation 6 */
    for( i = 0; i < n; i++ )
    {
        if( pMask->pData[i] != 0 )
            pKRaster->pData[i] = nTotalCells * pKRaster->pData[i] / dTotalRRi;
    }
}

/* Function that processes all the traps for a given year */
/* And returns the sensitivity for that run plus some intermediate values */
/* *pnCallbackValue is set to the return of the percentCallback */
/* if non-zero function returns straight away */
/* *pnLastPercentTime is update with the time of the last percentCallback - called every 1 sec */
struct sRaster * ProcessAllTrapsForYear( int nYear, struct sTrapData *pTrapData, int nTraps, struct sParameter *pParameters, 
                        int nChewcardTraps, 
                        gsl_rng *pRandomGenerator, struct sRaster *pSensitivityRaster, struct sMaskRaster *pMask,
                        struct sRaster *pARRaster, int (*percentCallback)(int, void*), void *pCallbackData,
                        int nProcessedTraps, int nTotalTrapsToProcess, time_t *pnLastPercentTime,
                        double *pdTotalAR, double *pdAverageSensitivity, int *pnSearchedCells, int *pnCallbackValue )
{
    struct sTrapData *pCurrentTrap;
    struct sParameter *pCurrentParam;
    double dSigma, dFourSigma, dSearchDistance;
    double dSearchTLX, dSearchTLY, dSearchBRX, dSearchBRY;
    double dXDist, dYDist, dDist, dKern;
    double dpCap, dpChew;
    int nCurrentTrap;
    double dg0_capt = 0; /* Probability of capturing a possums if the trapping device placed at home-range centre */
    double dg0_CC = 0;
    double dLambda = 0; /* annual probability of infection in a sentinel given an infected possum in its home range */
    double dTest; /* prob if the diagnostic test to detect Tb given an infected animal */
    double dSensitivityTrapCell; /* Sensitivity of trap j detecting Tb in cell i. SeUij in R code and paper */
    int nSearchedCells;             /* number of searched cells */
    double dTotalAR; /* adjusted risk for all search grid cells */
    double dTotalSensitivity;  /* of all traps */
    double testEast, testNorth;
    int testX, testY;
    int nPercent;
    struct sRaster *pThisSensitivity; /* sensitivities for this run - initially prob not detecting */
    double dOldValue, dNewValue;
    int i, Ni;
    time_t nCurrentTime;
    int nTLX, nTLY, nBRX, nBRY;

    /* create blank raster with sensitivities for this iteration */
    pThisSensitivity = createRaster( pSensitivityRaster->nColumns, pSensitivityRaster->nRows,
                                    pSensitivityRaster->xllcorner, pSensitivityRaster->yllcorner,
                                    pSensitivityRaster->resolution );


    /* go through each trap */
    for( nCurrentTrap = 0; nCurrentTrap < nTraps; nCurrentTrap++ )
    {
        /* get current trap and parameters for that species */
        /* Only process traps for specified year */
        pCurrentTrap = &pTrapData[nCurrentTrap];
        if( pCurrentTrap->year == nYear )
        {
            pCurrentParam = &pParameters[pCurrentTrap->species];

            /* dSigma = Spatial decay from point of the possums */
            /* utilisation of an area relative to that point */
            dSigma = pCurrentParam->mean_sig + gsl_ran_gaussian( pRandomGenerator, pCurrentParam->sd_sig );
            dFourSigma = 4.0 * dSigma;
            /* add another pixel to search just to be safe */
            dSearchDistance = dFourSigma + pSensitivityRaster->resolution;

            /* work out our search area */
            dSearchTLX = pCurrentTrap->easting - dSearchDistance;
            dSearchTLY = pCurrentTrap->northing + dSearchDistance;
            dSearchBRX = pCurrentTrap->easting + dSearchDistance;
            dSearchBRY = pCurrentTrap->northing - dSearchDistance;

            /* Convert to pixel coords */
            /* Both could be outside the raster, but we need to search */
            /* anyway in case the search area intersects with the raster */
            rasterGetXY( pSensitivityRaster, dSearchTLX, dSearchTLY, &nTLX, &nTLY );
            rasterGetXY( pSensitivityRaster, dSearchBRX, dSearchBRY, &nBRX, &nBRY );

            /* Correct back to coords on the grid */
            rasterGetNorthingEasting( pSensitivityRaster, nTLX, nTLY, &dSearchTLX, &dSearchTLY );
            
            /* Do random draws outside of pixel looping */
            dTest = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_test, pCurrentParam->b_test );
            switch( pCurrentTrap->species )
            {
                case chewcard:
                    dg0_CC = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_CC, pCurrentParam->b_CC );
                    dg0_capt = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_capt, pCurrentParam->b_capt );
                    break;
                case possum:
                case posstrap:
                    dg0_capt = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_capt, pCurrentParam->b_capt );
                    break;
                case ferret:
                case pig:
                case reddeer:
                    dLambda = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_infect, pCurrentParam->b_infect );
                    break;
            }

            /* go through each pixel in the search area */
            testNorth = dSearchTLY;
            for( testY = nTLY; testY < nBRY; testY++ )
            {
                testEast = dSearchTLX;
                for( testX = nTLX; testX < nBRX; testX++ )
                {
                    /* is this location within the raster? */
                    /* and not masked out? */
                    if( ( testX >= 0 ) && ( testY >= 0 ) && 
                        ( testX < pSensitivityRaster->nColumns ) && 
                        ( testY < pSensitivityRaster->nRows ) &&
                        ( maskRasterGetValue( pMask, testX, testY ) != 0 ) )
                    {
                        /* work out distance and then the kernel value */
                        dXDist = fabs( pCurrentTrap->easting - testEast );
                        dYDist = fabs( pCurrentTrap->northing - testNorth );
                        dDist = sqrt( dXDist * dXDist + dYDist * dYDist );
                        /* make sure our pixel is less than 4 sigma away from trap */
                        if( dDist <= dFourSigma )
                        {
                            /* Equation 11 */
                            dKern = exp( -( dDist * dDist ) / ( 2.0 * ( dSigma * dSigma ) ) );

                            switch( pCurrentTrap->species )
                            {
                                case chewcard:
                                    /* Note: chewcards not covered in paper */
                                    
                                    dpChew = 1.0 - pow( 1.0 - dg0_CC * dKern, pCurrentTrap->trapnights );
                                    dpCap = ( 1.0 - pow( 1.0 - dg0_capt * dKern, 3.0 * nChewcardTraps ) ) * dpChew;

                                    /* Probability of detecting TB in cell i from device j */
                                    dSensitivityTrapCell = dpCap * dTest;

                                    break;

                                case possum:
                                case posstrap:
                                    /* Equation 10 */
                                    dpCap = 1.0 - pow( 1.0 - dg0_capt * dKern, pCurrentTrap->trapnights );
                                    /* Probability of detecting TB in cell i from device j */
                                    dSensitivityTrapCell = dpCap * dTest;

                                    break;

                                case ferret:
                                case pig:
                                case reddeer:
                                    /* Equation 11 */
                                    /* Probability of detecting TB in cell i from device j */
                                    dSensitivityTrapCell = ( 1.0 - pow( 1.0 - dLambda * dKern, pCurrentTrap->age )) * dTest;

                                    break;

                                default:
                                    fprintf( stderr, "Unknown species %d\n", pCurrentTrap->species );
                                    dSensitivityTrapCell = 0.0;
                                    break;
                            }

                            /*fprintf(stderr, "%d %d %f\n", testX, testY, dSensitivityTrapCell);*/

                            /* Equation 8 */
                            /* product of 1-SeUij For each cell */
                            /* multiply by previous value if exists */
                            /* prob of not detecting */
                            dOldValue = rasterGetValue( pThisSensitivity, testX, testY );
                            if( dOldValue == 0 )
                                dNewValue = 1.0 - dSensitivityTrapCell;
                            else
                                dNewValue = dOldValue * ( 1.0 - dSensitivityTrapCell );
                            rasterSetValue( pThisSensitivity, testX, testY, dNewValue );
                        } /* less that 4 sigma */
                    } /* within raster */
                    testEast += pSensitivityRaster->resolution;
                } /* east */
                testNorth -= pSensitivityRaster->resolution;
            } /* north */

            /* update progress if more than one second since last call */
            nCurrentTime = time(NULL);
            if( ( nCurrentTime - *pnLastPercentTime ) > 1 )
            {
                nPercent = (int)round((double)((nProcessedTraps + nCurrentTrap) * 100) / nTotalTrapsToProcess);
                *pnCallbackValue = percentCallback( nPercent, pCallbackData );
                /* user cancel */
                if( *pnCallbackValue != 0 )
                {
                    destroyRaster( pThisSensitivity );
                    return NULL;
                }
                *pnLastPercentTime = nCurrentTime;
            }
        } /* trap for this year */
    } /* trap */

    /* now turn every value in pThisSensitivity into prob of detecting */
    /* and find for non zero cells total of prob of detecting and */
    /* total sensitivity (so we can compute average) and total AR */
    Ni = pThisSensitivity->nColumns * pThisSensitivity->nRows;
    dTotalAR = 0;
    nSearchedCells = 0;
    dTotalSensitivity = 0;
    for( i = 0; i < Ni; i++ )
    {
        dOldValue = pThisSensitivity->pData[i];
        if( dOldValue != 0 )
        {
            dNewValue = 1.0 - dOldValue;
            pThisSensitivity->pData[i] = dNewValue;
            dTotalSensitivity += dNewValue;
            /* Keep a track of number of unique cells we have used */
            nSearchedCells++;
            /* The summing of Equation 5 */
            if( pARRaster != NULL )
                dTotalAR += pARRaster->pData[i];
        }
    }

    *pdTotalAR = dTotalAR;
    *pdAverageSensitivity = dTotalSensitivity / (double)nSearchedCells;
    *pnSearchedCells = nSearchedCells;

    /* return it so it can be added to the total one */
    return pThisSensitivity;
}

/* Helper function. Does a Pert distribution which is basically a Beta with a multiplier */
/* Also does range checking */
double doBetaPert(gsl_rng *pRandomGenerator, double a, double b, double min, double max, double range)
{
double dVal;

    dVal = gsl_ran_beta( pRandomGenerator, a, b ) * range + min;
    if( dVal < min )
        dVal = min;
    else if( dVal > max )
        dVal = max;

    return dVal;
}

/* Main function */
/* Reads values from rasters and parameters and writes restults into: pSensitivityRaster, pSSeMat and pPoFMat */
/* *pnCallbackValue is set to the return of the percentCallback or newValues */
/* if non-zero function returns straight away with value 0 */
int proffreedom( struct sTrapData *pTrapData, int nTraps, struct sParameter *pParameters, 
                    int *pnYearSeq, int nYears,
                    int *pnSurveillanceYearSeq, int nSurveillanceYears, int nIter,
                    int nChewcardTraps, struct sMaskRaster *pMaskRaster, 
                    struct sRaster *pKMapRaster, int nPu, 
                    double dIntro_a, double dIntro_b, double dIntro_min, double dIntro_max, 
                    double dPrior_a, double dPrior_b, double dPrior_min, double dPrior_max,
                    char **ppszSensitivityNames, struct sRaster *pSSeMat, struct sRaster *pPoFMat,
                    int (*percentCallback)(int, void*), int (*newValues)(double, double, int, int, void*),
                    void *pCallbackData, char **ppszMessage, int *pnCallbackValue )
{

    int nCurrentIteration;
    gsl_rng *pRandomGenerator;
    int nTotalCells;  /* Ni in the R code */
    int nYearCount; /* how many years we have processed */
    int nTotalYears; /* total number of years we need to process */
    int nCurrentYear;
    int nCurrentYearIDX; /* index into pnSurveillanceYearSeq for the current year */
    double dTotalAR; /* adjusted risk for all search grid cells */
    double dAverageSensitivity; /* average grid cell sensitivity of sampled cells SeUAvg */
    double dEPIAvg; /* Effective Probability of Infection */
    double dexpTerm;
    double dSystemSensitivity; /* SSe */
    int nSearchedCells; /* ni in the R code */
    double dPrPrior, dPrIntro, dPoFLastYear;
    double dPrOfFreedom, dPStar;
    time_t nLastPercentTime = 0;
    int nProcessedTraps = 0;
    int nTotalTrapsToProcess;
    struct sRaster *pThisSensitivity, *pSensitivityRaster;
    double dIntro_range = dIntro_max - dIntro_min;
    double dPrior_range = dPrior_max - dPrior_min;

    *ppszMessage = NULL;
    *pnCallbackValue = 0;

    nTotalCells = maskRasterTotal( pMaskRaster );
    dPStar = (double)nPu / (double)nTotalCells;

    /* if we have been given a Kmap check it has the same extents */
    if( pKMapRaster != NULL )
    {
        if( ( pMaskRaster->nColumns != pKMapRaster->nColumns ) ||
            ( pMaskRaster->nRows != pKMapRaster->nRows ) ||
            ( pMaskRaster->xllcorner != pKMapRaster->xllcorner ) ||
            ( pMaskRaster->yllcorner != pKMapRaster->yllcorner ) ||
            ( pMaskRaster->resolution != pKMapRaster->resolution ) )
        {
            *ppszMessage = strdup( "Input files have different spatial extents\n" );
            return 0;
        }

        /* Ok this is going to be weird but pKMapRaster is now going to be ARi */
        convertRasterToARi( pKMapRaster, pMaskRaster, nTotalCells );
    }

    nTotalYears = pnYearSeq[nYears-1] - pnYearSeq[0] + 1;
    nTotalTrapsToProcess = nTotalYears * nIter * nTraps;

    /* Initialise the Random Number Generator to the Mersenne Twister */
    pRandomGenerator = gsl_rng_alloc( gsl_rng_mt19937 );
    /* Seed it with the current time */
    gsl_rng_set( pRandomGenerator, (unsigned long int)time(NULL) );

    /* Do modelling for each year starting at the first in our year sequence */
    /* and going through to the last year */
    for( nYearCount = 0; nYearCount < nYears; nYearCount++ )
    {
        nCurrentYear = pnYearSeq[nYearCount];

        /* do we do surveillance on this year? */
        nCurrentYearIDX = inList( nCurrentYear, pnSurveillanceYearSeq, nSurveillanceYears );
        if( nCurrentYearIDX != -1 )
        {
            /* Create a raster for the total sensitvities */
            /* for this year (accross all iterations) */
            pSensitivityRaster = createRaster( pMaskRaster->nColumns, pMaskRaster->nRows, 
                pMaskRaster->xllcorner, pMaskRaster->yllcorner, pMaskRaster->resolution );

            /* go through each iteration */
            for( nCurrentIteration = 0; nCurrentIteration < nIter; nCurrentIteration++ )
            {

                /* remember kMap is now ARi */
                pThisSensitivity = ProcessAllTrapsForYear( nCurrentYear, pTrapData, nTraps, pParameters,  
                            nChewcardTraps, pRandomGenerator, pSensitivityRaster,
                            pMaskRaster, pKMapRaster, percentCallback, pCallbackData,
                            nProcessedTraps, nTotalTrapsToProcess, &nLastPercentTime, 
                            &dTotalAR, &dAverageSensitivity, &nSearchedCells, pnCallbackValue );

                if( *pnCallbackValue != 0 )
                {
                    /* user cancel */
                    destroyRaster( pSensitivityRaster );
					if( pThisSensitivity != NULL )
					{
						destroyRaster( pThisSensitivity );
					}
                    gsl_rng_free( pRandomGenerator );
                    return 0;
                }

                /* call the callback with the new values */
                *pnCallbackValue = newValues( dTotalAR, dAverageSensitivity, nSearchedCells, nTotalCells, pCallbackData );
                if( *pnCallbackValue != 0 )
                {
                    /* user cancel */
                    destroyRaster( pSensitivityRaster );
                    destroyRaster( pThisSensitivity );
                    gsl_rng_free( pRandomGenerator );
                    return 0;
                }

                /* grab the sensitivity of the current run and add it onto the total */
                addRasters( pSensitivityRaster, pThisSensitivity );

                /* Finished with pThisSensitivity */
                destroyRaster( pThisSensitivity );

                /* for progress */
                nProcessedTraps += nTraps;

                if( pKMapRaster != NULL )
                {
                    /* We have a kmap */
                    /* Equation 5 */
                    dEPIAvg = dPStar * dTotalAR / nSearchedCells;
                    dexpTerm = dEPIAvg * nTotalCells;
                    if( dexpTerm < 1 )
                        dexpTerm = 1;
                    /* Equation 4 */
                    dSystemSensitivity = 1.0 - pow( 1.0 - dAverageSensitivity * (double)nSearchedCells / (double)nTotalCells, dexpTerm );
                }
                else
                {
                    /* no kmap */
                    dexpTerm = dPStar * nTotalCells;
                    if( dexpTerm < 1 )
                        dexpTerm = 1;
                    /* Equation 3 */
                    dSystemSensitivity = 1.0 - pow( 1.0 - dAverageSensitivity * (double)nSearchedCells / (double)nTotalCells, dexpTerm );
                }

                if( nYearCount == 0 )
                {
                    /* Probability of Introduction in the first year */
                    dPrPrior = doBetaPert( pRandomGenerator, dPrior_a, dPrior_b, dPrior_min, dPrior_max, dPrior_range );
                }
                else
                {
                    dPrIntro = doBetaPert( pRandomGenerator, dIntro_a, dIntro_b, dIntro_min, dIntro_max, dIntro_range );
                    /* Equation 2 ?? */
                    dPoFLastYear = rasterGetValue( pPoFMat, nYearCount - 1, nCurrentIteration );
                    dPrPrior = 1.0 - ((( 1.0 - dPoFLastYear ) + dPrIntro ) - ( ( 1.0 - dPoFLastYear ) * dPrIntro ));
                }
                /* Equation 1 */
                dPrOfFreedom = dPrPrior / ( 1.0 - dSystemSensitivity * ( 1.0 - dPrPrior ) );

                rasterSetValue( pSSeMat, nYearCount, nCurrentIteration, dSystemSensitivity );
                rasterSetValue( pPoFMat, nYearCount, nCurrentIteration, dPrOfFreedom );

            } /* iter */

            /* we have just been adding things to pSensitivityRaster so divide */
            /* it by the total number of iterations to get the average for this year */
            divideRasterByConstant( pSensitivityRaster, nIter );

            /* Write out raster for this year */
            if( !rasterWriteToFile( pSensitivityRaster, ppszSensitivityNames[nYearCount] ) )
            {
                *ppszMessage = strdup( "Failed to write output raster" );
                destroyRaster( pSensitivityRaster );
                gsl_rng_free( pRandomGenerator );
                return 0;
            }
            /* finished with it */
            destroyRaster( pSensitivityRaster );

        } /* have surveillance this year */
        else
        {
            /* no surveillance this year */
            if( nYearCount == 0 )
            {
                for( nCurrentIteration = 0; nCurrentIteration < nIter; nCurrentIteration++ )
                {
                    /* Probability of Introduction in the first year */
                    dPrPrior = doBetaPert( pRandomGenerator, dPrior_a, dPrior_b, dPrior_min, dPrior_max, dPrior_range );

                    rasterSetValue( pPoFMat, nYearCount, nCurrentIteration, dPrPrior );
                }
            }
            else
            {
                for( nCurrentIteration = 0; nCurrentIteration < nIter; nCurrentIteration++ )
                {
                    dPrIntro = doBetaPert( pRandomGenerator, dIntro_a, dIntro_b, dIntro_min, dIntro_max, dIntro_range );
                    /* Equation 2 ?? */
                    /* go through each iteration for last year and do it based on that */
                    dPoFLastYear = rasterGetValue( pPoFMat, nYearCount - 1, nCurrentIteration );
                    dPrPrior = 1.0 - ((( 1.0 - dPoFLastYear ) + dPrIntro ) - ( ( 1.0 - dPoFLastYear ) * dPrIntro ));
                    /* why prior? */
                    rasterSetValue( pPoFMat, nYearCount, nCurrentIteration, dPrPrior );
                }
            }
            /* create dummy raster */
            pSensitivityRaster = createRaster( pMaskRaster->nColumns, pMaskRaster->nRows, 
                pMaskRaster->xllcorner, pMaskRaster->yllcorner, pMaskRaster->resolution );

            if( !rasterWriteToFile( pSensitivityRaster, ppszSensitivityNames[nYearCount] ) )
            {
                *ppszMessage = strdup( "Failed to write output raster" );
                destroyRaster( pSensitivityRaster );
                gsl_rng_free( pRandomGenerator );
                return 0;
            }
            /* finished with it */
            destroyRaster( pSensitivityRaster );
        }

    } /* year */

    /* Free the random generator */
    gsl_rng_free( pRandomGenerator );

    /* Make sure they get a 100% */
    *pnCallbackValue = percentCallback( 100, pCallbackData );
    if( *pnCallbackValue != 0 )
        return 0;

    return 1;
}
