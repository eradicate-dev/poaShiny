
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "raster.h"
#include "types.h"
#include "fileio.h"
#include "maskutils.h"

#ifdef _WIN32
   /* Windows has a different name */
   #define strdup _strdup
#endif

int main(int argc, char *argv[])
{
char *pszTraps, *pszKMap, *pszMask, *pszOutMask, *pszYearSeq, *pszCurrent, *pszOutKMap;
int nMinK, nYears, *pnYearSeq, nCurrentYear;
double dDistance;
struct sRaster *pKMap;
struct sMaskRaster *pMask;
int *pnSurveillanceYearSeq, nSurveillanceYears;
int nTraps;
struct sTrapData *pTrapData;
char *pszMessage;

	if( argc != 9 )
	{
		fprintf( stderr, "usage: masktest traps yearseq kmap mask minK distance outmask outkmap\n" );
		return 1;
	}
	
	pszTraps = argv[1];
	/* year seq down below... */
	pszKMap = argv[3];
	pszMask = argv[4];
	nMinK = atol(argv[5]);
	dDistance = atof(argv[6]);
	pszOutMask = argv[7];
    pszOutKMap = argv[8];

	pszYearSeq = strdup(argv[2]);
    /* Turn pszYearSeq into an array of ints */
    /* First work out how many there are */
    /* strtok actually embeds \0's in the string */
    /* so we can't parse it twice so we take a copy */
    nYears = 0;
    pszCurrent = strtok( pszYearSeq, "," );
    while( pszCurrent != NULL )
    {
        pszCurrent = strtok( NULL, "," );
        nYears++;
    }
    free( pszYearSeq );
    pszYearSeq = strdup(argv[2]);
    /* now allocate memory and populate it */
    pnYearSeq = calloc( nYears, sizeof( int ) );
    nCurrentYear = 0;
    pszCurrent = strtok( pszYearSeq, "," );
    while( pszCurrent != NULL )
    {
        pnYearSeq[nCurrentYear] = atol( pszCurrent );
        pszCurrent = strtok( NULL, "," );
        nCurrentYear++;
    }
    free( pszYearSeq );

	pKMap = createRasterFromFile(pszKMap);
	if( pKMap == NULL )
	{
		fprintf( stderr, "Unable to open %s\n", pszKMap );
		exit(1);
	}
	pMask = createMaskRasterFromFile(pszMask);
	if( pMask == NULL )
	{
		fprintf( stderr, "Unable to open %s\n", pszMask );
		exit(1);
	}

    /* read in the data files */
    nTraps = readTrapCSV( pszTraps, &pTrapData, &pnSurveillanceYearSeq, 
                            &nSurveillanceYears, &pszMessage );
    if( nTraps == 0 )
    {
        fprintf( stderr, "Unable to read trap csv file %s. Message was %s\n", pszTraps, pszMessage );
        free( pszMessage );
        exit( 1 );
    }
    
	/* run it */
	maskKMap( pTrapData, nTraps, pnYearSeq, nYears, pKMap, pMask, nMinK, dDistance );

	/* write out */
	maskRasterWriteToFile( pMask, pszOutMask);
    rasterWriteToFile( pKMap, pszOutKMap);

    /* free memory */
    free( pTrapData );
	free( pnSurveillanceYearSeq );
	free(pnYearSeq);
	destroyMaskRaster(pMask);
	destroyRaster( pKMap);
    return 0;
}
