#!/usr/bin/env python

import os
from proofofabsence import postProcessing

######################
# Main function
def main():
    # datapath
    inputDataPath = os.path.join(os.getenv('POFPROJDIR', default = '.'), 'poa', 'Mahia', 
            'Data')
    outputDataPath = os.path.join(os.getenv('POFPROJDIR', default = '.'), 'poa', 'Mahia', 
            'Results', 'Model_0')

#    inputResultsPath = os.path.join(inOutDataPath, 'Model_0')

    ## Specify the label on y-axis of the probability of 'absence/below thres' plot
    probabilityName = 'Probability of absence'
    timeName = 'Sessions'
    targetPoA = 0.95
    priorTime = '0'

    preProcessingResults = 'spatialData.pkl'
    calculationResults = 'resultData.pkl'
    zoneShapeFName = os.path.join(inputDataPath, 'extent_block1.shp')

    SSePoFResultTableName = 'PofSseResultTable.txt'
    pofSSeGraphName = 'PoF_SSe_Graph.png'

    zoneSeResultTableName = 'zoneSeResultTable.txt'

        
    results = postProcessing.ResultsProcessing(inputDataPath, outputDataPath, 
                preProcessingResults, calculationResults, zoneShapeFName,
                SSePoFResultTableName, pofSSeGraphName, zoneSeResultTableName)

    # make results table and plot to screen
    results.makeTableFX(timeName)
    # write result table to directory
    results.writeToFileFX(SSePoFResultTableName, timeName)

    
    if results.calcdat.params.multipleZones:
        ## MAKE TABLE WITH SENSITIVITIES OF ZONES AND WRITE TO DIRECTORY
        results.makeZoneTableFX()
        results.writeZoneTableToFileFX(zoneSeResultTableName, timeName)

    # make pngs
    results.plotMeanSeUAllYears()
    results.plotRelRisk()

    # plot pof and sse over time and write to directory
    results.plotFX(pofSSeGraphName, probabilityName, timeName, targetPoA, priorTime)




    ##### OPTIONAL FUNCTIONS
    # get axis labels for 2-D plots (below)
#    results.getEastingsNorthings()
    # plot 2-d images of the yearly mean seu
#    results.plotMeanSeUTuiview()
    # plot updated relative risk map
#    OLD FX    self.plotRelRisk()
#    results.plotRelRiskTuiview()
    ##########################
    
if __name__ == '__main__':
    main()
                    
