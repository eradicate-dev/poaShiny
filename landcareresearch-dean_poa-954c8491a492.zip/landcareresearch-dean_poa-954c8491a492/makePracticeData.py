#!/usr/bin/env python

########################################
########################################
# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

# IMPORT MODULES
import os
import numpy as np
import pickle
import tempfile
from osgeo import gdal
from osgeo import ogr
from osgeo import osr
from osgeo import gdalconst
from numba import jit

def getPickleResults(inPKL_Name):
    """
    unpickle results from preProcessing.py and calculation.py
    """
    # unpickle preprocessing
    fileobj = open(inPKL_Name, 'rb')
    outObject = pickle.load(fileobj)
    fileobj.close()
    return(outObject)


@jit
def dogLureOneMultinom(riskMask, dogArr, lureArr, nlure, ndogs, 
        nRiskSites, nrows, ncols):
    """
    draw multinom variates where only 1 can be drawn
    """
    trialsRemain = nRiskSites
    nsurveys = nlure + ndogs
    nRemain = nsurveys
    sumProbsUsed = 0.0
    probDogSurvey = ndogs / nsurveys
    prob = 1.0 / nRiskSites
    for f in range(nrows):
        for g in range(ncols):
            if riskMask[f, g]:
                prob_fg = prob / (1.0 - sumProbsUsed)
                prob_fg = 1.0 - (1.0 - prob_fg)**nRemain
                if nRemain == trialsRemain:
                    X_fg = 1
                else:
                    X_fg = np.random.binomial(1, prob_fg)
                if X_fg == 1:
                    dogSurvey = np.random.binomial(1, probDogSurvey)
                    if dogSurvey == 1:
                        dogArr[f, g] = dogSurvey
                    else:
                        lureArr[f, g] = 1
                sumProbsUsed += prob
                nRemain -= X_fg
                trialsRemain -= 1
    return(dogArr, lureArr)

@jit
def rand2DMultinom(riskMask, surveyArr, nsurveys, 
        nRiskSites, nrows, ncols):
    """
    draw multinom variates where only 1 can be drawn
    """
    trialsRemain = nRiskSites
    nRemain = nsurveys
    sumProbsUsed = 0.0
    prob = 1.0 / nRiskSites
    for f in range(nrows):
        for g in range(ncols):
            if riskMask[f, g]:
                prob_fg = prob / (1.0 - sumProbsUsed)
                prob_fg = 1.0 - (1.0 - prob_fg)**nRemain
                if nRemain == trialsRemain:
                    X_fg = 1
                else:
                    X_fg = np.random.binomial(1, prob_fg)
                if X_fg == 1:
                    surveyArr[f, g] = 1
                sumProbsUsed += prob
                nRemain -= X_fg
                trialsRemain -= 1
    return(surveyArr)


@jit
def reviseRRNumba(relRiskRevised, rrBoolian, nrows, ncols):   
    """
    assign variable values to risk cells
    """
#    randChoice = np.array([1, 10, 100])
    for f in range(nrows):
        for g in range(ncols):
            if rrBoolian[f, g]:
                # doesn't seem to work in old Numba
#                relRiskRevised[f, g] = np.random.choice(randChoice, 1)
                # work around for old Numba
                change1 = np.random.binomial(1, 0.5)        # increase from 1
                if change1 == 1:
                    change2 = np.random.binomial(1, 0.5)    # change to 100
                    if change2 == 1:
                        relRiskRevised[f, g] = 100
                    else:
                        relRiskRevised[f, g] = 10
    return(relRiskRevised)


class MakeData(object):
    def __init__(self, inOutDataPath):
        """
        Object to read in RR map and make example grid surveillance
        An example of public surveillance or green-waste treatment
        """
        self.resol = 10.0
        self.epsg = 28355

        ##############  RUN FUNCTIONS
        self.readInData(inOutDataPath)
        self.makeMaskAndExtent()
        self.makeRelativeRiskTif()
        self.makeEmptyArrays()
        self.populateDogLureSurveys()
        self.populatePublic()
        self.populateGreen()
        self.writeSurveyTable()
#        self.wrapReviseRR()
        #############################

    def readInData(self, inOutDataPath):
        """
        Read in shape and RR raster
        """
        self.inOutDataPath = inOutDataPath
#        rrFName = os.path.join(self.inOutDataPath, 'EARiskImg.tif')
#        print('path: ', self.inOutDataPath, 'rrFName', rrFName)

#        self.relRisk = gdal.Open(rrFName).ReadAsArray()
        ## Read ext shape, write tmp tif, read in tif as raster
        self.extentFName = os.path.join(inOutDataPath, 'EAModelExtent.shp')

    def makeMaskAndExtent(self):
        """
        Use extent shapefile to make global mask
        """
        # Get layer dimensions of extent shapefile
        self.getShapefileDimensions(definition=False)
        # get number of columns and rows and set transformation
        self.setGeoTrans()
        # create extent raster tiff
        dataset = ogr.Open(self.extentFName)
        extent_layer = dataset.GetLayer()
        # Temporary Extent tif name and directory
        self.extentOutputFName = os.path.join(self.inOutDataPath, 'tempExtent.tif')
        extent_ds = gdal.GetDriverByName('GTiff').Create(self.extentOutputFName, self.cols,
                            self.rows, 1, gdal.GDT_Byte)
        extent_ds.SetGeoTransform(self.match_geotrans)
        # get spatial reference
        sr = osr.SpatialReference()
        sr.ImportFromEPSG(self.epsg)
        self.wkt = sr.ExportToWkt()
        extent_ds.SetProjection(self.wkt)
        band = extent_ds.GetRasterBand(1)
        NoData_value = -9999
        band.SetNoDataValue(NoData_value)
        # Rasterize Extent and write to directory
        gdal.RasterizeLayer(extent_ds, [1], extent_layer, burn_values=[1])
        extent_ds.FlushCache()
        del dataset
        del extent_layer
        # read in extent mask
        self.extMask = gdal.Open(self.extentOutputFName).ReadAsArray()

    def getShapefileDimensions(self, definition=False):
        """
        get x and y min and max from shapefile
        """
        dataset = ogr.Open(self.extentFName)
        layer = dataset.GetLayer()
        # print out definitions optional
        if definition:
            getShapeLayerDefinition(layer)
        # get dimensions
        (self.xmin, self.xmax, self.ymin, self.ymax) = layer.GetExtent()
        del dataset
        del layer

    def setGeoTrans(self):
        """
        #### get dimensions that incorporate both extent shape and farm boundaries
        """
        self.cols = int((self.xmax - self.xmin) / self.resol)
        self.rows = int((self.ymax - self.ymin) / self.resol)
        self.match_geotrans = [self.xmin, self.resol, 0, self.ymax, 0,
                               -self.resol]
        print('cols', self.cols, 'rows', self.rows)


    def makeRelativeRiskTif(self):
        """
        read in rel risk ascii, and write relative risk Tiff to directory
        """
#        self.relriskFname = relativeRiskFName
        rrFName = os.path.join(self.inOutDataPath, 'EARiskImg.tif')
        rrTmpOutFName = os.path.join(self.inOutDataPath, 'EARR_Tmp.tif')

        # Source - Kmap
        RR_src = gdal.Open(rrFName, gdalconst.GA_ReadOnly)
        # write kmap array to tif in directory
        # temp kmap tif name and directory
#        self.relriskOutName = relRiskRasterOutFName
#        self.temp_RelRisk_extent = self.outputdatapath + relRiskRasterOutFName
        dst = gdal.GetDriverByName('GTiff').Create(rrTmpOutFName, self.cols, self.rows,
                            1, gdalconst.GDT_Float32)
        dst.SetGeoTransform(self.match_geotrans)
        # spatial reference from making extent mask
        dst.SetProjection(self.wkt)
        # Reproject the kmap to the dimensions of the extent
        gdal.ReprojectImage(RR_src, dst, self.wkt, self.wkt, gdalconst.GRA_Bilinear)
        del dst  # Flush
        del RR_src
        # read in RR map 
        self.relRisk = gdal.Open(rrTmpOutFName).ReadAsArray()
        self.rrBoolian = self.relRisk > 0.0
        self.nRiskCells = np.sum(self.rrBoolian)
        print('sum', self.nRiskCells)


    def makeEmptyArrays(self):
        """
        make empty arrays
        """
        tmpNames = ['dog', 'lure', 'public', 'green']
        surveyMeans = np.array([0.90, 0.50, 0.05, 0.005])
        surveySD = np.array([0.10, 0.10, 0.03, 0.003])
        self.dogYears = np.arange(2017, 2021, dtype = int)
        self.lureYears = np.arange(2017, 2021, dtype = int)
        self.publicYears = np.arange(2017, 2020, dtype = int)
        self.greenYears = np.array([2018, 2019])
        nameDict = {'self.dogYears' : self.dogYears,
            'self.lureYears' : self.lureYears,
            'self.publicYears' : self.publicYears,
            'self.greenYears' : self.greenYears}
        self.gridNames = np.array([], dtype = str)
        self.gridYears = np.array([], dtype = int)
        self.gridMeans = np.array([], dtype = float)
        self.gridSD = np.array([], dtype = float)
        # loop through survey types
        for i in range(len(tmpNames)):
            nameSelf = 'self.' + tmpNames[i] + 'Years'
            years_i = nameDict[nameSelf]
            if np.isscalar(years_i):
                nYears = 1
            else:    
                nYears = len(years_i)
            # loop through years in survey type i
            for j in range(nYears):
                yr_ij = years_i[j]
                surveyTifName = tmpNames[i] + str(yr_ij) + '.tif'
                self.gridNames = np.append(self.gridNames, surveyTifName)
                self.gridYears = np.append(self.gridYears, yr_ij)
                self.gridMeans = np.append(self.gridMeans, surveyMeans[i])
                self.gridSD = np.append(self.gridSD, surveySD[i])                 
        print('gridYears', self.gridYears)

    def writeSurveyTable(self):
        """
        write *.csv of survey details to directory
        """
        dataTypes = [('gridName', 'U16'), ('year', 'i8'), ('mean', 'f8'),
            ('sd', 'f8')]
        gridSurvey = np.empty(len(self.gridYears), dtype=dataTypes)
        gridSurvey['gridName'] = self.gridNames
        gridSurvey['year'] = self.gridYears
        gridSurvey['mean'] = self.gridMeans
        gridSurvey['sd'] = self.gridSD
        gridPathFN = os.path.join(self.inOutDataPath, 'practiceGrids.csv')
        np.savetxt(gridPathFN, gridSurvey, delimiter=',', fmt=['%s', '%3i', 
            '%.3f', '%.3f'], header='gridName, year, mean, sd', comments='')


    def populateDogLureSurveys(self):
        """
        make dog and lure survey arrays and write to directory
        """
        nYears = len(self.dogYears)
        nlure = 232500
        ndogs = 457500
        for i in range(nYears):
            print('dog and lure year', self.dogYears[i])
            dogArray = np.zeros_like(self.extMask)
            lureArray = np.zeros_like(self.extMask)
            (dogArray, lureArray) = dogLureOneMultinom(self.rrBoolian,
                dogArray, lureArray, nlure, ndogs, self.nRiskCells, 
                self.rows, self.cols)
            dogFName = 'dog' + str(self.dogYears[i]) + '.tif'
            lureFName = 'lure' + str(self.dogYears[i]) + '.tif'
            dogPathFN = os.path.join(self.inOutDataPath, dogFName)
            lurePathFN = os.path.join(self.inOutDataPath, lureFName)
            self.writeTif(dogArray, dogPathFN, gdt_type = gdal.GDT_Byte)
            self.writeTif(lureArray, lurePathFN, gdt_type = gdal.GDT_Byte)
        print('proportion under active search = ', (nlure + ndogs) / self.nRiskCells)

    def populatePublic(self):
        """
        public survey arrays
        """
        if np.isscalar(self.publicYears):
            nYears = 1
        else:
            nYears = len(self.publicYears)
        prpSearched = 0.40
        nsurveys = np.int(prpSearched * self.nRiskCells)        
        for i in range(nYears):
            print('Public year', self.publicYears[i])
            surveyArr = np.zeros_like(self.extMask)    
            surveyArr = rand2DMultinom(self.rrBoolian, surveyArr, nsurveys, 
                self.nRiskCells, self.rows, self.cols)
            surveyFName = 'public' + str(self.publicYears[i]) + '.tif'
            surveyPathFN = os.path.join(self.inOutDataPath, surveyFName)
            self.writeTif(surveyArr, surveyPathFN, gdt_type = gdal.GDT_Byte)

    def populateGreen(self):
        """
        green survey arrays
        """
        if np.isscalar(self.greenYears):
            nYears = 1
        else:
            nYears = len(self.greenYears)
        prpSearched = 0.15
        nsurveys = np.int(prpSearched * self.nRiskCells)        
        for i in range(nYears):
            print('green year', self.greenYears[i])
            surveyArr = np.zeros_like(self.extMask)    
            surveyArr = rand2DMultinom(self.rrBoolian, surveyArr, nsurveys, 
                self.nRiskCells, self.rows, self.cols)
            surveyFName = 'green' + str(self.greenYears[i]) + '.tif'
            surveyPathFN = os.path.join(self.inOutDataPath, surveyFName)
            self.writeTif(surveyArr, surveyPathFN, gdt_type = gdal.GDT_Byte)

    def writeTif(self, raster, tempTifName, gdt_type):
        """
        write tif to directory
        """
        # write array to tif in directory
        dst = gdal.GetDriverByName('GTiff').Create(tempTifName, self.cols,
                    self.rows, 1, gdt_type)
        dst.SetGeoTransform(self.match_geotrans)
        dst.SetProjection(self.wkt)
        band = dst.GetRasterBand(1)
        band.WriteArray(raster)
        del dst  # Flush

    def wrapReviseRR(self):
        """
        wrap function to call numba function to revise the RR map
        Write to directory
        """
        relRiskRevised = self.relRisk.copy()
#        (nrows,ncols) = np.shape(relRiskRevised)
        relRiskRevised = reviseRRNumba(relRiskRevised, self.rrBoolian, self.rows,
            self.cols)
        revisedFName = 'revisedRRMap.tif'
        revisedPathFN = os.path.join(self.inOutDataPath, revisedFName)
        self.writeTif(relRiskRevised, revisedPathFN, gdt_type = gdal.GDT_Float32) 

######################
# Main function
def main():
    # datapath
    inOutDataPath = os.getenv('POFPROJDIR') + '/poa/EAPractice/EAPracticeData'   
    # Initiate instance of MakeData
    makeData = MakeData(inOutDataPath)


if __name__ == '__main__':
    main()


