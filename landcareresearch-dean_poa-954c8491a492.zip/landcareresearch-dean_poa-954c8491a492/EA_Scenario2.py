#!/usr/bin/env python

########################################
########################################
# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

import os
import pickle

from proofofabsence import preProcessing
from proofofabsence import params
from proofofabsence import calculation

######################
# Main function
def main():
    ############################################################
    ###################################### USER MODIFY HERE ONLY
    #################################
    # set paths to scripts and data
    inputDataPath = os.path.join(os.getenv('POFPROJDIR'), 'poa', 'EAScenario1', 'EA_Data')

    outputDataPath = os.path.join(os.getenv('POFPROJDIR'), 'poa', 'EAScenario1', 'EA_ResultsScen2')
    if not os.path.isdir(outputDataPath):
        os.mkdir(outputDataPath)

    # set INPUT extent and relative risk file names
    extentShapeFName = os.path.join(inputDataPath, 'EAModelExtent.shp')
    relativeRiskFName = os.path.join(inputDataPath, 'Risk10m.tif')  #'riskEA_10m.tif')
    gridSurvey = os.path.join(inputDataPath, 'gridScenario2.csv')
    # set OUTPUT names for mask and relative risk map
    extentMaskOutFName = os.path.join(outputDataPath, 'extentMask.tif')
    relRiskRasterOutFName = os.path.join(outputDataPath, 'relRiskRaster.tif')

    ############ IF FIRST RUN CONDITION
    # if True, do preprocessing, else skip to calculations
    firstRun = True        # True or False

    # resolution for analysis
    Resolution = 10.0
    # EPSG - PROJECTION SYSTEM
    epsg = 28355    # GDA_1994_MGA_Zone_55

    # Instance of POAParameters class
    myParams = params.POAParameters()
    # number of cpu's from SLURM
    ncpus = int(os.getenv('SLURM_CPUS_PER_TASK', '1'))
    myParams.setNumThreads(ncpus)
    # number of iterations
    myParams.setNumIterations(200)

    ## set years of analysis
    myParams.setYears([1,2,3,4,5,6,7,8])
    ## starting Pu and period rate of Pu increase
    startPu = 1.0
    PuIncreaseRate = 3.0
    myParams.setPu(startPu, PuIncreaseRate)

    ## minimum RR value
    myParams.setMinK(1.0)
    
    ## Set priors and probability of introduction
    myParams.setPrior(0.1, 0.30, 0.6)
    myParams.setIntro(0.002, 0.01, 0.015)

    #####################################   END USER MODIFICATION
    #############################################################
    #############################################################

    print('firstRun = ', firstRun)
    if firstRun:
        # initiate instances of Classes
        rawdata = preProcessing.RawData(extentShapeFName, relativeRiskFName, 
                extentMaskOutFName, relRiskRasterOutFName, Resolution, epsg, 
                None, myParams, gridSurvey)

        print('finish preProcessing')

        myParams.setGridSurvey(rawdata.gridSurveyYears, rawdata.gridSurveyData,
            rawdata.gridSurveyMeans, rawdata.gridSurveySD, rawdata.gridSurveyCodes)

        # make object for pickling spatial data
        pickledat = preProcessing.PickleDat(rawdata)
        # pickle to output directory
        pickleName = os.path.join(outputDataPath, 'spatialData.pkl')
        fileobj = open(pickleName, 'wb')
        pickle.dump(pickledat, fileobj, protocol=4)
        fileobj.close()

    # If preProcessing has already been run (not first run)
    else:
        # unpickle results from preProcessing.py
        PKLFName = os.path.join(outputDataPath, 'spatialData.pkl')
        # unpickle preprocessing
        fileobj = open(PKLFName, 'rb')
        pickledat = pickle.load(fileobj)
        fileobj.close()

        myParams.setGridSurvey(pickledat.gridSurveyYears, pickledat.gridSurveyData,
            pickledat.gridSurveyMeans, pickledat.gridSurveySD, pickledat.gridSurveyCodes)

    
    result = calculation.calcProofOfAbsence(myParams, pickledat.survey, 
                pickledat.extMask, pickledat.relativeRiskRaster, 
                pickledat.match_geotrans, pickledat.wkt, outputDataPath)

    ################################################
    ####################
    # temp for debugging    
#    result.modifiedK = None
#    result.sensitivitiesPerYear = None
#    result.updatedMask = None
    ###################
    ################################################

    ## PRINT INTERMEDIATE RESULTS
#    print(result.intermediateResults)
    ## Pickle results of modelling
    pickleName = os.path.join(outputDataPath, 'resultData.pkl')
    fileobj = open(pickleName, 'wb')
    pickle.dump(result, fileobj, protocol=4)
    fileobj.close()
 
if __name__ == '__main__':
    main()


