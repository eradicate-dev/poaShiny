#!/usr/bin/env python

import os
import pylab as P
import numpy as np
from numba import jit
from scipy.stats.mstats import mquantiles
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy.ma as ma
import pickle


@jit
def calcWeightedMean(randRisk, absolRisk, distWt, halfwinsize):
    """
    return a spatial effect raster se1 from the input raster and mask
    Makes use of distance and K caching (see makeDistArray)
    """
    (ysize, xsize) = absolRisk.shape
    for x in range(xsize):
        for y in range(ysize):
            # offset into dist array - deal with top and left edges
            xdistoff = 0
            ydistoff = 0
            # top left x
            tlx = x - halfwinsize
            if tlx < 0:
                xdistoff = -tlx
                tlx = 0
            tly = y - halfwinsize
            if tly < 0:
                ydistoff = -tly
                tly = 0
            brx = x + halfwinsize
            if brx > xsize - 1:
                brx = xsize - 1
            bry = y + halfwinsize
            if bry > ysize - 1:
                bry = ysize - 1
            sumWtRisk = 0.0
            sumWt = 0.0
            #print(x, y, tlx, brx, tly, bry)
            for cx in range(tlx, brx+1):
                for cy in range(tly, bry+1):
                    wt = distWt[ydistoff + cy - tly, xdistoff + cx - tlx]
                    sumWtRisk += randRisk[cy, cx] * wt
                    sumWt += wt
            absolRisk[y, x] = sumWtRisk / sumWt
    return absolRisk


@jit
def drawOneMultinom_1D(randArr, prob, nsuccess, nArray, extentSide):
    """
    draw multinom variates where only 1 can be drawn
    """
    trialsRemain = nArray
    nRemain = nsuccess
    prob0 = prob[0]
    X_i = np.random.binomial(1, prob0)
    randArr[0] = X_i
    nRemain -= X_i
    trialsRemain -= 1
    sumProbsUsed = prob0
    for i in range(1, nArray):
        prob_i = prob[i] / (1 - sumProbsUsed)
        if nRemain == trialsRemain:
            X_i = 1
        else:
            X_i = np.random.binomial(1, prob_i)
        sumProbsUsed += prob[i]
        randArr[i] = X_i
        nRemain -= X_i
        trialsRemain -= 1
    return(randArr)


@jit
def drawOneMultinom(randArr, prob, nsurveys, nRiskSites, extentSide, adjustRisk, riskMask):
    """
    draw multinom variates where only 1 can be drawn
    """
    trialsRemain = nRiskSites
    nRemain = nsurveys
    sumProbsUsed = 0.0
    sumAdjustRisk = 0.0
    for f in range(extentSide):
        for g in range(extentSide):
            if riskMask[f, g]:
                prob_fg = prob[f, g] / (1.0 - sumProbsUsed)
                prob_fg = 1.0 - (1.0 - prob_fg)**nRemain
                if nRemain == trialsRemain:
                    X_fg = 1
                else:
                    X_fg = np.random.binomial(1, prob_fg)
                if X_fg == 1:
                    sumAdjustRisk += adjustRisk[f, g]
                sumProbsUsed += prob[f, g]
                randArr[f, g] = X_fg
                nRemain -= X_fg
                trialsRemain -= 1
    return(randArr, sumAdjustRisk)

@jit
def drawOneRandom(randArr, prob, nsurveys, nRiskSites, extentSide, 
        adjustRisk, riskMask, maxNSurveys):
    """
    draw multinom variates where only 1 can be drawn
    """
    trialsRemain = nRiskSites
    nRemain = nsurveys
    sumProbsUsed = 0.0
    sumAdjustRisk = 0.0
    probRandom = 1.0 / maxNSurveys
    for f in range(extentSide):
        for g in range(extentSide):
            if riskMask[f, g]:
                prob_fg = probRandom / (1.0 - sumProbsUsed)
                prob_fg = 1.0 - (1.0 - prob_fg)**nRemain
                if nRemain == trialsRemain:
                    X_fg = 1
                else:
                    X_fg = np.random.binomial(1, prob_fg)
                if X_fg == 1:
                    sumAdjustRisk += adjustRisk[f, g]
                sumProbsUsed += probRandom
                randArr[f, g] = X_fg
                nRemain -= X_fg
                trialsRemain -= 1
    return(sumAdjustRisk)



@jit
def runSimulation(iter, nprior, prior, nrow, prp, nRiskSites, randArr, prob, extentSide,
        adjustedRisk, pStar, ncol, seSurvey, resultsPoE_3D, riskMask, maxNSurveys,
        randPoE, randColumn):
    """
    calc sse and pof using params
    """
    # loope iter
    for i in range(iter):
        #loop priors
        for j in range(nprior):
            prior_j = prior[j]
            # loop proportion surveyed
            for k in range(nrow):
                prp_k = prp[k]
                # select sites to survey
                nsurveys = np.int64(prp_k * nRiskSites)
                if nsurveys > maxNSurveys:
                    nsurveys = maxNSurveys
                (randArray, sumAdjustRisk) = drawOneMultinom(randArr, prob, nsurveys, nRiskSites, 
                    extentSide, adjustedRisk, riskMask)
                epiAve = pStar * sumAdjustRisk / nsurveys  
                for l in range(ncol):
                    SeU = seSurvey[l]
                    SSe = 1.0 - (1.0 - SeU * prp_k)**(epiAve * nRiskSites)
                    PoE = (1.0 - prior_j) / (1.0 - (SSe * prior_j))
                    resultsPoE_3D[j, k, l] += PoE
                    ##### if run test of random sampling
                    if (l == randColumn) & (j == 0):
                        randPoE[k] += randSamp(randArr, prob, nsurveys, nRiskSites, 
                            extentSide, adjustedRisk, riskMask, maxNSurveys, pStar, 
                            SeU, prp_k, prior_j)
                    ##### end random sampling test
    return(resultsPoE_3D,randPoE)


@jit
def randSamp(randArr, prob, nsurveys, nRiskSites, extentSide, adjustedRisk, 
            riskMask, maxNSurveys, pStar, SeU, prp_k, prior_j):
    """
    if specified se value sample landscape randomly and store POE
    """
    sumAdjustRiskRand = drawOneRandom(randArr, prob, nsurveys, 
        nRiskSites, extentSide, adjustedRisk, riskMask, maxNSurveys)
    epiAveRand = pStar * sumAdjustRiskRand / nsurveys
    SSeRand = 1.0 - (1.0 - SeU * prp_k)**(epiAveRand * nRiskSites)
    randPoETmp = (1.0 - prior_j) / (1.0 - (SSeRand * prior_j))
    return(randPoETmp)



class Params():
    def __init__(self):
        """
        set parameters for simulation
        """
        self.iter = 500
        self.prior = np.array([0.10, 0.20, 0.35, 0.50])
        self.nprior = len(self.prior)
        self.seSurvey = np.linspace(0.4, .99, num = 300)
        self.prp = np.linspace(0.99, 0.4, num = 300)
        self.extentSide = 100
        self.nHabitatCells = self.extentSide**2
        self.rrMean = 3.0
        self.var = 2.65     # 3.05              # covariance variance 
        self.rho = 3.0              # decay parameter
        self.winsize = 7
        self.halfwinsize = int(self.winsize / 2)
        # file name of pickled results
        self.simoutFname = 'bsalContain_out.pkl'
        psemask = (self.seSurvey > .749) & (self.seSurvey < .75)
        prpmask = (self.prp > .749) & (self.prp < .75)
        nseq = np.arange(300)
        self.randColumn = np.int(nseq[psemask])
        print('randCol', self.randColumn)
        print('se seq', nseq[psemask],
            'prp seq', nseq[prpmask])
        print('se', self.seSurvey[psemask], 'prp', self.prp[prpmask])

class SimData():
    def __init__(self, params):
        """
        class to assess SSe and PoF
        """
        ##########################
        ##  Run functions
        self.setUpDataArrays(params)
        self.makeDistArray()
        self.absolRisk = calcWeightedMean(self.randRisk, self.absolRisk, 
                self.distWt, self.params.halfwinsize)
        self.calcRR()
        self.plotRR()

        ### Run Simulation and plot results     #################
        (self.resultsPoE_3D, self.randPoE) = runSimulation(self.params.iter, 
            self.params.nprior, self.params.prior, 
            self.nrow, self.params.prp, self.nRiskSites, self.randArr, self.riskMultinomProb, 
            self.params.extentSide, self.adjustedRisk, self.pStar, self.ncol, self.params.seSurvey, 
            self.resultsPoE_3D, self.riskMask, self.maxNSurveys, self.randPoE, 
            self.params.randColumn)
        self.getImPlotLabels()
        self.plotPoE()
        self.plotResultRR()


        ## End running functions
        ##########################

    def setUpDataArrays(self, params):
        """
        set up data, parameters and arrays
        """
        self.params = params
        self.ncol = len(self.params.seSurvey)
        self.nrow = len(self.params.prp)
        ###### Result Arrays
        self.randPoE = np.zeros(self.ncol)
        self.resultsPoE_3D = np.zeros((self.params.nprior, self.nrow, self.ncol))
        #### make empty absolute risk raster
        self.absolRisk = np.zeros((self.params.extentSide, self.params.extentSide))
        self.randRisk = np.random.gamma(.01, 500., (self.params.extentSide, self.params.extentSide))

        
    def makeDistArray(self):
        """
        Pre calculate this so we don't have to do it each time
        """
        self.distWt = np.empty((self.params.winsize, self.params.winsize))   #, np.int)
        for x in range(self.params.winsize):
            for y in range(self.params.winsize):
                distx = (x - self.params.halfwinsize)
                disty = (y - self.params.halfwinsize)
                dist = np.sqrt(distx*distx + disty*disty)
                self.distWt[y, x] = np.exp(-(dist**2.0) / 2.0 / self.params.rho**2)
#        print('distWt', self.distWt[:, :6], np.shape(self.distWt))

    def calcRR(self):
        """
        calc rel risk values from absolute values
        """
        quantLevels = mquantiles(self.absolRisk, prob=[0.25])
        self.absolRisk[self.absolRisk <= quantLevels] = np.nan
        min = np.nanmin(self.absolRisk)
        self.relRisk = self.absolRisk / min
        self.riskMultinomProb = self.relRisk / np.nansum(self.relRisk)
        self.riskMask = (1 - np.isnan(self.relRisk)) == 1
        self.maxNSurveys = np.nansum(self.riskMask)
        self.randArr = np.zeros((self.params.extentSide, self.params.extentSide), dtype = int)
        self.nRiskSites = np.sum(self.riskMask)
        self.sumRelRisk = np.nansum(self.relRisk)
        self.adjustedRisk = self.nRiskSites * self.relRisk / self.sumRelRisk
        self.pStar = 1.0 / self.nRiskSites
    
    def getRRCutOff(self):
        """
        get cutoff RR value for each prp using top RR values
        """
        self.nSearchTop = np.int64(self.prp * self.nRiskSites)        
        self.quantTop = .999

    def getRRPlotLabels(self):
        """
        get axes and labels
        """
        self.xticks = np.array([10, 30, 50, 70, 90])
        self.yticks= np.array([90, 70, 50, 30, 10])
        self.brx = np.max(self.xticks)
        self.tlx = np.min(self.xticks)
        self.tly = np.max(self.yticks)
        self.bry = np.min(self.yticks)
        self.extent = ([(self.tlx - 9), (self.brx + 9),
            (self.bry - 9), (self.tly + 9)])

    def plotRR(self):
        """
        plot 2-D image of relative risks
        """
        self.getRRPlotLabels()
        P.figure(figsize=(12,12))
        raster = self.relRisk.copy()
        minRast = np.nanmin(raster)
        maxRast = np.nanmax(raster)
        print('min and max', minRast, maxRast)
        raster_masked_array = np.ma.masked_where(np.isnan(raster), raster)
        cmap = P.cm.jet
        cmap.set_bad('w', 1.)
        ax = P.gca()
        P.xticks(self.xticks, fontsize = 12)
        P.yticks(self.yticks, fontsize = 12)
        # image plot - all elements arguments are important
        imgplot = ax.imshow(raster_masked_array, cmap=cmap, extent = self.extent,
            interpolation = 'none')
        plotTit = 'Relative risk values'
#        P.title(plotTit, fontsize=14)
        P.xlabel('Eastings units', fontsize = 14)
        P.ylabel('Northings units', fontsize = 14)
        imgplot.set_clim(minRast, maxRast)
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="3%", pad=0.075)
        cbar = P.colorbar(imgplot, cax=cax)
        imgplot.set_clim(minRast, maxRast)
        cbar.ax.tick_params(labelsize=10)
        P.tight_layout(pad=.75, w_pad=.75)
        P.savefig('bsalRelRisk.png', format='png')
        P.show()

    def getImPlotLabels(self):
        """
        get axes and labels
        """
        self.resultsPoE_3D = self.resultsPoE_3D / self.params.iter
        self.xticks = np.array([0.5, 0.6, 0.7, 0.8, 0.9])
        self.yticks= np.array([0.9, 0.8, 0.7, 0.6, 0.5])
        self.brx = np.max(self.xticks)
        self.tlx = np.min(self.xticks)
        self.tly = np.max(self.yticks)
        self.bry = np.min(self.yticks)
        self.extent = ([(self.tlx - 0.09), (self.brx + 0.09),
            (self.bry - 0.09), (self.tly + 0.09)])
#        print('xticks', self.xticks, self.yticks, self.extent)
        self.titlePoE = np.array(['A.', 'B.', 'C.', 'D.'])

    def plotPoE(self):
        """
        plot 2-D image of pof
        """
        P.figure(figsize=(12,12))
        minRast = np.nanmin(self.resultsPoE_3D)
        maxRast = np.nanmax(self.resultsPoE_3D)
        print('poe .7, .7', self.resultsPoE_3D[:, 152, 147])
        for i in range(self.params.nprior):
            P.subplot(2, 2, i+1)
            raster = self.resultsPoE_3D[i]
            raster_masked_array = np.ma.masked_where(np.isnan(raster), raster)
            cmap = P.cm.jet
            cmap.set_bad('w', 1.)
            ax = P.gca()
            P.xticks(self.xticks, fontsize = 12)
            P.yticks(self.yticks, fontsize = 12)
            # image plot - all elements arguments are important
            imgplot = ax.imshow(raster_masked_array, cmap=cmap, extent = self.extent,
                interpolation = 'none')
            plotTit = self.titlePoE[i]
            P.title(plotTit, loc = 'left', fontsize=17)
            if np.in1d(i, [2,3]):
                P.xlabel('Surveillance-unit sensitivity', fontsize = 14)
            if np.in1d(i, [0,2]):
                P.ylabel('Proportion of risk areas searched', fontsize = 14)
            quantLevels = [0.95]
            ContLines = P.contour(raster, levels = quantLevels, linewidths=2, extent = self.extent,
                   origin = 'upper', colors='k')
            divider = make_axes_locatable(ax)
            cax = divider.append_axes("right", size="3%", pad=0.075)
            cbar = P.colorbar(imgplot, cax=cax)
            imgplot.set_clim(minRast, maxRast)
            cbar.ax.tick_params(labelsize=10)
        P.tight_layout(pad=.75, w_pad=.75)
        P.savefig('bsalPofContain2.png', format='png')
        P.show()



    def plotResultRR(self):
        """
        plot PoE across prp for random and RR selection of su
        """
        self.randPoE = self.randPoE / self.params.iter
        self.rrPoE = self.resultsPoE_3D[0, :, self.params.randColumn]
        P.figure(figsize=(14, 11))
        ax1 = P.gca()
        lns1 = ax1.plot(self.params.prp, self.randPoE, color = 'k', label = 'Random Selection', linewidth = 2.0)
        lns2 = ax1.plot(self.params.prp, self.rrPoE, color = 'k', label = 'Priority Selection', 
            linewidth = 4.0)
        lns3 = ax1.axhline(y = .95, color='k', label = 'Target probability',
            ls='dashed', linewidth = 2.0)


        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax1.legend(lns, labs, loc = 'upper left')
        ax1.set_ylim([0.90, 1.0])
        for tick in ax1.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax1.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        ax1.set_xlabel('Proportion searched', fontsize = 17)
        ax1.set_ylabel('Probability of absence', fontsize = 17)
        P.savefig('bsal_PoE_Rand_overPrp.png', format='png')
        P.show()





########            Main function
#######
def main():
    params = Params()


    simobj = SimData(params)

#    simout = SimOut(params, simobj)

    # pickle results
#    fileobj = open(params.simoutFname, 'wb')
#    pickle.dump(simout, fileobj)
#    fileobj.close()



if __name__ == '__main__':
    main()




