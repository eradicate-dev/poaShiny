library(testthat)
library(proofofabsence)

test_check("proofofabsence")
