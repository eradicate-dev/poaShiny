#!/usr/bin/env python

import os
import pylab as P
import numpy as np
from numba import jit, int64
from scipy import stats
from scipy.stats.mstats import mquantiles


def getBetaFX(Mn, Sd):
    """
    get alpha and beta parameters for beta distribution using mean and sd
    """
    a = Mn * ((Mn * (1.0 - Mn)) / Sd**2.0 - 1.0)
    b = (1.0 - Mn) * ((Mn * (1.0 - Mn)) / Sd**2.0 - 1.0)
    return (a, b)

@jit
def calcPOA(prior, SSe):
    """
    Bayesian calculation of poa 
    """
    poa = prior / (1.0 - (SSe * (1.0 - prior)))
    return(poa)

@jit
def calcKeepCostPoA(iterCost, costKeep_RV, SeKeep_RV, priorKeep_RV,
        nKeepPoA, PoAKeepRange, nPropCost, prpCost, prpKeepSpp2D,
        costKeep2D, meanSppShip):
    """
    Calc cost of keeping ban across range of PoA values
    """
    ## loop thru iterations i
    for i in range(iterCost):
        cost_i = costKeep_RV[i]
        Se_i = SeKeep_RV[i]
        prior_i = priorKeep_RV[i]
        ## loop thru target PoA
        for j in range(nKeepPoA):
            poaTarget_j = PoAKeepRange[j]
            if prior_i >= poaTarget_j:        ## no cost to achieve target PoA.
                continue
            ## loop thru prp until achieve target
            for k in range(nPropCost):
                prp_k = prpCost[k]
                se_ijk = Se_i * prp_k
                poa_ijk = calcPOA(prior_i, se_ijk)
                if poa_ijk >= poaTarget_j:
                    cost_ijk = meanSppShip * prp_k * cost_i 
                    prpKeepSpp2D[i, j] = prp_k
                    costKeep2D[i, j] = cost_ijk
                    continue
                if (prp_k == 1.0) & (poa_ijk < poaTarget_j):
                    prpKeepSpp2D[i, j] = np.nan
                    costKeep2D[i, j] = 'nan'
    return(prpKeepSpp2D, costKeep2D)




class Params():
    def __init__(self):
        """
        set parameters for simulation
        """
        # set paths to scripts and data
        dp = os.getenv('POFPROJDIR')
        if dp is not None:
            self.datapath = os.getenv('POFPROJDIR') + '/bsal'
        else:
            self.datapath = '.'
        self.bsaldataFName = os.path.join(self.datapath, 'bsalData.csv')
        # set parameters
        self.iter = 500
        # priors
        # lift ban prior
        self.liftPriorPara = [0.73, 0.075]    #[0.83, 0.10]
        self.priorLift_Beta = getBetaFX(self.liftPriorPara[0],
            self.liftPriorPara[1]) # mean and sd
        # keep ban prior
        self.banPriorPara = [0.90, 0.075]
        self.priorBan_Beta = getBetaFX(self.banPriorPara[0], self.banPriorPara[1]) # mean and sd  
        # Test sensitivities for keep ban
        self.EDNA_Beta = np.array([0.92, 0.075])    # np.array([0.85, 0.075]) 
        self.seEDNA_Beta = getBetaFX(self.EDNA_Beta[0], self.EDNA_Beta[1])
        self.sePCR_Beta = getBetaFX(0.96, 0.05) # getBetaFX(0.92, 0.05)
        # Test sensitivities for lifting the ban 
        self.seLiftEDNA_Beta = getBetaFX(0.99, 0.025)
        self.seLiftPCR_Beta = getBetaFX(0.99, 0.02) # getBetaFX(0.92, 0.05)
        # number of proportions to assess
        self.nProportions = 80
        self.prp = np.linspace(0.21, 1.0, self.nProportions)
        # proportion of individual risk species to sample
        self.nPrpIndividual = 80
        self.individualPrp = np.linspace(0.21, 1.0, self.nPrpIndividual)
        # cost of tests in dollars for origin-risk species
        self.costEDNA_Normal = np.array([200.0, 20.0]) #mean and sd
        self.costPCR_Normal = np.array([60.0, 10.0])
#        # cost of tests in dollars for origin-risk species
        self.costEDNA_NormalLift = np.array([300.0, 20.0]) #mean and sd
        self.costPCR_NormalLift = np.array([90.0, 10.0])
        self.targetPoA = 0.99       # 0.95
        self.RROriginSpp = np.array([1, 100]) # RR for origin risk and spp risk, respectively


class AnalyseData():
    def __init__(self, params):
        """
        class to assess SSe and PoF
        """
        self.params = params
        ##########################
        ##########################
        ##########################

    def readData(self):
        """
        read in bsal csv data
        """
        bsalDat = np.genfromtxt(self.params.bsaldataFName, delimiter=',', names=True,
            dtype=['int16', 'S10', 'S10', 'S10', 'S10', 'S10', 'S10', 'S10', 'i8',
                 'S10', 'S10', 'S10', 'S10', 'i8', 'S10', 'S10',])      
        # mask out not risk shipments
        reductionMask = ((bsalDat['origin'] == b'EAASIA') | 
            (bsalDat['origin'] == b'SEASIA') | (bsalDat['threat'] == b'Y'))
        # shipments with risk spp or risk origin
        self.sppThreatBool = bsalDat['threat'][reductionMask] == b'Y'
        self.originRiskBool = ((bsalDat['origin'][reductionMask] == b'EAASIA') |
            (bsalDat['origin'][reductionMask] == b'SEASIA'))
        # array of years
        self.years = bsalDat['year'][reductionMask]
        self.nAllDat = len(self.years)
        # number of animals in a shipment
        self.qty = bsalDat['qty'][reductionMask]

    def keepBan(self):
        """
        wrapper function for keeping ban scenario
        """
        self.keepBanData()
        self.poaFX()
        self.costKeepBan()
#        self.plotPoA()
        self.plotCostsPoA()
        self.plotPriors(self.priorsFName)
        self.poaCostTargets()
        
        
    def keepBanData(self):
        """
        get data with risk origins, but not risk species
        """
        maskKeep = self.originRiskBool & (self.sppThreatBool == 0)
        self.yearsScen = self.years[maskKeep]

        self.proportion2D = (np.tile(self.params.prp, 
            self.params.iter).reshape(self.params.iter, self.params.nProportions))
        self.uYears = np.unique(self.yearsScen)

        randSeUAve = np.random.beta(self.params.seEDNA_Beta[0],
            self.params.seEDNA_Beta[1], self.params.iter)
        self.SeUAve2D = (np.repeat(randSeUAve, 
            self.params.nProportions).reshape(self.params.iter, 
            self.params.nProportions))
 
        self.SSe2D = self.SeUAve2D * self.proportion2D

        randPrior =np.random.beta(self.params.priorBan_Beta[0], self.params.priorBan_Beta[1],
            self.params.iter)
        self.prior2D = (np.repeat(randPrior, self.params.nProportions).reshape(self.params.iter,
            self.params.nProportions))

        self.poaImageName = 'keepBanPoA.eps'
        self.priorsFName = 'priorImage.eps'

    def poaFX(self):
        """
        calc poa
        """
        self.poa2D = self.prior2D / (1.0 - (self.SSe2D * (1.0 - self.prior2D)))
        self.poaResults = np.zeros((3, self.params.nProportions))
        self.poaResults[0] = np.mean(self.poa2D, axis = 0)
        self.poaResults[1:] = mquantiles(self.poa2D, prob=[0.025, 0.975], axis = 0)
        exceedTargetMask = self.poaResults[0] >= self.params.targetPoA
        self.minPrpTarget = np.min(self.params.prp[exceedTargetMask])
        print('min Prp required Ban scenario', self.minPrpTarget)

    def costKeepBan(self):
        """
        calc cost to get to target for each year if keep ban - 
        function of number of shipments
        """
        self.nYears = len(self.uYears)
        self.randCost = (np.random.normal(self.params.costEDNA_Normal[0], 
            self.params.costEDNA_Normal[1], self.params.iter))

        print('meanCost 1', np.mean(self.randCost))

        costBan2D = (np.repeat(self.randCost, self.nYears).reshape(self.params.iter, self.nYears))        
        self.nshipments = np.zeros(self.nYears, dtype=int)
        for i in range(self.nYears):
            shp_i = self.yearsScen[self.yearsScen == self.uYears[i]]
            self.nshipments[i] = len(shp_i)
        self.nSurveyed = self.nshipments * self.minPrpTarget
        nSurvey2D = self.nSurveyed.reshape(1, self.nYears) 
        self.cost2D = nSurvey2D * costBan2D
        self.costResults = np.zeros((3, self.nYears))
        self.costResults[0] = np.mean(self.cost2D, axis = 0)
        self.costResults[1:] = mquantiles(self.cost2D, prob=[0.025, 0.975], axis = 0)
#        print('years', self.uYears, 'nshp', self.nshipments)
        
        
    def plotPoA(self):
        """
        plot poa against proportion searched
        """
        P.figure(figsize=(10, 8))

        P.plot(self.params.prp, self.poaResults[0], label='Mean PoA', color='k', linewidth=5)
        P.plot(self.params.prp, self.poaResults[1], label='95% confidence intervals',
               linewidth=2, color='k')
        P.plot(self.params.prp, self.poaResults[2], linewidth=2, color='k')
        P.axhline(y=self.params.targetPoA, label='Target PoA', color='k', ls='dashed')
        miny = np.min(self.poaResults[1]) - .1
        P.ylim([miny, 1.02])
        ax = P.gca()
        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        P.xlabel('Proportion of shipments searched', fontsize=17)
        P.ylabel('Probability of absence', fontsize=17)
        P.legend(loc='lower right')
        figFName = 'proportionPoa.eps'
        poaImagePathFName = os.path.join(self.params.datapath, figFName)
        P.savefig(poaImagePathFName, format='eps', dpi = 1200)
        P.show()



    def plotCostsPoA(self):
        """
        plot poa against across years and number of shipments from risk areas
        """
        P.figure(figsize=(10, 8))
        # save plots to project directory
        costK = self.costResults / 1000.
        ax = P.gca()
        lowCI = costK[0] - costK[1]
        hiCI = costK[2] - costK[0]
        print('costBan', costK)
  
        lns1 = ax.errorbar(self.uYears, costK[0], yerr = [lowCI, hiCI], ecolor = 'black',
            marker = 'o', markerfacecolor = 'black', ms = 3, ls = 'none', mew = 3,
            markeredgecolor = 'black', capsize = 8)
        ax2 = ax.twinx()
        lns4 = ax2.plot(self.uYears, self.nshipments, 'k*', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns4 = tuple(lns4)
        lns5 = ax2.plot(self.uYears, self.nSurveyed, 'ko', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns5 = tuple(lns5)

        P.legend([lns1, lns4, lns5], 
            ["Cost mean and 95% CI", 
            'Total origin-risk shipments',
            'Surveyed origin-risk shipments'], 
            loc='upper right')        

        maxy = np.max(costK[2]) + 20.0
        miny = np.min(costK[1]) - 20.0
        minx = np.min(self.uYears) - 1
        maxx = np.max(self.uYears) + 1
        ax.set_ylim([miny, maxy])
        ax.set_xlim([minx, maxx])
        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        self.getNTicks()

        ax.set_xticks(self.xTicksYr, self.xlabelsYr)
        ax.set_xlabel('Years', fontsize=17)
        ax.set_ylabel('Annual surveillance cost (x $1000)', fontsize=17)
        ax2.set_ylabel('Number of shipments', fontsize = 17)
        y2max = np.max(self.nshipments) + 50
        y2min = np.min(self.nSurveyed) - 50
        
        ax2.set_ylim([y2min, y2max])
        plotFName = 'costByYear.eps'
        poaImagePathFName = os.path.join(self.params.datapath, plotFName)
        P.savefig(poaImagePathFName, format='eps', dpi = 1200)
        P.show()


    def getNTicks(self):
        """
        get n==5 ticks for plot
        """
        if self.nYears <= 5:
            self.byTicks = 1
        else:
            self.byTicks = np.round(self.nYears / 5.0)
        self.xTicksYr = np.arange(self.uYears[0], self.uYears[-1], self.byTicks)
        self.xTicksYr = self.xTicksYr.astype(int)
        self.xlabelsYr = [str(x) for x in self.xTicksYr]

    def plotPriors(self, priorsFName):
        """
        plot priors if keep ban, or eliminate ban
        """
        denRange = np.arange(0.01, 0.999, step = 0.001)
        (a,b) = self.params.priorBan_Beta
        banDensity = stats.beta.pdf(denRange, a, b)
        (c,d) = self.params.priorLift_Beta
        liftDensity = stats.beta.pdf(denRange, c, d)
        P.figure(figsize=(14, 6))
        P.subplot(1, 2, 1)
        P.plot(denRange, banDensity, label='Keep ban', color='k', linewidth=5)
        P.plot(denRange, liftDensity, label='Lift ban', color='k', ls='dashed', linewidth=3)
        P.xlim(0.4, 1.0)
        P.ylim(0.0, 15.0)
        P.title('A.', loc = 'left', fontsize = 17)
        P.xlabel('Prior prob. of no incursion', fontsize=17)
        P.ylabel('Probability density', fontsize=17)
        P.legend(loc='upper left')
        # graph SeU distributions
        (a,b) = self.params.seEDNA_Beta
        banEdnaDensity = stats.beta.pdf(denRange, a, b)
        (c, d) = self.params.seLiftEDNA_Beta
        liftEdnaDensity = stats.beta.pdf(denRange, c, d)
        P.subplot(1, 2, 2)
        P.plot(denRange, banEdnaDensity, label='Keep ban test sensitivity', color='k', linewidth=5)
        P.plot(denRange, liftEdnaDensity, label='Lift ban test sensitivity', color='k', 
            ls='dashed', linewidth=3)
        P.xlim(0.4, 1.0)
        P.ylim(0.0, 15.0)
        P.title('B.', loc = 'left', fontsize = 17)
        P.xlabel('Test sensitivity', fontsize=17)
        P.ylabel('')
        P.legend(loc='upper left')
        # save plots to project directory
        priorImagePathFName = os.path.join(self.params.datapath, priorsFName)
        P.savefig(priorImagePathFName, format='eps', dpi=1200)
        P.show()

    #############
    ### ANALYSIS OF COST OF RANGE OF POA TARGETS
    ### KEEP BAN SCENARIO
    #############


    def poaCostTargets(self):
        """
        ## get cost distribution for range of poa targets
        """
        self.iterCost = 20000
        self.nKeepPoA = 50
        self.nprp = 100        # number of proportions to assess
        self.makeArrays()
        self.getPrpPoaRange()
        self.plotKeepPrpPoA()

#        self.costPoaRange()

    def makeArrays(self):
        """
        ## make arrays, storage arrays, and random variates
        """       
        self.PoAKeepRange = np.linspace((self.params.banPriorPara[0] + 0.01), 
            self.params.targetPoA, self.nKeepPoA) 
        ## get mean number of origin-risk shipments
        self.meanOrigShip = np.mean(self.nshipments)
        ## range of proportions to assess
        self.prpRange1D = np.linspace(0.01, 1.0, self.nprp)
        self.prpRange2D = self.prpRange1D.reshape(1, self.nprp)
        # storage array for min prp
#        self.minPrpPoaResults = np.zeros((3, self.nKeepPoA)) 
        self.minPrpPoaResultsKeep = np.zeros(self.nKeepPoA) 
        ## storage array for cost results: means and 95% CI
        self.costPoaResultsKeep = np.zeros((3, self.nKeepPoA)) 
        ## 2D seu variates
        self.seuRand = np.random.beta(self.params.seEDNA_Beta[0],
            self.params.seEDNA_Beta[1], (self.iterCost, self.nprp))
        ## system sensitivities in 2D
        self.ssePoaRange = self.seuRand * self.prpRange2D
        ## variates of prior for keep scenario
        self.priorPoaRange = np.random.beta(self.params.priorBan_Beta[0], 
            self.params.priorBan_Beta[1], (self.iterCost, self.nprp))


    def getPrpPoaRange(self):

        ## posterior PoA in 2D (iter)
        self.postPoaRange = self.priorPoaRange / ( 1.0 -
            (self.ssePoaRange * (1.0 - self.priorPoaRange)))
        meanPostPoA = np.mean(self.postPoaRange, axis = 0)
        randCost = (np.random.normal((self.params.costEDNA_Normal[0]), 
            self.params.costEDNA_Normal[1], size = self.iterCost) / 1000.0)

        ## loop thru PoA of interest to get proportion needed
        for i in range(self.nKeepPoA):    
            targetMask = meanPostPoA >= self.PoAKeepRange[i]
            minPrp = np.min(self.prpRange1D[targetMask])
            ## distribution of costs from variates of cost
            costArray = randCost * minPrp * self.meanOrigShip

#            print('poa_i', self.PoAKeepRange[i], 'iter_j', j, 'minPrp', minPrp,
#                'costarray', costArray[j])

            self.costPoaResultsKeep[0, i] = np.mean(costArray)
            self.costPoaResultsKeep[1:, i] = mquantiles(costArray, prob= [0.025, 0.975])
#            self.minPrpPoaResults[0, i] = np.mean(prpArray)
#            self.minPrpPoaResults[1:, i] = mquantiles(prpArray, prob= [0.025, 0.975])
            self.minPrpPoaResultsKeep[i] = minPrp
        print('min Cost', np.min(self.costPoaResultsKeep[0]), 
                'maxCost', np.max(self.costPoaResultsKeep[0]),
                'min Prp', np.min(self.minPrpPoaResultsKeep),
                'max Prp', np.max(self.minPrpPoaResultsKeep))

            

    def plotKeepLiftPrpPoA(self):
        P.figure(figsize=(8, 6))
        P.plot(self.PoAKeepRange, self.costPoaResultsKeep[0] , color = 'k', linewidth = 5)
        P.plot(self.PoAKeepRange, self.costPoaResultsKeep[1] , color = 'k', ls='dashed', linewidth =3) 
        P.plot(self.PoAKeepRange, self.costPoaResultsKeep[2] , color = 'k', ls='dashed', linewidth =3) 

        P.xlabel('Probability of absence', fontsize=17)
        P.ylabel('Surveillance cost (x $1000)', fontsize=17)
        plotFName = 'costByPoA.eps'
        poaImagePathFName = os.path.join(self.params.datapath, plotFName)
        P.savefig(poaImagePathFName, format='eps', dpi = 1200)
        P.show()


        P.show()



    #####################################
    #####################################
    #####################################
    #################
    ##                  LIFT BAN
    #################
    #####################################
    #####################################
    #####################################
    
    def liftBan(self):
        """
        wrapper function for lifting ban scenario
        """
        self.liftBanData()
        self.getNSamples()
        self.getEpiAve()
        self.getPOACosts()
        self.plotCostsLiftBan()

    def liftBanData(self):
        """
        get data with risk origins, but not risk species
        """
        masklift = self.originRiskBool | self.sppThreatBool
        # make Rel Risk array
        self.RR = np.ones(len(self.years))
        self.RR[self.sppThreatBool] = self.params.RROriginSpp[1]
        ## reduce len of RR array - include risk samples only
        self.RR = self.RR[masklift]
        ## mask length of shipments included in analysis
        self.sppRiskMask = self.RR == self.params.RROriginSpp[1]
        self.originMask = self.RR == 1.
        self.yearsScen = self.years[masklift]
        self.uYears = np.unique(self.yearsScen)
        self.nYears = len(self.uYears)
        self.qty = self.qty[masklift]

    def getNSamples(self):
        """
        get annual number of origin- and spp-risk samples
        """
        self.nOrigRiskSamples2D = np.zeros((self.params.nProportions, self.nYears), 
            dtype = int)
        self.nOrigAll = np.zeros(self.nYears, dtype = int)
        ## always sample all of risk species shipments
        self.nSppRiskYear = np.zeros(self.nYears, dtype = int)
        self.nShipmentsYear = np.zeros(self.nYears, dtype = int)
        for i in range(self.nYears):
            yearMask = self.yearsScen == self.uYears[i]
            self.nShipmentsYear[i] = np.sum(yearMask)
            self.nSppRiskYear[i] = np.sum(self.sppRiskMask[yearMask])
            nOrig_i = np.sum(self.originMask[yearMask])
            self.nOrigAll[i] = nOrig_i
            self.nOrigRiskSamples2D[:, i] = (np.round(nOrig_i * 
                self.params.prp)).astype(int)
        ## 2D array of total samples
        self.nSppRiskYear2D = self.nSppRiskYear.reshape(1, self.nYears)
        self.totalSamples2D = (self.nSppRiskYear2D + self.nOrigRiskSamples2D)
        ## Incorporates all risk-spp samples and a proportion of origin-risk samples
        self.totalProportion2D = (self.totalSamples2D /
            (self.nShipmentsYear.reshape(1, self.nYears))) 

    def getEpiAve(self):
        """
        calc EpiAve for scenario
        """
        self.EpiAve = np.zeros((self.params.nProportions, self.nYears))
        self.sumRR = np.zeros(self.nYears)
        for i in range(self.nYears):
            yearMask = self.yearsScen == self.uYears[i]
            RR_i = self.RR[yearMask]
            sumRRi = np.sum(RR_i)
            ## the AR_i values for single origin and spp risk shipments
            ARi_origin = (self.params.RROriginSpp[0] * 
                self.nShipmentsYear[i] / sumRRi)
            ARi_spp = (self.params.RROriginSpp[1] * 
                self.nShipmentsYear[i] / sumRRi)
            pStar_i = 1.0 / self.nShipmentsYear[i]
            ## sum all AR_i - 2-D array(nPrp, 1)
            AR_Sum = ((ARi_origin * self.nOrigRiskSamples2D[:, i]) +
                (ARi_spp * self.nSppRiskYear[i]))            
            ## populate 2-D EpiAve array
            self.EpiAve[:, i] = (pStar_i * AR_Sum) / self.totalSamples2D[:, i]
            sumAR_Temp = np.sum((ARi_origin * self.nOrigAll[i]) +
                (ARi_spp * self.nSppRiskYear[i]))  
#            print('i', i, 'meanAR', sumAR_Temp / self.nShipmentsYear[i])
        nShips2D = np.expand_dims(self.nShipmentsYear, 1)
        self.nShips2D = np.transpose(nShips2D)
        self.exponent = self.EpiAve * self.nShips2D

    def getPOACosts(self):
        """
        ## get costs of acheiving target and associated proportion 
        ## of origin-risk shipments searched
        """
        self.costSummary = np.zeros((3, self.nYears))
        self.reqOrigRiskSample = np.zeros(self.nYears)
        self.minPropRequired = np.zeros(self.nYears)
        ##rand se and prior
        self.randPrior = np.random.beta(self.params.priorLift_Beta[0], 
            self.params.priorLift_Beta[1], size = self.params.iter)
        self.randSeOrigin = np.random.beta(self.params.seLiftEDNA_Beta[0],
            self.params.seLiftEDNA_Beta[1], size = self.params.iter)
        self.randSeSpp = self.randSeOrigin   
        ## Random cost of surveillance
        self.randCostOrigin = np.random.normal(self.params.costEDNA_NormalLift[0],
            self.params.costEDNA_NormalLift[1], self.params.iter)
        self.randCostSpp = np.random.normal(self.params.costEDNA_NormalLift[0],
            self.params.costEDNA_NormalLift[1], self.params.iter)
        self.meanSSe = np.zeros(self.nYears)
        ## loop thru years
        for i in range(self.nYears):
            ## loop through proportions
            for j in range(self.params.nProportions):
                meanPoAYearPrp = 0.0
                meanSSeYearPrp = 0.0
                ## loop thru iterations
                for k in range(self.params.iter):
                    ## get SeAve for spp and origin risk samples
                    seAve_ijk = (((self.nSppRiskYear2D[0, i] * self.randSeSpp[k]) +
                        (self.nOrigRiskSamples2D[j, i] * self.randSeOrigin[k])) /
                        self.totalSamples2D[j, i])
                    SSe_ijk = (1.0 - (1.0 - seAve_ijk * 
                        self.totalProportion2D[j, i])**self.exponent[j, i])
                    meanPoAYearPrp += calcPOA(self.randPrior[k], SSe_ijk)
                    meanSSeYearPrp += SSe_ijk
                meanPoAYearPrp = meanPoAYearPrp / self.params.iter
                meanSSeYearPrp = meanSSeYearPrp / self.params.iter
                ## Assess if target was acheived
                if (meanPoAYearPrp >= self.params.targetPoA):
                    ## get costs
                    totalCost_ij = ((self.randCostOrigin * self.nOrigRiskSamples2D[j, i]) +
                        (self.randCostSpp * self.nSppRiskYear2D[0, i]))
                    self.costSummary[0, i] = np.mean(totalCost_ij)
                    self.costSummary[1:, i] = mquantiles(totalCost_ij, 
                        prob=[0.025, 0.975], axis = 0)
                    self.reqOrigRiskSample[i] = self.nOrigRiskSamples2D[j, i]
                    self.meanSSe[i] = meanSSeYearPrp
                    self.minPropRequired[i] = self.params.prp[j]
                    break
#            print(i, j, k, 'SSe', np.round(meanSSeYearPrp,3), 
#                'prp', self.minPropRequired[i])
        print('min prop req', self.minPropRequired)
         

    def plotCostsLiftBan(self):
        """
        plot poa against across years and number of shipments from risk areas
        """
        P.figure(figsize=(10, 8))
        ## save plots to project directory
        costK = self.costSummary / 1000.
        print('cost lift edna', costK)
        ax = P.gca()
        lowCI = costK[0] - costK[1]
        hiCI = costK[2] - costK[0]
        lns1 = ax.errorbar(self.uYears, costK[0], yerr = [lowCI, hiCI], ecolor = 'black', 
            marker = 'o', markerfacecolor = 'black', ms = 3, ls = 'none', mew = 3, 
            markeredgecolor = 'black', capsize = 8)
        ax2 = ax.twinx()
        lns4 = ax2.plot(self.uYears, self.nSppRiskYear , 'kD',  
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns4 = tuple(lns4)
        lns5 = ax2.plot(self.uYears, self.reqOrigRiskSample , 'ko', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns5 = tuple(lns5) 
        lns6 = ax2.plot(self.uYears, self.nOrigAll , 'k*', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns6 = tuple(lns6) 
        P.legend([lns1, lns6, lns5, lns4], 
            ["Cost mean and 95% CI", 'Total origin-risk shipments',
            'Surveyed origin-risk shipments',
            'Surveyed species-risk shipments', 
            ], loc='upper right')
        maxy = np.max(costK[2]) + 20.0
        miny = np.min(costK[1]) - 20.0
        minx = np.min(self.uYears) - 1
        maxx = np.max(self.uYears) + 1
        ax.set_ylim([miny, maxy])
        ax.set_xlim([minx, maxx])
        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        self.getNTicks()

        ax.set_xticks(self.xTicksYr, self.xlabelsYr)
        ax.set_xlabel('Years', fontsize=17)
        ax.set_ylabel('Annual surveillance cost (x $1000)', fontsize=17)
        ax2.set_ylabel('Number of shipments surveyed', fontsize = 17)
#        y2max = np.max(self.nSurveyedLift) + 30
#        y2min = np.min(self.nSurveyedLift) - 30
        #        ax2.set_ylim([y2min, y2max])
        plotFName = 'costByYearLiftBan.eps'
        poaImagePathFName = os.path.join(self.params.datapath, plotFName)
        P.savefig(poaImagePathFName, format='eps', dpi = 1200)
        P.show()
        
            
      
    #############################
    #############################
    ##  Sample individuals of risk species in shipment
    #############################
    #############################
    
    def sampleIndividuals(self):
        """
        ## Wrapper functions for sample individuals of risk species in shipment
        ## not use EDNA
        """
        self.liftBanData()
        self.getRandVariates()
        self.getOptimProportion()
                       
    def getRandVariates(self):
        """
        ## get random variates for iteration ma
        """
        self.randPrior = np.random.beta(self.params.priorLift_Beta[0], 
            self.params.priorLift_Beta[1], size = self.params.iter)
        self.randSeOrigin = np.random.beta(self.params.seLiftEDNA_Beta[0],
            self.params.seLiftEDNA_Beta[1], size = self.params.iter)
        self.randSePCR = np.random.beta(self.params.seLiftPCR_Beta[0],
            self.params.seLiftPCR_Beta[1], size = self.params.iter)
        ## Random cost of surveillance
        self.randCostOrigin = np.random.normal(self.params.costEDNA_NormalLift[0],
            self.params.costEDNA_NormalLift[1], self.params.iter)
        self.randCostPCR = np.random.normal(self.params.costPCR_NormalLift[0],
            self.params.costPCR_NormalLift[1], self.params.iter)
        
    def getOptimProportion(self):
        """
        ## get optim prp of origin risk and prp of risk individ to sample
        ## loop through proportions (2) and iterations - uncertainty
        """
        self.nOrigOptim = np.zeros(self.nYears)
        self.nIndividOptim = np.zeros(self.nYears)
        self.prpOrigOptim = np.zeros(self.nYears)
        self.prpIndividOptim = np.zeros(self.nYears)        
        self.costYears_2D = np.zeros((3, self.nYears))
        self.costTemp_m = np.zeros(self.params.iter)
        ## loop thru years
        for i in range(self.nYears):
            self.getYearData(i)
            self.meanCost = 1.0e9
            ## loop through proportions sampling origin-risk shipments
            for j in range(self.params.nProportions): 
                self.prpOrig_j = self.params.prp[j]
                ## loop thru prp of risk individuals to sample in shipment
                for k in range(self.params.nPrpIndividual):
                    self.prpIndivid_k = self.params.individualPrp[k]
                    self.getProportionSamples()
                    self.getIndividEpiAve(i, j, k)
                    meanPoA = 0.0
                    ## loop thru iterations
                    for m in range(self.params.iter):
                        self.getSSe_ijkm(m)
                        meanPoA += calcPOA(self.randPrior[m], self.SSe_ijkm)
                    meanPoA = meanPoA / self.params.iter
                    ## if achieve target
                    if meanPoA >= self.params.targetPoA:
                        ## Calculate cost distribution
                        self.calcCostIndividSampling(i, j, k)
                        break
            print('year', i, 'costyears', np.round(self.costYears_2D[:, i], 0),
                'nIndivid', self.nIndividOptim[i],
                'nOrigShip', self.nOrigOptim[i],
                'prpOrig', self.prpOrigOptim[i],
                'prpInd', self.prpIndividOptim[i])
                        
    def getYearData(self, i):
        """
        ## get n samples for year i
        """
        yearMask = self.yearsScen == self.uYears[i]
        self.nShipmentsYear_i = np.sum(yearMask)
        self.nSppRiskYear_i = np.sum(self.sppRiskMask[yearMask])
        self.nOrigAll_i = np.sum(self.originMask[yearMask])
        ## number of animals in a shipment
        individRiskMask = yearMask & self.sppRiskMask
        self.sumQty_i = np.sum(self.qty[individRiskMask])
        self.RR_i = self.RR[yearMask]
        
    def getProportionSamples(self):
        """
        ## calc seAve across shipments in individ sampling scenario with PCR
        """
        self.nOriginSampled_ij = np.int(self.nOrigAll_i * self.prpOrig_j)
        self.nIndividSampled_ijk = np.int(self.sumQty_i * self.prpIndivid_k)
        self.totalSampledShips_ijk = (self.nOriginSampled_ij + self.nSppRiskYear_i)
        self.totalProportionShips_ij = (self.totalSampledShips_ijk / self.nShipmentsYear_i)
        
    def getIndividEpiAve(self, i, j, k):
        """
        ## get EpiAve for individ sampling scenario with PCR
        """
        sumRRi = np.sum(self.RR_i)
        ## the AR_i values for single origin and spp risk shipments
        ARi_origin = (self.params.RROriginSpp[0] * 
                self.nShipmentsYear_i / sumRRi)
        ARi_spp = (self.params.RROriginSpp[1] * 
                self.nShipmentsYear_i / sumRRi)
        pStar_i = 1.0 / self.nShipmentsYear_i
        ## sum all AR_i 
        AR_Sum = ((ARi_origin * self.nOriginSampled_ij) +
                (ARi_spp * self.nSppRiskYear_i))            
        EpiAve_ijk = (pStar_i * AR_Sum) / self.totalSampledShips_ijk
        self.exponent_ijk = EpiAve_ijk * self.nShipmentsYear_i
#        sumAR_Temp = np.sum((ARi_origin * self.nOrigAll[i]) +
#                (ARi_spp * self.nSppRiskYear_i)) 
#        print('origsam', self.nOriginSampled_ij,
#            'prpori', np.round(self.prpOrig_j,3),
#            'totOrig', self.nOrigAll_i, 'nrisk', self.nSppRiskYear_i,
#            'totShip', self.nShipmentsYear_i, 
#            'totSamp', self.totalSampled_ijk, 
#            'totPro', np.round(self.totalProportion_ij,3),
#            'meanAR', np.round(sumAR_Temp / self.nShipmentsYear_i,3))
        
    def getSSe_ijkm(self, m):
        """
        ## calc system sensitivity SSe
        """
        self.seIndivid_km = self.randSePCR[m] * self.prpIndivid_k
        self.SeShipAve = (((self.seIndivid_km * self.nSppRiskYear_i) +
            (self.randSeOrigin[m] * self.nOriginSampled_ij)) / 
            self.nShipmentsYear_i) 
        self.SSe_ijkm = (1.0 - (1.0 - (self.SeShipAve * 
            self.totalProportionShips_ij))**self.exponent_ijk)

    def calcCostIndividSampling(self, i, j, k):
        """
        ## calc cost of surveillance given prop of origin risk and number of individ sampled
        """
        tmpCost = ((self.randCostOrigin * self.nOriginSampled_ij) +
                        (self.randCostPCR * self.nIndividSampled_ijk))
        meanTmpCost = np.mean(tmpCost)
        if meanTmpCost < self.meanCost:
            self.nIndividOptim[i] = self.nIndividSampled_ijk
            self.nOrigOptim[i] = self.nOriginSampled_ij
            self.meanCost = meanTmpCost 
            ## populate cost storage array
            self.costYears_2D[0, i] = self.meanCost
            self.costYears_2D[1:, i] = mquantiles(tmpCost, prob=[0.025, 0.975])
            self.prpOrigOptim[i] = self.prpOrig_j
            self.prpIndividOptim[i] = self.prpIndivid_k
#            print('yr=', i, 'pOrg=', j, 'pInd=', k, 'OrgSamp', self.nOriginSampled_ij,
#                'IndSamp', self.nIndividSampled_ijk, 'totInd', self.sumQty_i, 
#                'mnCost', self.meanCost)


   #############################
    #############################
    ##  Calc cost of achieving range of PoA targets for both keep and lift ban
    #############################
    #############################
    
    def costPerPOA(self):
        """
        ## Wrapper functions for calc cost of achieving range of PoA targets 
        ## for both keep and lift ban scenarios
        """
        self.iterCost = 1000
        self.minQuants = 0.05
        # number of potential proportions to assess
        self.nPropCost = 100
        self.prpCost = np.linspace(0.05, 1.0, self.nPropCost)
#        self.makeStorageArrays()
#        self.drawVariates()
        ## numba function for Keep scenario
        (self.prpKeepSpp2D, self.costKeep2D) = calcKeepCostPoA(self.iterCost, self.costKeep_RV, 
            self.SeKeep_RV, self.priorKeep_RV, self.nKeepPoA, self.PoAKeepRange, self.nPropCost, 
            self.prpCost, self.prpKeepSpp2D, self.costKeep2D, self.meanSppShip)
#        self.calcLiftCostPoA()
#        self.plotKeepPrpPoA()


    def makeStorageArrays(self):
        """
        make 2-D storage arrays for 2 scenarios
        """
        ## get lowest PoA to track (self.minQuants) 
        minPoAScenKeep = 0.90
#            np.round(mquantiles(np.random.beta(self.params.priorBan_Beta[0],
#            self.params.priorBan_Beta[1], 1000), prob = self.minQuants), 2)
        minPoAScenLift = np.round(mquantiles(np.random.beta(self.params.priorLift_Beta[0],
            self.params.priorLift_Beta[1], 1000), prob = self.minQuants), 2)
        print('minquants', minPoAScenKeep, minPoAScenLift)
        self.PoAKeepRange = np.arange(minPoAScenKeep, 
            (self.params.targetPoA + 0.01), 0.01)
        self.nKeepPoA = len(self.PoAKeepRange)
        self.PoALiftRange = np.arange(minPoAScenLift, 
            (self.params.targetPoA + 0.01), 0.01)
        self.nLiftPoA = len(self.PoALiftRange)
        ## cost storage arrays
        self.costKeep2D = np.zeros((self.iterCost, self.nKeepPoA))
        self.costLift2D = np.zeros((self.iterCost, self.nLiftPoA))
        ## get mean number of spp-risk and origin-risk shipments
        self.meanSppShip = np.mean(self.nSppRiskYear)
        self.meanOriginShip = np.mean(self.nOrigAll)
        print('mean ships', self.meanSppShip, self.meanOriginShip)
        ## proportion storage arrays
        self.prpKeepSpp2D = np.zeros((self.iterCost, self.nKeepPoA))
        self.prpLiftSpp2D = np.zeros((self.iterCost, self.nLiftPoA))
        self.prpLiftOrigSpp2D = np.zeros((self.iterCost, self.nLiftPoA))


    def drawVariates(self):
        """
        ## draw random variates for parameters (cost, SeU, and Priors)
        """
        self.costKeep_RV = np.random.normal(self.params.costEDNA_Normal[0],
            self.params.costEDNA_Normal[1], self.iterCost)
        self.costLift_RV = np.random.normal(self.params.costEDNA_NormalLift[0],
            self.params.costEDNA_NormalLift[1], self.iterCost)
        self.SeKeep_RV = np.random.beta(self.params.seEDNA_Beta[0], 
            self.params.seEDNA_Beta[1], self.iterCost)
        self.SeLift_RV = np.random.beta(self.params.seLiftEDNA_Beta[0], 
            self.params.seLiftEDNA_Beta[1], self.iterCost)
        self.priorKeep_RV = np.random.beta(self.params.priorBan_Beta[0], 
            self.params.priorBan_Beta[1], self.iterCost)
        self.priorLift_RV = np.random.beta(self.params.priorLift_Beta[0], 
            self.params.priorLift_Beta[1], self.iterCost)

        print('max priors', np.min(self.priorKeep_RV), np.min(self.priorLift_RV))

    def plotKeepPrpPoA_XXXX(self):
        self.mnPrpPoAKeep = np.nanmean(self.prpKeepSpp2D, axis = 0)
        self.quantPrpPoAKeep = mquantiles(self.prpKeepSpp2D, axis = 0, prob = [0.05, 0.95])
        print('shp quants', np.shape(self.quantPrpPoAKeep))
        P.figure()
        P.plot(self.PoAKeepRange, self.mnPrpPoAKeep, color = 'k', linewidth = 5)
        P.plot(self.PoAKeepRange, self.quantPrpPoAKeep[0], color = 'k', ls='dashed', linewidth =3) 
        P.plot(self.PoAKeepRange, self.quantPrpPoAKeep[1], color = 'k', ls='dashed', linewidth =3) 
        P.show()




        
########            Main function
#######
def main():
    params = Params()
    analysedata = AnalyseData(params)

    ##  Run functions
    analysedata.readData()
    analysedata.keepBan()
    analysedata.liftBan()


    
#    analysedata.sampleIndividuals()
#    analysedata.costPerPOA()

if __name__ == '__main__':
    main()


