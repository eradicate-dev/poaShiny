#!/usr/bin/env python

import os
import pylab as P
import numpy as np
#from numba import jit
from scipy import stats
from scipy.stats.mstats import mquantiles
#from mpl_toolkits.axes_grid1 import make_axes_locatable
#import numpy.ma as ma
#import pickle

def getBetaFX(Mn, Sd):
    """
    get alpha and beta parameters for beta distribution using mean and sd
    """
    a = Mn * ((Mn * (1.0 - Mn)) / Sd**2.0 - 1.0)
    b = (1.0 - Mn) * ((Mn * (1.0 - Mn)) / Sd**2.0 - 1.0)
    return (a, b)

def calcPOA(prior, SSe):
    """
    Bayesian calculation of poa 
    """
    poa = prior / (1.0 - (SSe * (1.0 - prior)))
    return(poa)


class Params():
    def __init__(self):
        """
        set parameters for simulation
        """
        # set paths to scripts and data
        dp = os.getenv('POFPROJDIR')
        if dp is not None:
            self.datapath = os.getenv('POFPROJDIR') + '/bsal'
        else:
            self.datapath = '.'
#        self.datapath = os.getenv('POFPROJDIR') + '/bsal'
        self.bsaldataFName = os.path.join(self.datapath, 'bsalData.csv')
        # set parameters
        self.iter = 2000
        # priors
        self.keepBanPriorPara = [0.97, 0.05]
        self.priorBan_Beta = getBetaFX(self.keepBanPriorPara[0], 
            self.keepBanPriorPara[1]) # mean and sd
        self.liftPriorPara = [0.83, 0.10]
        self.priorLift_Beta = getBetaFX(self.liftPriorPara[0],
            self.liftPriorPara[1]) # mean and sd
        # Test sensitivities for keep ban
        self.EDNA_Beta = np.array([0.85, 0.075]) 
        self.seEDNA_Beta = getBetaFX(self.EDNA_Beta[0], self.EDNA_Beta[1])
        self.sePCR_Beta = getBetaFX(0.92, 0.05)
        # number of proportions to assess
        self.nProportions = 101
        self.prp = np.linspace(0.0, 1.0, self.nProportions)
        # proportion of individual risk species to sample
        self.nPrpIndividual = 80
        self.individualPrp = np.linspace(0.21, 1.0, self.nPrpIndividual)
        # cost of tests in dollars for origin-risk species
        self.costEDNA_Normal = np.array([200.0, 20.0]) #mean and sd
        self.costPCR_Normal = np.array([60.0, 10.0])
        # cost of tests in dollars for origin-risk species
        self.costEDNA_NormalLift = np.array([200.0, 20.0]) #mean and sd
#        self.costPCR_NormalLift = np.array([50.0, 10.0])
        self.targetPoA = 0.95
        self.RROriginSpp = np.array([1, 100]) # RR for origin risk and spp risk, respectively


class AnalyseData():
    def __init__(self, params):
        """
        class to assess SSe and PoF
        """
        self.params = params
        ##########################
        ##########################
        ##########################

    def readData(self):
        """
        read in bsal csv data
        """
        bsalDat = np.genfromtxt(self.params.bsaldataFName, delimiter=',', names=True,
            dtype=['int16', 'S10', 'S10', 'S10', 'S10', 'S10', 'S10', 'S10', 'i8',
                 'S10', 'S10', 'S10', 'S10', 'i8', 'S10', 'S10',])      
        # mask out not risk shipments
        reductionMask = ((bsalDat['origin'] == b'EAASIA') | 
            (bsalDat['origin'] == b'SEASIA') | (bsalDat['threat'] == b'Y'))
        # shipments with risk spp or risk origin
        self.sppThreatBool = bsalDat['threat'][reductionMask] == b'Y'
        self.originRiskBool = ((bsalDat['origin'][reductionMask] == b'EAASIA') |
            (bsalDat['origin'][reductionMask] == b'SEASIA'))
        # array of years
        self.years = bsalDat['year'][reductionMask]
        self.nAllDat = len(self.years)
        # number of animals in a shipment
        self.qty = bsalDat['qty'][reductionMask]

    def keepBan(self):
        """
        wrapper function for keeping ban scenario
        """
        self.keepBanData()
        self.getOptimProportionBan()
#        self.poaFX()
#        self.costKeepBan()
#        self.plotPoA()
        self.plotCostsPoA()
        self.plotPriors(self.priorsFName)

               
    def keepBanData(self):
        """
        get data with risk origins, but not risk species
        """
        maskKeep = self.originRiskBool & (self.sppThreatBool == 0)
        self.yearsScen = self.years[maskKeep]
#        self.proportion2D = (np.tile(self.params.prp, 
#            self.params.iter).reshape(self.params.iter, self.params.nProportions))
        self.uYears = np.unique(self.yearsScen)
        self.nYears = len(self.uYears)
        self.randCost = (np.random.normal((self.params.costEDNA_Normal[0]), 
            self.params.costEDNA_Normal[1], self.params.iter))
        self.nshipments = np.zeros(self.nYears, dtype=int)
        for i in range(self.nYears):
            shp_i = self.yearsScen[self.yearsScen == self.uYears[i]]
            self.nshipments[i] = len(shp_i)
        self.randSeUAve = np.random.beta(self.params.seEDNA_Beta[0],
            self.params.seEDNA_Beta[1], self.params.iter)
        self.randPrior =np.random.beta(self.params.priorBan_Beta[0], self.params.priorBan_Beta[1],
            self.params.iter)
        self.randNoIntro = np.random.beta(self.params.priorBan_Beta[0], self.params.priorBan_Beta[1],
            self.params.iter)
        self.poaImageName = 'keepBanPoA.png'
        self.priorsFName = 'priorImage.png'
        
    def getOptimProportionBan(self):
        """ 
        ## get optim prp of origin risk to sample
        ## loop through proportions (2) and iterations - uncertainty
        """
        self.nOrigOptim = np.zeros(self.nYears)
        self.prpOrigOptim = np.zeros(self.nYears)
        self.costYears_2D = np.zeros((3, self.nYears))
        ## loop thru years
        for i in range(self.nYears):
#            self.getYearDataBan(i)
            self.meanCost = 1.0e9
            ## loop through proportions sampling origin-risk shipments
            for j in range(self.params.nProportions): 
                self.prpOrig_j = self.params.prp[j]
                self.nOriginSampled_ij = np.int(self.nshipments[i] * self.prpOrig_j)
#                meanPoA = 0.0
                ## loop thru iterations
#                for m in range(self.params.iter):
#                    if i == 0:
#                        prior_im = self.randPrior[m]
#                    else:
#                        prior_im = post_im * self.randPrior[m]
                if i == 0:
                    prior_ij = self.randPrior.copy()
                else:
                    prior_ij = post_ij * self.randNoIntro
                SSe_ij = self.randSeUAve * self.prpOrig_j
                post_ij = calcPOA(prior_ij, SSe_ij)
                meanPoA = np.mean(post_ij)
                #                    meanPoA += post_im
#                meanPoA = meanPoA / self.params.iter
                ## if achieve target
                if meanPoA >= self.params.targetPoA:
                    ## Calculate cost distribution
                    self.calcCostBan(i)
                    self.nOrigOptim[i] = self.nOriginSampled_ij
                    self.prpOrigOptim[i] = self.prpOrig_j
                    break
            print('year', i,
                'pri', np.round(np.mean(prior_ij),2), 'post', np.round(meanPoA,2),
                'pIntr', np.round(np.mean(self.randNoIntro),2))

                                        
    def calcCostBan(self, i):
        """
        calc cost to get to target for each year if keep ban - 
        function of number of shipments
        """
        cost_i = self.randCost * self.nOriginSampled_ij
        self.costYears_2D[0, i] = np.mean(cost_i)
        self.costYears_2D[1:, i] = mquantiles(cost_i, prob=[0.025, 0.975])
#        print('years', self.uYears, 'nshp', self.nshipments)

        
    def plotCostsPoA(self):
        """
        plot poa against across years and number of shipments from risk areas
        """
        P.figure(figsize=(10, 8))
        # save plots to project directory
        costK = self.costYears_2D / 1000.
        ax = P.gca()
        lowCI = costK[0] - costK[1]
        hiCI = costK[2] - costK[0]
  
        lns1 = ax.errorbar(self.uYears, costK[0], yerr = [lowCI, hiCI], ecolor = 'black',
            marker = 'o', markerfacecolor = 'black', ms = 3, ls = 'none', mew = 3,
            markeredgecolor = 'black', capsize = 8)
        ax2 = ax.twinx()
        lns4 = ax2.plot(self.uYears, self.nshipments, 'k*', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns4 = tuple(lns4)
        lns5 = ax2.plot(self.uYears, self.nOrigOptim, 'ko', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns5 = tuple(lns5)

        P.legend([lns1, lns4, lns5], ["Cost mean and 95% CI", 
            'Total origin-risk shipments', 
            'Surveyed origin-risk shipments'], loc='upper right')
        
#        lns1 = ax.plot(self.uYears, costK[0] , label='Mean annual cost', color='k', linewidth=5)
#        lns2 = ax.plot(self.uYears, costK[1], label='95% CI of cost',
#               linewidth=2, color='k')
#        lns3 = ax.plot(self.uYears, costK[2], linewidth=2, color='k')
#        ax2 = ax.twinx()
#        lns4 = ax2.plot(self.uYears, self.nshipments, 'ko', label = 'Number of shipments', ms = 12)
#        lns = lns1 + lns2 + lns4
#        labs  = [l.get_label() for l in lns]
#        ax.legend(lns, labs, loc='upper right')
        maxy = np.max(costK[2]) + 20.0
        miny = np.min(costK[1]) - 20.0
        minx = np.min(self.uYears) - 1
        maxx = np.max(self.uYears) + 1
        ax.set_ylim([miny, maxy])
        ax.set_xlim([minx, maxx])
        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        self.getNTicks()

        ax.set_xticks(self.xTicksYr, self.xlabelsYr)
        ax.set_xlabel('Years', fontsize=17)
        ax.set_ylabel('Annual surveillance cost (x $1000)', fontsize=17)
        ax2.set_ylabel('Number of shipments', fontsize = 17)
        y2max = np.max(self.nshipments) + 40
        y2min = np.min(self.nOrigOptim) - 40
        
        ax2.set_ylim([y2min, y2max])
        plotFName = 'costByYear.png'
        poaImagePathFName = os.path.join(self.params.datapath, plotFName)
        P.savefig(poaImagePathFName, format='png', dpi = 1000)
        P.show()
        
        
        
        
        

    def getNTicks(self):
        """
        get n==5 ticks for plot
        """
        if self.nYears <= 5:
            self.byTicks = 1
        else:
            self.byTicks = np.round(self.nYears / 5.0)
        self.xTicksYr = np.arange(self.uYears[0], self.uYears[-1], self.byTicks)
        self.xTicksYr = self.xTicksYr.astype(int)
        self.xlabelsYr = [str(x) for x in self.xTicksYr]

    def plotPriors(self, priorsFName):
        """
        plot priors if keep ban, or eliminate ban
        """
        denRange = np.arange(0.01, 0.999, step = 0.001)
        (a,b) = self.params.priorBan_Beta
        banDensity = stats.beta.pdf(denRange, a, b)
        (c,d) = self.params.priorLift_Beta
        liftDensity = stats.beta.pdf(denRange, c, d)
        P.figure(figsize=(14, 6))
        P.subplot(1, 2, 1)
        P.plot(denRange, banDensity, label='Keep ban', color='k', linewidth=5)
        P.plot(denRange, liftDensity, label='Lift ban', color='k', linewidth=3)
        P.xlim(.55, 1.0)
        P.ylim(0.0, 15.0)
        P.xlabel('Prior prob. of no infestion', fontsize=17)
        P.ylabel('Probability density', fontsize=17)
        P.legend(loc='upper left')
        # graph SeU distributions
        (a,b) = self.params.seEDNA_Beta
        ednaDensity = stats.beta.pdf(denRange, a, b)
        (c,d) = self.params.sePCR_Beta
        pcrDensity = stats.beta.pdf(denRange, c, d)
        P.subplot(1, 2, 2)
        P.plot(denRange, ednaDensity, label='eDNA test sensitivity', color='k', linewidth=5)
        P.plot(denRange, pcrDensity, label='individual sampling sensitivity', color='k', linewidth=3)
        P.xlim(.5, 1.0)
        P.ylim(0.0, 15.0)
        P.xlabel('Test sensitivity', fontsize=17)
        P.ylabel('')
        P.legend(loc='upper left')
        # save plots to project directory
        priorImagePathFName = os.path.join(self.params.datapath, priorsFName)
        P.savefig(priorImagePathFName, format='png', dpi=1000)
        P.show()


    #####################################
    #####################################
    #####################################
    #################
    ##                  LIFT BAN
    #################
    #####################################
    #####################################
    #####################################
    
    def liftBan(self):
        """
        wrapper function for lifting ban scenario
        """
        self.liftBanData()
        self.getNSamples()
        self.getEpiAve()
        self.getPOACosts()
        self.plotCostsLiftBan()

    def liftBanData(self):
        """
        get data with risk origins, but not risk species
        """
        masklift = self.originRiskBool | self.sppThreatBool
        # make Rel Risk array
        self.RR = np.ones(len(self.years))
        self.RR[self.sppThreatBool] = self.params.RROriginSpp[1]
        ## reduce len of RR array - include risk samples only
        self.RR = self.RR[masklift]
        ## mask length of shipments included in analysis
        self.sppRiskMask = self.RR == self.params.RROriginSpp[1]
        self.originMask = self.RR == 1.
        self.yearsScen = self.years[masklift]
        self.uYears = np.unique(self.yearsScen)
        self.nYears = len(self.uYears)
        self.qty = self.qty[masklift]

    def getNSamples(self):
        """
        get annual number of origin- and spp-risk samples
        """
        self.nOrigRiskSamples2D = np.zeros((self.params.nProportions, self.nYears), 
            dtype = int)
        self.nOrigAll = np.zeros(self.nYears, dtype = int)
        ## always sample all of risk species shipments
        self.nSppRiskYear = np.zeros(self.nYears, dtype = int)
        self.nShipmentsYear = np.zeros(self.nYears, dtype = int)
        for i in range(self.nYears):
            yearMask = self.yearsScen == self.uYears[i]
            self.nShipmentsYear[i] = np.sum(yearMask)
            self.nSppRiskYear[i] = np.sum(self.sppRiskMask[yearMask])
            nOrig_i = np.sum(self.originMask[yearMask])
            self.nOrigAll[i] = nOrig_i
            self.nOrigRiskSamples2D[:, i] = (np.round(nOrig_i * 
                self.params.prp)).astype(int)
        ## 2D array of total samples
        self.nSppRiskYear2D = self.nSppRiskYear.reshape(1, self.nYears)
        self.totalSamples2D = (self.nSppRiskYear2D + self.nOrigRiskSamples2D)
        ## Incorporates all risk-spp samples and a proportion of origin-risk samples
        self.totalProportion2D = (self.totalSamples2D /
            (self.nShipmentsYear.reshape(1, self.nYears))) 

    def getEpiAve(self):
        """
        calc EpiAve for scenario
        """
        self.EpiAve = np.zeros((self.params.nProportions, self.nYears))
        self.sumRR = np.zeros(self.nYears)
        for i in range(self.nYears):
            yearMask = self.yearsScen == self.uYears[i]
            RR_i = self.RR[yearMask]
            sumRRi = np.sum(RR_i)
            ## the AR_i values for single origin and spp risk shipments
            ARi_origin = (self.params.RROriginSpp[0] * 
                self.nShipmentsYear[i] / sumRRi)
            ARi_spp = (self.params.RROriginSpp[1] * 
                self.nShipmentsYear[i] / sumRRi)
            pStar_i = 1.0 / self.nShipmentsYear[i]
            ## sum all AR_i - 2-D array(nPrp, 1)
            AR_Sum = ((ARi_origin * self.nOrigRiskSamples2D[:, i]) +
                (ARi_spp * self.nSppRiskYear[i]))            
            ## populate 2-D EpiAve array
            self.EpiAve[:, i] = (pStar_i * AR_Sum) / self.totalSamples2D[:, i]
            sumAR_Temp = np.sum((ARi_origin * self.nOrigAll[i]) +
                (ARi_spp * self.nSppRiskYear[i]))  
#            print('i', i, 'meanAR', sumAR_Temp / self.nShipmentsYear[i])
        nShips2D = np.expand_dims(self.nShipmentsYear, 1)
        self.nShips2D = np.transpose(nShips2D)
        self.exponent = self.EpiAve * self.nShips2D

    def getPOACosts(self):
        """
        ## get costs of acheiving target and associated proportion 
        ## of origin-risk shipments searched
        """
        self.costSummary = np.zeros((3, self.nYears))
        self.reqOrigRiskSample = np.zeros(self.nYears)
        self.minPropRequired = np.zeros(self.nYears)
        ##rand se and prior
        self.randPrior = np.random.beta(self.params.priorLift_Beta[0], 
            self.params.priorLift_Beta[1], size = self.params.iter)
        self.randSeOrigin = np.random.beta(self.params.seEDNA_Beta[0],
            self.params.seEDNA_Beta[1], size = self.params.iter)
        self.randSeSpp = self.randSeOrigin   # 1.0 - (1.0 - self.randSeOrigin)**2
#        print('sppSSe', self.randSeSpp[:10], 'originSSe', self.randSeOrigin[:10])
        ## Random cost of surveillance
        self.randCostOrigin = np.random.normal(self.params.costEDNA_Normal[0],
            self.params.costEDNA_Normal[1], self.params.iter)
        self.randCostSpp = np.random.normal(self.params.costEDNA_NormalLift[0],
            self.params.costEDNA_NormalLift[1], self.params.iter)
        self.meanSSe = np.zeros(self.nYears)
        ## loop thru years
        for i in range(self.nYears):
            ## loop through proportions
            for j in range(self.params.nProportions):
                meanPoAYearPrp = 0.0
                meanSSeYearPrp = 0.0
                ## loop thru iterations
                for k in range(self.params.iter):
                    ## get SeAve for spp and origin risk samples
                    seAve_ijk = (((self.nSppRiskYear2D[0, i] * self.randSeSpp[k]) +
                        (self.nOrigRiskSamples2D[j, i] * self.randSeOrigin[k])) /
                        self.totalSamples2D[j, i])
                    SSe_ijk = (1.0 - (1.0 - seAve_ijk * 
                        self.totalProportion2D[j, i])**self.exponent[j, i])
                    meanPoAYearPrp += calcPOA(self.randPrior[k], SSe_ijk)
                    meanSSeYearPrp += SSe_ijk
                meanPoAYearPrp = meanPoAYearPrp / self.params.iter
                meanSSeYearPrp = meanSSeYearPrp / self.params.iter
                ## Assess if target was acheived
                if (meanPoAYearPrp >= self.params.targetPoA):
                    ## get costs
                    totalCost_ij = ((self.randCostOrigin * self.nOrigRiskSamples2D[j, i]) +
                        (self.randCostSpp * self.nSppRiskYear2D[0, i]))
                    self.costSummary[0, i] = np.mean(totalCost_ij)
                    self.costSummary[1:, i] = mquantiles(totalCost_ij, 
                        prob=[0.025, 0.975], axis = 0)
                    self.reqOrigRiskSample[i] = self.nOrigRiskSamples2D[j, i]
                    self.meanSSe[i] = meanSSeYearPrp
                    self.minPropRequired[i] = self.params.prp[j]
                    break
#            print(i, j, k, 'SSe', np.round(meanSSeYearPrp,3), 
#                'prp', self.minPropRequired[i])
#        print('meanSSe', self.meanSSe)
         

    def plotCostsLiftBan(self):
        """
        plot poa against across years and number of shipments from risk areas
        """
        P.figure(figsize=(10, 8))
        ## save plots to project directory
        costK = self.costSummary / 1000.
        ax = P.gca()
        lowCI = costK[0] - costK[1]
        hiCI = costK[2] - costK[0]
        lns1 = ax.errorbar(self.uYears, costK[0], yerr = [lowCI, hiCI], ecolor = 'black', 
            marker = 'o', markerfacecolor = 'black', ms = 3, ls = 'none', mew = 3, 
            markeredgecolor = 'black', capsize = 8)
        ax2 = ax.twinx()
        lns4 = ax2.plot(self.uYears, self.nSppRiskYear , 'kD',  
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns4 = tuple(lns4)
        lns5 = ax2.plot(self.uYears, self.reqOrigRiskSample , 'ko', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns5 = tuple(lns5) 
        lns6 = ax2.plot(self.uYears, self.nOrigAll , 'k*', 
            markerfacecolor = 'none', ms = 10, mew = 1.5)
        lns6 = tuple(lns6) 
        P.legend([lns1, lns6, lns5, lns4], 
            ["Cost mean and 95% CI", 'Total origin-risk shipments',
            'Surveyed origin-risk shipments',
            'Surveyed species-risk shipments'], loc='upper right')
        maxy = np.max(costK[2]) + 20.0
        miny = np.min(costK[1]) - 20.0
        minx = np.min(self.uYears) - 1
        maxx = np.max(self.uYears) + 1
        ax.set_ylim([miny, maxy])
        ax.set_xlim([minx, maxx])
        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(14)
        self.getNTicks()

        ax.set_xticks(self.xTicksYr, self.xlabelsYr)
        ax.set_xlabel('Years', fontsize=17)
        ax.set_ylabel('Annual surveillance cost (x $1000)', fontsize=17)
        ax2.set_ylabel('Number of shipments surveyed', fontsize = 17)
#        y2max = np.max(self.nSurveyedLift) + 30
#        y2min = np.min(self.nSurveyedLift) - 30
        #        ax2.set_ylim([y2min, y2max])
        plotFName = 'costByYearLiftBan.png'
        poaImagePathFName = os.path.join(self.params.datapath, plotFName)
        P.savefig(poaImagePathFName, format='png', dpi = 1000)
        P.show()
        
            
      
    #############################
    #############################
    ##  Sample individuals of risk species in shipment
    #############################
    #############################
    
    def sampleIndividuals(self):
        """
        ## Wrapper functions for sample individuals of risk species in shipment
        """
        self.liftBanData()
        self.getRandVariates()
        self.getOptimProportion()
                       
    def getRandVariates(self):
        """
        ## get random variates for iteration ma
        """
        self.randPrior = np.random.beta(self.params.priorLift_Beta[0], 
            self.params.priorLift_Beta[1], size = self.params.iter)
        self.randSeOrigin = np.random.beta(self.params.seEDNA_Beta[0],
            self.params.seEDNA_Beta[1], size = self.params.iter)
        self.randSePCR = np.random.beta(self.params.sePCR_Beta[0],
            self.params.sePCR_Beta[1], size = self.params.iter)
        ## Random cost of surveillance
        self.randCostOrigin = np.random.normal(self.params.costEDNA_Normal[0],
            self.params.costEDNA_Normal[1], self.params.iter)
        self.randCostPCR = np.random.normal(self.params.costPCR_Normal[0],
            self.params.costPCR_Normal[1], self.params.iter)
        
    def getOptimProportion(self):
        """
        ## get optim prp of origin risk and prp of risk individ to sample
        ## loop through proportions (2) and iterations - uncertainty
        """
        self.nOrigOptim = np.zeros(self.nYears)
        self.nIndividOptim = np.zeros(self.nYears)
        self.prpOrigOptim = np.zeros(self.nYears)
        self.prpIndividOptim = np.zeros(self.nYears)        
        self.costYears_2D = np.zeros((3, self.nYears))
#        self.costTemp_m = np.zeros(self.params.iter)
        ## loop thru years
        for i in range(self.nYears):
            self.getYearData(i)
            self.meanCost = 1.0e9
            ## loop through proportions sampling origin-risk shipments
            for j in range(self.params.nProportions): 
                self.prpOrig_j = self.params.prp[j]
                ## loop thru prp of risk individuals to sample in shipment
                for k in range(self.params.nPrpIndividual):
                    self.prpIndivid_k = self.params.individualPrp[k]
                    self.getProportionSamples()
                    self.getIndividEpiAve(i, j, k)
                    meanPoA = 0.0
                    ## loop thru iterations
                    for m in range(self.params.iter):
                        self.getSSe_ijkm(m)
                        ## if year 1, use prior
                        if i == 0:
                            prior_im = self.randPrior[m]
                        ## if past year 1, discount with intro rate (1-prior)
                        else:
                            prior_im = self.randPrior[m]**2.0
                        meanPoA += calcPOA(prior_im, self.SSe_ijkm)
                    meanPoA = meanPoA / self.params.iter
                    ## if achieve target
                    if meanPoA >= self.params.targetPoA:
                        ## Calculate cost distribution
                        self.calcCostIndividSampling(i, j, k)
                        break
            print('year', i, 'costyears', np.round(self.costYears_2D[:, i], 0),
                'nIndivid', self.nIndividOptim[i],
                'nOrigShip', self.nOrigOptim[i],
                'prpOrig', self.prpOrigOptim[i],
                'prpInd', self.prpIndividOptim[i])
                        
    def getYearData(self, i):
        """
        ## get n samples for year i
        """
        yearMask = self.yearsScen == self.uYears[i]
        self.nShipmentsYear_i = np.sum(yearMask)
        self.nSppRiskYear_i = np.sum(self.sppRiskMask[yearMask])
        self.nOrigAll_i = np.sum(self.originMask[yearMask])
        ## number of animals in a shipment
        individRiskMask = yearMask & self.sppRiskMask
        self.sumQty_i = np.sum(self.qty[individRiskMask])
        self.RR_i = self.RR[yearMask]
        
    def getProportionSamples(self):
        """
        ## calc seAve across shipments in individ sampling scenario with PCR
        """
        self.nOriginSampled_ij = np.int(self.nOrigAll_i * self.prpOrig_j)
        self.nIndividSampled_ijk = np.int(self.sumQty_i * self.prpIndivid_k)
        self.totalSampledShips_ijk = (self.nOriginSampled_ij + self.nSppRiskYear_i)
        self.totalProportionShips_ij = (self.totalSampledShips_ijk / self.nShipmentsYear_i)
        
    def getIndividEpiAve(self, i, j, k):
        """
        ## get EpiAve for individ sampling scenario with PCR
        """
        sumRRi = np.sum(self.RR_i)
        ## the AR_i values for single origin and spp risk shipments
        ARi_origin = (self.params.RROriginSpp[0] * 
                self.nShipmentsYear_i / sumRRi)
        ARi_spp = (self.params.RROriginSpp[1] * 
                self.nShipmentsYear_i / sumRRi)
        pStar_i = 1.0 / self.nShipmentsYear_i
        ## sum all AR_i 
        AR_Sum = ((ARi_origin * self.nOriginSampled_ij) +
                (ARi_spp * self.nSppRiskYear_i))            
        EpiAve_ijk = (pStar_i * AR_Sum) / self.totalSampledShips_ijk
        self.exponent_ijk = EpiAve_ijk * self.nShipmentsYear_i
#        sumAR_Temp = np.sum((ARi_origin * self.nOrigAll[i]) +
#                (ARi_spp * self.nSppRiskYear_i)) 
#        print('origsam', self.nOriginSampled_ij,
#            'prpori', np.round(self.prpOrig_j,3),
#            'totOrig', self.nOrigAll_i, 'nrisk', self.nSppRiskYear_i,
#            'totShip', self.nShipmentsYear_i, 
#            'totSamp', self.totalSampled_ijk, 
#            'totPro', np.round(self.totalProportion_ij,3),
#            'meanAR', np.round(sumAR_Temp / self.nShipmentsYear_i,3))
        
    def getSSe_ijkm(self, m):
        """
        ## calc system sensitivity SSe
        """
        self.seIndivid_km = self.randSePCR[m] * self.prpIndivid_k
        self.SeShipAve = (((self.seIndivid_km * self.nSppRiskYear_i) +
            (self.randSeOrigin[m] * self.nOriginSampled_ij)) / 
            self.nShipmentsYear_i) 
        self.SSe_ijkm = (1.0 - (1.0 - (self.SeShipAve * 
            self.totalProportionShips_ij))**self.exponent_ijk)

    def calcCostIndividSampling(self, i, j, k):
        """
        ## calc cost of surveillance given prop of origin risk and number of individ sampled
        """
        tmpCost = ((self.randCostOrigin * self.nOriginSampled_ij) +
                        (self.randCostPCR * self.nIndividSampled_ijk))
        meanTmpCost = np.mean(tmpCost)
        if meanTmpCost < self.meanCost:
            self.nIndividOptim[i] = self.nIndividSampled_ijk
            self.nOrigOptim[i] = self.nOriginSampled_ij
            self.meanCost = meanTmpCost 
            ## populate cost storage array
            self.costYears_2D[0, i] = self.meanCost
            self.costYears_2D[1:, i] = mquantiles(tmpCost, prob=[0.025, 0.975])
            self.prpOrigOptim[i] = self.prpOrig_j
            self.prpIndividOptim[i] = self.prpIndivid_k
#            print('yr=', i, 'pOrg=', j, 'pInd=', k, 'OrgSamp', self.nOriginSampled_ij,
#                'IndSamp', self.nIndividSampled_ijk, 'totInd', self.sumQty_i, 
#                'mnCost', self.meanCost)

        
########            Main function
#######
def main():
    params = Params()
    analysedata = AnalyseData(params)

    ##  Run functions
    analysedata.readData()
    analysedata.keepBan()
#    analysedata.liftBan()
#    analysedata.sampleIndividuals()




if __name__ == '__main__':
    main()


