#!/usr/bin/env python

########################################
########################################
# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

import os
import pickle
import numpy as np

from proofofabsence import postProcessing
#from proofofabsence import params
#from proofofabsence import calculation

######################
# Main function
def main():
    ############################################################
    ###################################### USER MODIFY HERE ONLY
    #################################

    # set paths to result pickle files
    inputDataPath = 'validation/valid_data'
    outputDataPath = 'validation/valid_results_means'
    # set INPUT extent and relative risk file names

    preProcessingResults = 'spatialData.pkl'
    calculationResults = 'resultData.pkl'
    zoneShapeFName = os.path.join(inputDataPath, 'extentShape.shp')

    #### Results names
    SSePoFResultTableName = 'PofSseResultTable.txt'
    pofSSeGraphName = 'PoF_SSe_Graph.png'

    zoneSeResultTableName = None

    ## Specify the label on y-axis of the probability of 'absence/below thres' plot
    probabilityName = 'Probability of absence'
    timeName = 'Years'
    targetPoA = 0.95
    priorTime = '2006'


    #####################################   END USER MODIFICATION
    #############################################################
    #############################################################


    results = postProcessing.ResultsProcessing(inputDataPath, outputDataPath, 
                preProcessingResults, calculationResults, zoneShapeFName,
                SSePoFResultTableName, pofSSeGraphName, zoneSeResultTableName)


    #### Run Functions

    # make results table and plot to screen
    results.makeTableFX(timeName)
    # write result table to directory
    results.writeToFileFX(SSePoFResultTableName, timeName)


    if results.calcdat.params.multipleZones:
        ## MAKE TABLE WITH SENSITIVITIES OF ZONES AND WRITE TO DIRECTORY
        results.makeZoneTableFX()
        results.writeZoneTableToFileFX(zoneSeResultTableName, timeName)
    
    # make pngs
    results.plotMeanSeUAllYears()
    results.plotRelRisk()

    # plot pof and sse over time and write to directory
    results.plotFX(pofSSeGraphName, probabilityName, timeName, targetPoA, priorTime)

    ##### OPTIONAL FUNCTIONS
    # plot 2-d images of the yearly mean seu
#    results.plotMeanSeUTuiview()
    # plot updated relative risk map
#    OLD FX    self.plotRelRisk()
#    results.plotRelRiskTuiview()
    ##########################


if __name__ == '__main__':
    main()

