#!/usr/bin/env python

########################################
########################################
# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

import os
import pickle

from proofofabsence import preProcessing
from proofofabsence import params
from proofofabsence import calculation

######################
# Main function
def main():
    ############################################################
    ###################################### USER MODIFY HERE ONLY
    #################################
    # set paths to scripts and data
    inputDataPath = 'testdata' # 'testdata' 
    outputDataPath = 'results1'   # 'results1' # 
    if not os.path.isdir(outputDataPath):
        os.mkdir(outputDataPath)

    # set INPUT extent and relative risk file names
    extentShapeFName = os.path.join(inputDataPath, 'extentShape.shp')
    relativeRiskFName = os.path.join(inputDataPath, 'testRelRisk.asc')
    gridSurvey = os.path.join(inputDataPath, 'gridSurvey.csv')
    # set OUTPUT names for mask and relative risk map
    extentMaskOutFName = os.path.join(outputDataPath, 'extentMask.tif')
    relRiskRasterOutFName = os.path.join(outputDataPath, 'relRiskRaster.tif')
    # resolution for analysis
    Resolution = 100.0
    # EPSG - PROJECTION SYSTEM
    epsg = 2193 # NZTM
    # Surveillance data Name
    surveyFName = os.path.join(inputDataPath, 'surveyData.csv')
    # Instance of POAParameters class
    myParams = params.POAParameters()
    myParams.setNumIterations(5)
    myParams.setNumChewcardTraps(3)
    myParams.setKTrapDistance(100.0)
    myParams.setYears([2007, 2008, 2009, 2010, 2011])
    myParams.setPu(2.0)
    myParams.setMinK(5.0)

    myParams.setPrior(0.499999, 0.5, 0.500001)
    myParams.setIntro(0.009999, 0.01, 0.010001)
    myParams.setSigma(params.TYPE_POSSUM, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_POSSTRAP, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_CHEWCARD, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_FERRET, 287.0, 0.000001)
    myParams.setSigma(params.TYPE_PIG, 910.0, 0.000001)
    myParams.setSigma(params.TYPE_REDDEER, 2500.0, 1.0)

    myParams.setChewcard(params.TYPE_CHEWCARD, 0.2, 0.000001)
    myParams.setCapture(params.TYPE_POSSUM, 0.13, 0.000001)
    myParams.setCapture(params.TYPE_POSSTRAP, 0.13, 0.000001)
    myParams.setCapture(params.TYPE_CHEWCARD, 0.13, 0.000001)

    myParams.setTest(params.TYPE_POSSUM, 0.95, 0.00001)
    myParams.setTest(params.TYPE_POSSTRAP, 0.95, 0.000001)
    myParams.setTest(params.TYPE_CHEWCARD, 0.95, 0.00001)
    myParams.setTest(params.TYPE_FERRET, 0.95, 0.00001)
    myParams.setTest(params.TYPE_PIG, 0.95, 0.000001)
    myParams.setTest(params.TYPE_REDDEER, 0.95, 0.00001)

    myParams.setInfect(params.TYPE_POSSUM, 1.0, 0.1)
    myParams.setInfect(params.TYPE_POSSTRAP, 1.0, 0.1)
    myParams.setInfect(params.TYPE_CHEWCARD, 1.0, 0.1)
    myParams.setInfect(params.TYPE_FERRET, 0.187, 0.01)
    myParams.setInfect(params.TYPE_PIG, 0.472, 0.000001)
    myParams.setInfect(params.TYPE_REDDEER, 0.009, 0.01)

    #####################################   END USER MODIFICATION
    #############################################################
    #############################################################

    # initiate instances of Classes
    rawdata = preProcessing.RawData(extentShapeFName, relativeRiskFName, 
            extentMaskOutFName, relRiskRasterOutFName, Resolution, epsg, 
            surveyFName, myParams, gridSurvey)

    # make object for pickling spatial data
    pickledat = preProcessing.PickleDat(rawdata)
    # pickle to output directory
    pickleName = os.path.join(outputDataPath, 'spatialData.pkl')
    fileobj = open(pickleName, 'wb')
    pickle.dump(pickledat, fileobj)
    fileobj.close()

    myParams.setGridSurvey(rawdata.gridSurveyYears, rawdata.gridSurveyData,
            rawdata.gridSurveyMeans, rawdata.gridSurveySD, rawdata.gridSurveyCodes)

    result = calculation.calcProofOfAbsence(myParams, pickledat.survey, 
                pickledat.extMask, pickledat.relativeRiskRaster, 
                pickledat.match_geotrans)
    ## PRINT INTERMEDIATE RESULTS
    print(result.intermediateResults)
    pickleName = os.path.join(outputDataPath, 'resultData.pkl')
    fileobj = open(pickleName, 'wb')
    pickle.dump(result, fileobj)
    fileobj.close()
 
if __name__ == '__main__':
    main()


