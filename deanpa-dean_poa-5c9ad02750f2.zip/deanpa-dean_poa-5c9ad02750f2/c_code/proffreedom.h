
#ifndef __PROFFREEDOM_H__
#define __PROFFREEDOM_H__

int proffreedom( struct sTrapData *pTrapData, int nTraps, struct sParameter *pParameters, 
                    int *pnYearSeq, int nYears,
                    int *pnSurveillanceYearSeq, int nSurveillanceYears, int nIter,
                    int nChewcardTraps, struct sMaskRaster *pMaskRaster, 
                    struct sRaster *pKMapRaster, int nPu, 
                    double dIntro_a, double dIntro_b, double dIntro_min, double dIntro_max,
                    double dPrior_a, double dPrior_b, double dPrior_min, double dPrior_max,
                    char **ppszSensitivityNames, struct sRaster *pSSeMat, struct sRaster *pPoFMat,
                    int (*percentCallback)(int, void*), int (*newValues)(double, double, int, int, void*),
                    void *pCallbackData, char **ppszMessage, int *pnCallbackValue );

#endif /*__PROFFREEDOM_H__*/
