#ifndef __MASKUTILS_H__
#define __MASKUTILS_H__

int maskKMap( struct sTrapData *pTrapData, int nTraps, int *pnYearSeq, int nYears, struct sRaster *pKMapRaster, 
                struct sMaskRaster *pMaskRaster,
                int nMinK, double dDistance );
                
int addConstant( struct sRaster *pRaster, double dConst);

int maskRaster( struct sRaster *pRaster, struct sMaskRaster *pMaskRaster);
            

#endif /* __MASKUTILS_H__ */
