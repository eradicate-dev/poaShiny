
#ifndef __FILEIO_H__
#define __FILEIO_H__ 

/* Contains functions for reading data files */

int readParameters( const char *pszFilename, struct sParameter **ppParameters );
int readTrapCSV(const char *pszFilename, struct sTrapData **ppTrapData, 
                    int **ppnSurveillanceYearSeq, int *pnSurveillanceYears, char **ppszMessage);
void printParameters(struct sParameter *pParameters);

#endif /*__FILEIO_H__*/

