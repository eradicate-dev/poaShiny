
#include <stdio.h>
#include "raster.h"
#include "types.h"
#include "maskutils.h"
#include <math.h>

int maskKMap( struct sTrapData *pTrapData, int nTraps, int *pnYearSeq, int nYears, struct sRaster *pKMapRaster, 
                struct sMaskRaster *pMaskRaster,
                int nMinK, double dDistance )
{
	int n, i, nCurrentTrap, nTLX, nTLY, nBRY, nBRX, testY, testX;
	struct sTrapData *pCurrentTrap;
	double dSearchDistance, dSearchTLX, dSearchTLY, dSearchBRX, dSearchBRY, testNorth, testEast;
	double dXDist, dYDist, dDist;
    struct sMaskRaster *pOrigMask;
    double dMaxK;
    
    if( ( pKMapRaster->nColumns != pMaskRaster->nColumns ) ||
            ( pKMapRaster->nRows != pMaskRaster->nRows ) )
    {
        fprintf( stderr, "Rasters do not match in size" );
        return 0;
    }

    /* duplicate the original mask so we can check and not mask areas in that we should not */
    pOrigMask = duplicateMaskRaster(pMaskRaster);
    
    /* Do masking by minimum K */
    /* Note: we compare to 1 not zero since 1 has been added to everything */
	if( nMinK > 1 )
	{
		n = pKMapRaster->nColumns * pKMapRaster->nRows;
		/* mask out everything less than nMinK */
		for( i = 0; i < n; i++ )
		{
			if( pKMapRaster->pData[i] < nMinK )
				pMaskRaster->pData[i] = 0;
		}
	}

    if( dDistance > 0 )
    {
        /* Work out what value to set K to around traps */
        /* This is half the maximum K, or nMinK+1 - whatever bigger */
        dMaxK = rasterMaximumWithMask(pKMapRaster, pMaskRaster) / 2.0;
        if( nMinK > dMaxK )
        {
            dMaxK = nMinK + 1;
        }

        /* go through each trap */
        for( nCurrentTrap = 0; nCurrentTrap < nTraps; nCurrentTrap++ )
        {
            /* get current trap and parameters for that species */
            /* Only process traps for specified year */
            pCurrentTrap = &pTrapData[nCurrentTrap];
            if( ((pCurrentTrap->species == posstrap) || (pCurrentTrap->species == possum) || 
                (pCurrentTrap->species == chewcard)) && (inList(pCurrentTrap->year, pnYearSeq, nYears) != -1) )
            {
                /* add another pixel to search just to be safe */
                dSearchDistance = dDistance + pKMapRaster->resolution;
            

                /* work out our search area */
                dSearchTLX = pCurrentTrap->easting - dSearchDistance;
                dSearchTLY = pCurrentTrap->northing + dSearchDistance;
                dSearchBRX = pCurrentTrap->easting + dSearchDistance;
                dSearchBRY = pCurrentTrap->northing - dSearchDistance;

                /* Convert to pixel coords */
                /* Both could be outside the raster, but we need to search */
                /* anyway in case the search area intersects with the raster */
                rasterGetXY( pKMapRaster, dSearchTLX, dSearchTLY, &nTLX, &nTLY );
                rasterGetXY( pKMapRaster, dSearchBRX, dSearchBRY, &nBRX, &nBRY );
			
                /* Correct back to coords on the grid */
                rasterGetNorthingEasting( pKMapRaster, nTLX, nTLY, &dSearchTLX, &dSearchTLY );
                /* go through each pixel in the search area */
                testNorth = dSearchTLY;
                for( testY = nTLY; testY < nBRY; testY++ )
                {
                    testEast = dSearchTLX;
                    for( testX = nTLX; testX < nBRX; testX++ )
                    {
                        /* is this location within the raster? */
                        if( ( testX >= 0 ) && ( testY >= 0 ) && 
                            ( testX < pKMapRaster->nColumns ) && 
                            ( testY < pKMapRaster->nRows ) )
                        {
                            /* work out distance and then the kernel value */
                            dXDist = fabs( pCurrentTrap->easting - testEast );
                            dYDist = fabs( pCurrentTrap->northing - testNorth );
                            dDist = sqrt( dXDist * dXDist + dYDist * dYDist );
                            /* make sure our pixel is less than dDistance away from trap */
                            /* and included in the original mask */
                            if( ( dDist <= dDistance ) && (maskRasterGetValue(pOrigMask, testX, testY) != 0 ) )
                            {
                                maskRasterSetValue(pMaskRaster, testX, testY, 1);
                                /* do infill if value only smaller than nMinK */
                                if( rasterGetValue(pKMapRaster, testX, testY) < nMinK )
                                {
                                    rasterSetValue(pKMapRaster, testX, testY, dMaxK);
                                }
                            } /* less that dDistance */
                        } /* within raster */
                        testEast += pKMapRaster->resolution;
                    } /* east */
                    testNorth -= pKMapRaster->resolution;
                } /* north */					
            }/* species == trap */
        } /* trap loop */
    } /* distance */
    destroyMaskRaster( pOrigMask );

    return 1;
}

int addConstant( struct sRaster *pRaster, double dConst)
{
    int i;
    int n = pRaster->nColumns * pRaster->nRows;
    for( i = 0; i < n; i++ )
    {
        pRaster->pData[i] += dConst;
    }
    return 1;
}

int maskRaster( struct sRaster *pRaster, struct sMaskRaster *pMaskRaster)
{
    int i;
    int n = pRaster->nColumns * pRaster->nRows;

    if( ( pRaster->nColumns != pMaskRaster->nColumns ) ||
            ( pRaster->nRows != pMaskRaster->nRows ) )
    {
        fprintf( stderr, "Rasters do not match in size" );
        return 0;
    }

    for( i = 0; i < n; i++ )
    {
        if( pMaskRaster->pData[i] == 0 )
            pRaster->pData[i] = -9999;
    }
    
    return 0;
}
