
#ifndef __TYPES_H__
#define __TYPES_H__

/* The different species/traps supported */
enum eSpecies
{
    possum = 0, 
    posstrap, 
    chewcard,
    ferret,
    pig,
    reddeer
};

/* Must update this when you update eSpecies */
#define NSPECIES 6

/* Sex of the animal */
enum eSex
{
    male,
    female
};

/* Information about a particular trap/animal */
struct sTrapData
{
    int year;
    enum eSpecies species;
    double easting;
    double northing;
    double age;
    enum eSex sex;
    int trapnights;
};

/* Parameters for a particular trap/animal */
struct sParameter
{
    double mean_sig;
    double sd_sig;

    double mean_CC;
    double sd_CC;
    double a_CC;
    double b_CC;

    double mean_capt;
    double sd_capt;
    double a_capt;
    double b_capt;

    double mean_test;
    double sd_test;
    double a_test;
    double b_test;

    double mean_infect;
    double sd_infect;
    double a_infect;
    double b_infect;
};

/* Some handy functions used elsewhere */
void findBeta( double mu, double sdev, double *pA, double *pB );
void findBetaPert(double min, double mode, double max, double shape, double *pShape1, double *pShape2);
int inList( int nValue, int *pList, int nLength );

#define PERT_SHAPE 4.0


#ifdef _WIN32
   /* Windows does not have this function */
   #define round(d) floor((d) + 0.5)
#endif

#endif /*__TYPES_H__*/

