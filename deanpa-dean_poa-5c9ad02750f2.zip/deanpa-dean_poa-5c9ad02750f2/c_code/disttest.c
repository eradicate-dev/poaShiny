
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include "types.h"
#include "fileio.h"

int main(int argc, char* argv[])
{
char *pszParaFile;
double dDist1, dDist2, dSigma, dg0, dpCap, dTest, dKern, dSensitivityTrapCell1, dSensitivityTrapCell2;
double dCombined;
struct sParameter *pParameters, *pCurrentParam;
gsl_rng *pRandomGenerator;
int nTrapnights1, nTrapnights2;

	if( argc != 6 )
	{
		fprintf( stderr, "usage: parafile distance1 trapnights1 distance2 trapnights2" );
		exit(1);
	}

	pszParaFile = argv[1];
	dDist1 = atof(argv[2]);
	nTrapnights1 = atoi(argv[3]);
	dDist2 = atof(argv[4]);
	nTrapnights2 = atoi(argv[5]);

    if( ! readParameters( pszParaFile, &pParameters ) )
    {
        fprintf( stderr, "Unable to read parameter file %s\n", pszParaFile );
        exit( 1 );
    }
	printParameters(pParameters);

    /* Initialise the Random Number Generator to the Mersenne Twister */
    pRandomGenerator = gsl_rng_alloc( gsl_rng_mt19937 );
    /* Seed it with the current time */
    gsl_rng_set( pRandomGenerator, (unsigned long int)time(NULL) );

	pCurrentParam = &pParameters[posstrap];

	dSigma = pCurrentParam->mean_sig + gsl_ran_gaussian( pRandomGenerator, pCurrentParam->sd_sig );
    /* Equation 11 */
    dKern = exp( -( dDist1 * dDist1 ) / ( 2.0 * ( dSigma * dSigma ) ) );

	dTest = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_test, pCurrentParam->b_test );
	printf( "sigma = %f, kern = %f, test = %f\n", dSigma, dKern, dTest);
    /* Equation 10 */
    dg0 = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_capt, pCurrentParam->b_capt );
	printf( "d0 = %f\n", dg0 );
    dpCap = 1.0 - pow( 1.0 - dg0 * dKern, nTrapnights1 );

    /* Probability of detecting TB in cell i from device j */
    dSensitivityTrapCell1 = dpCap * dTest;
	printf( "dSensitivityTrapCell1 = %f\n", dSensitivityTrapCell1);


	dSigma = pCurrentParam->mean_sig + gsl_ran_gaussian( pRandomGenerator, pCurrentParam->sd_sig );
    /* Equation 11 */
    dKern = exp( -( dDist2 * dDist2 ) / ( 2.0 * ( dSigma * dSigma ) ) );

	dTest = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_test, pCurrentParam->b_test );
	printf( "sigma = %f, kern = %f, test = %f\n", dSigma, dKern, dTest);
    /* Equation 10 */
    dg0 = gsl_ran_beta( pRandomGenerator, pCurrentParam->a_capt, pCurrentParam->b_capt );
	printf( "d0 = %f\n", dg0 );
    dpCap = 1.0 - pow( 1.0 - dg0 * dKern, nTrapnights2 );

    /* Probability of detecting TB in cell i from device j */
    dSensitivityTrapCell2 = dpCap * dTest;
	printf( "dSensitivityTrapCell2 = %f\n", dSensitivityTrapCell2);

	dCombined = (1.0 - dSensitivityTrapCell1) * (1.0 - dSensitivityTrapCell2);
	printf("combined sentitivity = %f\n", dCombined);

	return 0;
}
