#!/bin/sh

GDALVER=`python -c "from osgeo import gdal;print(gdal.__version__[0])"`

./proffreedom data/surveyData.csv data/params.csv 2007,2008,2009,2010,2011 \
    10 3 data/extentMask.asc data/relRiskRaster_gdal${GDALVER}.asc 2.0 5 100 0.0001 0.01 0.02 \
    0.2 0.5 0.8



