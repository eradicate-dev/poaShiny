
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "raster.h"
#include "fileio.h"
#include "maskutils.h"
#include "proffreedom.h"

#ifdef _WIN32
    /* Windows needs this for some reason */
    #define strdup _strdup
    #define snprintf _snprintf
#endif

int stdout_percent( int nPercent, void *pData )
{
    fprintf( stderr, "%d%%\r", nPercent );
    return 0;
}

int new_values( double dTotalAR, double dAverageSensitivity, int nSearched, int nTotal, void *pData )
{
    fprintf( stderr, "total AR = %f SeUAvg = %f ni = %d Ni = %d\n", dTotalAR, dAverageSensitivity, nSearched, nTotal );
    return 0;
}

int main(int argc, char *argv[])
{
    int nTraps;
    struct sTrapData *pTrapData;
    struct sParameter *pParameters;
    struct sMaskRaster *pMaskRaster;
    struct sRaster *pKMapRaster;
    struct sRaster *pSSeMat, *pPoFMat;
    char *pszTrapCSV, *pszParaFile;
    char *pszYearSeq, *pszCurrent;
    char **ppszSensitivityNames;
    int *pnYearSeq, nYears;
    int *pnSurveillanceYearSeq, nSurveillanceYears, nCurrentYear;
    int nIter, nChars;
    int nChewcardTraps;
    char *pszDataMask, *pszKMap, *pszMessage;
    double dPrior_a, dPrior_b, dIntro_a, dIntro_b;
    double dIntro_min, dIntro_mode, dIntro_max;
    double dPrior_min, dPrior_mode, dPrior_max;
    int nPu;
    int nCallbackValue;
    int nMinK;
    double dTrapDistance;

    /* get the command line arguments */
    if( argc != 17 )
    {
        fprintf( stderr, "proffreedom trapcsv parafile yearSeq niter nchewcardtraps datamask kmap pu minK trapDistance intro_min intro_likely intro_max prior_mean prior_sd\n" );
        fprintf( stderr, "where:\n" );
        fprintf( stderr, "trapcsv        = .csv file of trap information\n" );
        fprintf( stderr, "parafile       = text file of parameter information\n" );
        fprintf( stderr, "yearSeq        = comma sperated list of years\n" );
        fprintf( stderr, "niter          = number of iterations\n" );
        fprintf( stderr, "nchewcardtraps = number of traps per chewed card\n" );
        fprintf( stderr, "datamask       = ascii grid containing 1's where modelling to be carried out, 0 elsewhere\n" );
        fprintf( stderr, "kmap           = habitat preference map or NONE\n" );
        fprintf( stderr, "pu             = design prevalence(integer)\n" );
        fprintf( stderr, "minK           = Minimum K value to use in mapping\n");
        fprintf( stderr, "trapDistance   = the distance to buffer around traps in areas of low K\n");
        fprintf( stderr, "intro_min      = Minimum risk of introduction of adjacent areas\n" );
        fprintf( stderr, "intro_likely   = Mode risk of introduction of adjacent areas\n" );
        fprintf( stderr, "intro_max      = Maximum risk of introduction of adjacent areas\n" );
        fprintf( stderr, "prior_min      = Minimum of the initial prior value\n" );
        fprintf( stderr, "prior_likely   = Mode of the initial prior value\n" );
        fprintf( stderr, "prior_max      = Maximum of the initial prior value\n" );
        exit( 1 );
    }

    pszTrapCSV = argv[1];
    pszParaFile = argv[2];
    pszYearSeq = strdup(argv[3]);
    /* Turn pszYearSeq into an array of ints */
    /* First work out how many there are */
    /* strtok actually embeds \0's in the string */
    /* so we can't parse it twice so we take a copy */
    nYears = 0;
    pszCurrent = strtok( pszYearSeq, "," );
    while( pszCurrent != NULL )
    {
        pszCurrent = strtok( NULL, "," );
        nYears++;
    }
    free( pszYearSeq );
    pszYearSeq = strdup(argv[3]);
    /* now allocate memory and populate it */
    pnYearSeq = calloc( nYears, sizeof( int ) );
    nCurrentYear = 0;
    pszCurrent = strtok( pszYearSeq, "," );
    while( pszCurrent != NULL )
    {
        pnYearSeq[nCurrentYear] = atol( pszCurrent );
        pszCurrent = strtok( NULL, "," );
        nCurrentYear++;
    }
    free( pszYearSeq );

    /* Create the list of output sensitvity names */
    ppszSensitivityNames = calloc( nYears, sizeof( char* ) );
    for( nCurrentYear = 0; nCurrentYear < nYears; nCurrentYear++ )
    {
        nChars = snprintf( NULL, 0, "seui_%d.asc", pnYearSeq[nCurrentYear] );
        ppszSensitivityNames[nCurrentYear] = calloc( nChars + 1, sizeof( char ) );
        snprintf( ppszSensitivityNames[nCurrentYear], nChars + 1, "seui_%d.asc", pnYearSeq[nCurrentYear] );
    }

    nIter = atol( argv[4] );

    nChewcardTraps = atol( argv[5] );
    pszDataMask = argv[6];
    pszKMap = argv[7];
    nPu = atol( argv[8] );
    nMinK = atol( argv[9]);
    dTrapDistance = atof( argv[10] );

    /* convert these ones straight into a and b */
    dIntro_min = atof( argv[11] );
    dIntro_mode = atof( argv[12] );
    dIntro_max = atof( argv[13] );
    findBetaPert( dIntro_min, dIntro_mode, dIntro_max, PERT_SHAPE, &dIntro_a, &dIntro_b );
    dPrior_min = atof( argv[14] );
    dPrior_mode = atof( argv[15] );
    dPrior_max = atof( argv[16] );
    findBetaPert( dPrior_min, dPrior_mode, dPrior_max, PERT_SHAPE, &dPrior_a, &dPrior_b );

    /* read in the data files */
    nTraps = readTrapCSV( pszTrapCSV, &pTrapData, &pnSurveillanceYearSeq, 
                            &nSurveillanceYears, &pszMessage );
    if( nTraps == 0 )
    {
        fprintf( stderr, "Unable to read trap csv file %s. Message was %s\n", pszTrapCSV, pszMessage );
        free( pszMessage );
        exit( 1 );
    }

    if( ! readParameters( pszParaFile, &pParameters ) )
    {
        fprintf( stderr, "Unable to read parameter file %s\n", pszParaFile );
        exit( 1 );
    }

    pMaskRaster = createMaskRasterFromFile( pszDataMask );
    if( pMaskRaster == NULL )
    {
        fprintf( stderr, "Unable to read mask %s\n", pszDataMask );
        exit( 1 );
    }
    pKMapRaster = NULL;
    if( strcmp( pszKMap, "NONE" ) != 0 )
    {
        pKMapRaster = createRasterFromFile( pszKMap );
        if( pKMapRaster == NULL )
        {
            fprintf( stderr, "Unable to read kmap %s\n", pszKMap );
            exit( 1 );
        }
        /* add 1 to all k values to avoid divide by zero errors */
        addConstant(pKMapRaster, 1.0);
        /* increment this also */
        nMinK++;

        if( dTrapDistance > 0 )
        {
            /* Need to buffer around traps */
            maskKMap(pTrapData, nTraps, pnYearSeq, nYears, pKMapRaster, pMaskRaster, nMinK, dTrapDistance);
        }
    }

    /* Allocate the output rasters */
    pSSeMat = createRaster( nYears, nIter, 0, 0, 0 );
    pPoFMat = createRaster( nYears, nIter, 0, 0, 0 );

    /* do the processing */
    if( proffreedom( pTrapData, nTraps, pParameters, pnYearSeq, nYears, 
                    pnSurveillanceYearSeq, nSurveillanceYears, nIter,
                    nChewcardTraps, pMaskRaster, pKMapRaster, nPu, 
                    dIntro_a, dIntro_b, dIntro_min, dIntro_max,
                    dPrior_a, dPrior_b, dPrior_min, dPrior_max,
                    ppszSensitivityNames, pSSeMat, pPoFMat,
                    &stdout_percent, &new_values, NULL, &pszMessage, &nCallbackValue ) )
    {
        /* write output .csv files */
        rasterWriteToCSV( pSSeMat, "sse.csv" );
        rasterWriteToCSV( pPoFMat, "pof.csv" );
        fprintf( stderr, "\n" );
    }
    else
    {
        fprintf( stderr, "Failed. Message was %s callback value was %d\n", pszMessage, nCallbackValue );
        free( pszMessage );
    }

    /* free memory */
    free( pTrapData );
    free( pParameters );
    free( pnYearSeq );
    free( pnSurveillanceYearSeq );
    for( nCurrentYear = 0; nCurrentYear < nYears; nCurrentYear++ )
        free( ppszSensitivityNames[nCurrentYear] );
    free( ppszSensitivityNames );
    destroyMaskRaster( pMaskRaster );
    if( pKMapRaster != NULL )
        destroyRaster( pKMapRaster );
    destroyRaster( pSSeMat );
    destroyRaster( pPoFMat );
    
    return 0;
}
