
#include <Python.h>
#include "structmember.h"

#include "types.h"
#include "fileio.h"
#include "raster.h"
#include "proffreedom.h"
#include "maskutils.h"

#define POF_VERSION 0.92

/* A new Python Object ('Parameters') implemented in C */
/* Contains the 'parameters' to the Pr of Freedom calculations */
/* ie the inputs that are numeric */
typedef struct {
    PyObject_HEAD

    /* one sParameter struct for each species */
    struct sParameter aParameters[NSPECIES];

    int nPu;
    double dPrior_a;
    double dPrior_b;
    double dPrior_min;
    double dPrior_max;
    double dIntro_a;
    double dIntro_b;
    double dIntro_min;
    double dIntro_max;
    int nIter;
    int nChewcardTraps;

} pof_Parameters;

/* An exception object for this module */
/* created in the init function */
static PyObject *POFError;

/* Below are methods on the Python Parameters object */
static PyObject*
parameters_setNumIterations(pof_Parameters* self, PyObject *args)
{
    int nIter;

    if( !PyArg_ParseTuple(args, "i", &nIter) )
    {
        PyErr_SetString( POFError, "Must pass integer type" );
        return NULL;
    }

    self->nIter = nIter;

    Py_RETURN_NONE;
}

static PyObject*
parameters_setNumChewcardTraps(pof_Parameters* self, PyObject *args)
{
    int nChewcardTraps;

    if( !PyArg_ParseTuple(args, "i", &nChewcardTraps) )
    {
        PyErr_SetString( POFError, "Must pass integer type" );
        return NULL;
    }

    self->nChewcardTraps = nChewcardTraps;

    Py_RETURN_NONE;
}


static PyObject*
parameters_setPu(pof_Parameters* self, PyObject *args)
{
    int nPu;

    if( !PyArg_ParseTuple(args, "i", &nPu) )
    {
        PyErr_SetString( POFError, "Must pass integer type" );
        return NULL;
    }

    self->nPu = nPu;

    Py_RETURN_NONE;
}

static PyObject*
parameters_setPrior(pof_Parameters* self, PyObject *args)
{
    double dMin, dMode, dMax;

    if( !PyArg_ParseTuple(args, "ddd", &dMin, &dMode, &dMax) )
    {
        PyErr_SetString( POFError, "Must pass 3 floating point numbers" );
        return NULL;
    }

    findBetaPert( dMin, dMode, dMax, PERT_SHAPE, &self->dPrior_a, &self->dPrior_b );
    self->dPrior_min = dMin;
    self->dPrior_max = dMax;

    Py_RETURN_NONE;
}

static PyObject*
parameters_setIntro(pof_Parameters* self, PyObject *args)
{
    double dMin, dMode, dMax;

    if( !PyArg_ParseTuple(args, "ddd", &dMin, &dMode, &dMax) )
    {
        PyErr_SetString( POFError, "Must pass 3 floating point numbers" );
        return NULL;
    }

    findBetaPert( dMin, dMode, dMax, PERT_SHAPE, &self->dIntro_a, &self->dIntro_b );
    self->dIntro_min = dMin;
    self->dIntro_max = dMax;

    Py_RETURN_NONE;
}

static PyObject*
parameters_setSigma(pof_Parameters* self, PyObject *args)
{
    int nSpecies;
    double dMean, dStd;

    if( !PyArg_ParseTuple(args, "idd", &nSpecies, &dMean, &dStd) )
    {
        PyErr_SetString( POFError, "Must pass a species number and two floating point numbers" );
        return NULL;
    }
    else if( ( nSpecies < possum ) || ( nSpecies > reddeer ) )
    {
        PyErr_SetString( POFError, "species must be one of the constants defined in this module" );
        return NULL;
    }

    self->aParameters[nSpecies].mean_sig = dMean;
    self->aParameters[nSpecies].sd_sig = dStd;
    
    Py_RETURN_NONE;
}

static PyObject*
parameters_setChewCard(pof_Parameters* self, PyObject *args)
{
    int nSpecies;
    double dMean, dStd;

    if( !PyArg_ParseTuple(args, "idd", &nSpecies, &dMean, &dStd) )
    {
        PyErr_SetString( POFError, "Must pass a species number and two floating point numbers" );
        return NULL;
    }
    else if( ( nSpecies < possum ) || ( nSpecies > reddeer ) )
    {
        PyErr_SetString( POFError, "species must be one of the constants defined in this module" );
        return NULL;
    }

    self->aParameters[nSpecies].mean_CC = dMean;
    self->aParameters[nSpecies].sd_CC = dStd;
    findBeta( dMean, dStd, &self->aParameters[nSpecies].a_CC, &self->aParameters[nSpecies].b_CC );
    
    Py_RETURN_NONE;
}

static PyObject*
parameters_setCapture(pof_Parameters* self, PyObject *args)
{
    int nSpecies;
    double dMean, dStd;

    if( !PyArg_ParseTuple(args, "idd", &nSpecies, &dMean, &dStd) )
    {
        PyErr_SetString( POFError, "Must pass a species number and two floating point numbers" );
        return NULL;
    }
    else if( ( nSpecies < possum ) || ( nSpecies > reddeer ) )
    {
        PyErr_SetString( POFError, "species must be one of the constants defined in this module" );
        return NULL;
    }

    self->aParameters[nSpecies].mean_capt = dMean;
    self->aParameters[nSpecies].sd_capt = dStd;
    findBeta( dMean, dStd, &self->aParameters[nSpecies].a_capt, &self->aParameters[nSpecies].b_capt );
    
    Py_RETURN_NONE;
}

static PyObject*
parameters_setTest(pof_Parameters* self, PyObject *args)
{
    int nSpecies;
    double dMean, dStd;

    if( !PyArg_ParseTuple(args, "idd", &nSpecies, &dMean, &dStd) )
    {
        PyErr_SetString( POFError, "Must pass a species number and two floating point numbers" );
        return NULL;
    }
    else if( ( nSpecies < possum ) || ( nSpecies > reddeer ) )
    {
        PyErr_SetString( POFError, "species must be one of the constants defined in this module" );
        return NULL;
    }

    self->aParameters[nSpecies].mean_test = dMean;
    self->aParameters[nSpecies].sd_test = dStd;
    findBeta( dMean, dStd, &self->aParameters[nSpecies].a_test, &self->aParameters[nSpecies].b_test );
    
    Py_RETURN_NONE;
}

static PyObject*
parameters_setInfect(pof_Parameters* self, PyObject *args)
{
    int nSpecies;
    double dMean, dStd;

    if( !PyArg_ParseTuple(args, "idd", &nSpecies, &dMean, &dStd) )
    {
        PyErr_SetString( POFError, "Must pass a species number and two floating point numbers" );
        return NULL;
    }
    else if( ( nSpecies < possum ) || ( nSpecies > reddeer ) )
    {
        PyErr_SetString( POFError, "species must be one of the constants defined in this module" );
        return NULL;
    }

    self->aParameters[nSpecies].mean_infect = dMean;
    self->aParameters[nSpecies].sd_infect = dStd;
    findBeta( dMean, dStd, &self->aParameters[nSpecies].a_infect, &self->aParameters[nSpecies].b_infect );
    
    Py_RETURN_NONE;
}

static PyObject*
parameters_printParameters(pof_Parameters* self, PyObject *args)
{
    printParameters(self->aParameters);
    Py_RETURN_NONE;
}

/* This structure relates the names of the functions to the C code to execute them */
static PyMethodDef parameters_methods[] = {
    {"setNumIterations", (PyCFunction)parameters_setNumIterations, METH_VARARGS, 
        "Set the number of iterations setNumIterations(niter)"},
    {"setNumChewcardTraps", (PyCFunction)parameters_setNumChewcardTraps, METH_VARARGS, 
        "Set the number of traps per chewed card setNumChewcardTraps(nchewcardtraps)"},
    {"setPu", (PyCFunction)parameters_setPu, METH_VARARGS, 
        "Set the Pu parameter setPu(pu)"},
    {"setPrior", (PyCFunction)parameters_setPrior, METH_VARARGS, 
        "Set the Prior parameter setPrior(mean,sd)"},
    {"setIntro", (PyCFunction)parameters_setIntro, METH_VARARGS, 
        "Set the Intro parameter setIntro(mean,sd)"},
    {"setSigma", (PyCFunction)parameters_setSigma, METH_VARARGS, 
        "Set the Sigma parameter for given species setSigma(species,mean,sd)"},
    {"setChewCard", (PyCFunction)parameters_setChewCard, METH_VARARGS, 
        "Set the ChewCard parameter for given species setChewCard(species,mean,sd)"},
    {"setCapture", (PyCFunction)parameters_setCapture, METH_VARARGS, 
        "Set the Capture parameter for given species setCapture(species,mean,sd)"},
    {"setTest", (PyCFunction)parameters_setTest, METH_VARARGS, 
        "Set the Test parameter for given species setTest(species,mean,sd)"},
    {"setInfect", (PyCFunction)parameters_setInfect, METH_VARARGS, 
        "Set the Infect parameter for given species setInfect(species,mean,sd)"},
    {"printParameters", (PyCFunction)parameters_printParameters, METH_NOARGS,
        "Print the parameters to stdout"},
    {NULL}  /* Sentinel */
};

/* This structure defines the new Python 'type' for the object */
/* AFAIK each Python object must have a type */
/* This tells Python what the object is called and what methods are available */
static PyTypeObject pof_ParametersType = {
    PyObject_HEAD_INIT(NULL)
    0,                         /*ob_size*/
    "wlife_pof.Parameters",             /*tp_name*/
    sizeof(pof_Parameters), /*tp_basicsize*/
    0,                         /*tp_itemsize*/
    0,                         /*tp_dealloc*/
    0,                         /*tp_print*/
    0,                         /*tp_getattr*/
    0,                         /*tp_setattr*/
    0,                         /*tp_compare*/
    0,                         /*tp_repr*/
    0,                         /*tp_as_number*/
    0,                         /*tp_as_sequence*/
    0,                         /*tp_as_mapping*/
    0,                         /*tp_hash */
    0,                         /*tp_call*/
    0,                         /*tp_str*/
    0,                         /*tp_getattro*/
    0,                         /*tp_setattro*/
    0,                         /*tp_as_buffer*/
    Py_TPFLAGS_DEFAULT,        /*tp_flags*/
    "Parameter object",           /* tp_doc */
    0,                     /* tp_traverse */
    0,                     /* tp_clear */
    0,                     /* tp_richcompare */
    0,                     /* tp_weaklistoffset */
    0,                     /* tp_iter */
    0,                     /* tp_iternext */
    parameters_methods,             /* tp_methods */
};

/* Some constants that we can return from the callback  */
/* And trap the conditions on return from main function */
#define CALLBACK_FALSE 1
#define CALLBACK_EXCEPTION 2

/* These callback functions are called by the proffreedom C function */
/* A pointer to the callback object is passed in the pData parameter */
int callback_percent( int nPercent, void *pData )
{
    PyObject *pCallback;
    PyObject *pResult;
    int nVal;

    pCallback = (PyObject*)pData;

    /* call the function 'progress' on the object */
    pResult = PyObject_CallMethod( pCallback, "progress", "(i)", nPercent );
    if( pResult == NULL )
    {
        /* callback has raised an exception */
        nVal = CALLBACK_EXCEPTION;
    }
    else
    {
        if( PyObject_Not( pResult ) )
        {
            /* user cancel */
            nVal = CALLBACK_FALSE;
        }
        else
        {
            nVal = 0;
        }
        Py_DECREF( pResult );
    }
    return nVal;
}

int callback_new_values(double dTotalAR, double dAverageSensitivity, int nSearched, int nTotal, void *pData )
{
    PyObject *pCallback;
    PyObject *pResult;
    int nVal;

    pCallback = (PyObject*)pData;

    /* call the function newValues on the object */
    pResult = PyObject_CallMethod( pCallback, "newValues", "(ddii)", 
                    dTotalAR, dAverageSensitivity, nSearched, nTotal );
    if( pResult == NULL )
    {
        /* callback has raised an exception */
        nVal = CALLBACK_EXCEPTION;
    }
    else
    {
        if( PyObject_Not( pResult ) )
        {
            /* user cancel */
            nVal = CALLBACK_FALSE;
        }
        else
        {
            nVal = 0;
        }
        Py_DECREF( pResult );
    }
    return nVal;
}

/* Main function of the module */
/* calls the C proffreedom function */
static PyObject*
wlife_pof_proffreedom(PyObject *self, PyObject *args)
{
    PyObject *pYearList;
    PyObject *pCallbackObj;
    PyObject *pPyParameters;
    const char *pszTrapCSV;
    const char *pszMask;
    const char *pszKMap;
    const char *pszOutSSE;
    const char *pszOutPOF;
    PyObject *pSeUIList;

    PyObject *pListItem;

    int *pnSurveillanceYearSeq;
    int nSurveillanceYears, nTraps;
    int *pnYearSeq, nYears;
    int i;
    struct sTrapData *pTrapData;
    char *pszMessage;
    char **ppszSensitivityNames;
    struct sMaskRaster *pMaskRaster;
    struct sRaster *pKMapRaster;
    struct sRaster *pSSeMat, *pPoFMat;
    pof_Parameters *pParameters;
    int nCallbackValue;
    
    /* get the arguments out of the passed in tuple */
    if( !PyArg_ParseTuple(args, "OOOsszssO", &pYearList, &pCallbackObj, &pPyParameters, 
            &pszTrapCSV, &pszMask, &pszKMap, &pszOutSSE, &pszOutPOF, &pSeUIList) )
    {
        PyErr_SetString( POFError, "Must pass a list, 2 objects and 5 strings, then a list" );
        return NULL;
    }

    /* check that the parameters object is of our type */
    if( !PyObject_TypeCheck( pPyParameters, &pof_ParametersType) )
    {
        PyErr_SetString( PyExc_TypeError, "3rd parameter must be of type wlife_pof.Parameters" );
        return NULL;
    }

    /* Cast from PyObject to our type and hold on to a reference */
    pParameters = (pof_Parameters*)pPyParameters;
    Py_INCREF(pParameters);

    /* check the list of years is indeed a list */
    if( !PyList_Check( pYearList ) )
    {
        PyErr_SetString( POFError, "First argument must be list" );
        Py_DECREF(pParameters); 
        return NULL;
    }

    /* increment the reference to the callback just in case the object */
    /* is dereferenced somewhere else during the processing */
    Py_INCREF(pCallbackObj);

    /* process the list of years and turn it into a C array */
    nYears = PyList_Size( pYearList );
    pnYearSeq = calloc( nYears, sizeof( int ) );
    for( i = 0; i < nYears; i++ )
    {
        /* get the i'th element */
        pListItem = PyList_GetItem( pYearList, i );
        if( pListItem == NULL )
        {
            PyErr_SetString( POFError, "Could not get item from list of years" );
            free( pnYearSeq );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);
            return NULL;
        }

        /* check that it is actually an int */
        if( !PyInt_Check( pListItem ) )
        {
            PyErr_SetString( PyExc_ValueError, "List of years must only contain ints" );
            free( pnYearSeq );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);
            return NULL;
        }

        /* set that item in the array */
        pnYearSeq[i] = PyInt_AsLong( pListItem );
    }

    /* read in the traps file */
    nTraps = readTrapCSV( pszTrapCSV, &pTrapData, &pnSurveillanceYearSeq, 
                            &nSurveillanceYears, &pszMessage );
    if( nTraps == 0 )
    {
        PyErr_SetString( POFError, pszMessage );
        free( pszMessage );
        free( pnYearSeq );
        Py_DECREF(pCallbackObj);
        Py_DECREF(pParameters);
        return NULL;
    }

    /* read in the mask */
    pMaskRaster = createMaskRasterFromFile( pszMask );
    if( pMaskRaster == NULL )
    {
        PyErr_SetString( POFError, "Unable to read mask file" );
        free( pnYearSeq );
        free( pnSurveillanceYearSeq );
        free( pTrapData );
        Py_DECREF(pCallbackObj);
        Py_DECREF(pParameters);
        return NULL;
    }

    /* Read in kmap if exists */
    pKMapRaster = NULL;
    if( pszKMap != NULL )
    {
        pKMapRaster = createRasterFromFile( pszKMap );
        if( pKMapRaster == NULL )
        {
            PyErr_SetString( POFError, "unable to read kmap file" );
            free( pnYearSeq );
            free( pnSurveillanceYearSeq );
            free( pTrapData );
            destroyMaskRaster( pMaskRaster );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);
            return NULL;
        }
    }

    /* process the list of output seui names */
    if( !PyList_Check( pSeUIList ) || ( PyList_Size( pSeUIList ) != nYears ) )
    {
        PyErr_SetString( POFError, "last argument must be list of same length as yearList" );
        free( pnYearSeq );
        free( pnSurveillanceYearSeq );
        free( pTrapData );
        destroyMaskRaster( pMaskRaster );
        if( pKMapRaster != NULL )
            destroyRaster( pKMapRaster );
        Py_DECREF(pCallbackObj);
        Py_DECREF(pParameters);
        return NULL;
    }

    ppszSensitivityNames = calloc( nYears, sizeof( char* ) );
    for( i = 0; i < nYears; i++ )
    {
        pListItem = PyList_GetItem( pSeUIList, i );
        if( pListItem == NULL )
        {
            PyErr_SetString( POFError, "Could not get item from list of sensitivities" );
            free( pnYearSeq );
            free( pnSurveillanceYearSeq );
            free( pTrapData );
            destroyMaskRaster( pMaskRaster );
            if( pKMapRaster != NULL )
                destroyRaster( pKMapRaster );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);
            return NULL;
        }

        if( !PyString_Check( pListItem ) )
        {
            PyErr_SetString( POFError, "list of sensitivities must contain strings" );
            free( pnYearSeq );
            free( pnSurveillanceYearSeq );
            free( pTrapData );
            destroyMaskRaster( pMaskRaster );
            if( pKMapRaster != NULL )
                destroyRaster( pKMapRaster );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);
            return NULL;
        }

        ppszSensitivityNames[i] = strdup( PyString_AsString( pListItem ) );
    }

    /* Allocate the output rasters */
    pSSeMat = createRaster( nYears, pParameters->nIter, 0, 0, 0 );
    pPoFMat = createRaster( nYears, pParameters->nIter, 0, 0, 0 );


    /* do the processing */
    if( proffreedom( pTrapData, nTraps, pParameters->aParameters, pnYearSeq, nYears, 
                    pnSurveillanceYearSeq, nSurveillanceYears,
                    pParameters->nIter, pParameters->nChewcardTraps, 
                    pMaskRaster, pKMapRaster, pParameters->nPu, 
                    pParameters->dIntro_a, pParameters->dIntro_b, 
                    pParameters->dIntro_min, pParameters->dIntro_max,
                    pParameters->dPrior_a, pParameters->dPrior_b,
                    pParameters->dPrior_min, pParameters->dPrior_max,
                    ppszSensitivityNames, pSSeMat, pPoFMat,
                    &callback_percent, &callback_new_values, pCallbackObj, &pszMessage, &nCallbackValue ) )
    {
        /* write output rasters */
        if( !rasterWriteToCSV( pSSeMat, pszOutSSE ) ||
            !rasterWriteToCSV( pPoFMat, pszOutPOF ) )
        {
            /* Error writing output */
            free( pnYearSeq );
            free( pnSurveillanceYearSeq );
            for( i = 0; i < nYears; i++ )
                free( ppszSensitivityNames[i] );
            free( ppszSensitivityNames );
            free( pTrapData );
            destroyMaskRaster( pMaskRaster );
            if( pKMapRaster != NULL )
                destroyRaster( pKMapRaster );
            destroyRaster( pSSeMat );
            destroyRaster( pPoFMat );
            Py_DECREF(pCallbackObj);
            Py_DECREF(pParameters);

            PyErr_SetString( POFError, "Error writing output" );
            return NULL;
        }
    }
    else
    {
        /* An error was reported or user cancel */
        /* cleanup first */
        free( pnYearSeq );
        free( pnSurveillanceYearSeq );
        for( i = 0; i < nYears; i++ )
            free( ppszSensitivityNames[i] );
        free( ppszSensitivityNames );
        free( pTrapData );
        destroyMaskRaster( pMaskRaster );
        if( pKMapRaster != NULL )
            destroyRaster( pKMapRaster );
        destroyRaster( pSSeMat );
        destroyRaster( pPoFMat );
        Py_DECREF(pCallbackObj);
        Py_DECREF(pParameters);

        if( nCallbackValue == 0 )
        {
            /* genuine error - raise exception */
            PyErr_SetString( POFError, pszMessage );
            free( pszMessage );
            return NULL;
        }
        else if( nCallbackValue == CALLBACK_EXCEPTION )
        {
            /* an exception was raised in the callback */
            /* exception should already be set - just return NULL */
            return NULL;
        }
        else
        {
            /* user cancelled - tell caller */
            Py_RETURN_FALSE;
        }
    }

    /* free the C arrays*/
    free( pnYearSeq );
    free( pnSurveillanceYearSeq );
    for( i = 0; i < nYears; i++ )
        free( ppszSensitivityNames[i] );
    free( ppszSensitivityNames );
    free( pTrapData );
    destroyMaskRaster( pMaskRaster );
    if( pKMapRaster != NULL )
        destroyRaster( pKMapRaster );
    destroyRaster( pSSeMat );
    destroyRaster( pPoFMat );
    
    /* Finished with the Python objects */
    Py_DECREF(pCallbackObj);
    Py_DECREF(pParameters);

    Py_RETURN_TRUE;
}

/* masking function */
static PyObject*
wlife_pof_maskbyK(PyObject *self, PyObject *args)
{
    PyObject *pYearList;
    const char *pszTrapCSV;
    const char *pszMask;
    const char *pszKMap;
    const char *pszOutMask;
    const char *pszOutKMap;
    int nMinK;
    double dDistance;
    PyObject *pListItem;
    struct sMaskRaster *pMaskRaster;
    struct sRaster *pKMapRaster;
    char *pszMessage;

    int *pnSurveillanceYearSeq;
    int nSurveillanceYears, nTraps;
    int *pnYearSeq, nYears, i;
    struct sTrapData *pTrapData;

    /* get the arguments out of the passed in tuple */
    if( !PyArg_ParseTuple(args, "Osssidss", &pYearList, &pszTrapCSV, &pszMask, &pszKMap, 
            &nMinK, &dDistance, &pszOutMask, &pszOutKMap) )
    {
        PyErr_SetString( POFError, "Must pass a list, three strings, an int, a double and 2 strings" );
        return NULL;
    }

    /* check the list of years is indeed a list */
    if( !PyList_Check( pYearList ) )
    {
        PyErr_SetString( POFError, "First argument must be list" );
        return NULL;
    }

    /* process the list of years and turn it into a C array */
    nYears = PyList_Size( pYearList );
    pnYearSeq = calloc( nYears, sizeof( int ) );
    for( i = 0; i < nYears; i++ )
    {
        /* get the i'th element */
        pListItem = PyList_GetItem( pYearList, i );
        if( pListItem == NULL )
        {
            PyErr_SetString( POFError, "Could not get item from list of years" );
            free( pnYearSeq );
            Py_DECREF(pYearList); 
            return NULL;
        }

        /* check that it is actually an int */
        if( !PyInt_Check( pListItem ) )
        {
            PyErr_SetString( PyExc_ValueError, "List of years must only contain ints" );
            free( pnYearSeq );
            Py_DECREF(pYearList); 
            return NULL;
        }

        /* set that item in the array */
        pnYearSeq[i] = PyInt_AsLong( pListItem );
    }

    /* read in the traps file */
    nTraps = readTrapCSV( pszTrapCSV, &pTrapData, &pnSurveillanceYearSeq, 
                            &nSurveillanceYears, &pszMessage );
    if( nTraps == 0 )
    {
        PyErr_SetString( POFError, pszMessage );
        free( pszMessage );
        free( pnYearSeq );
        return NULL;
    }

    /* read in the mask */
    pMaskRaster = createMaskRasterFromFile( pszMask );
    if( pMaskRaster == NULL )
    {
        PyErr_SetString( POFError, "Unable to read mask file" );
        free( pnYearSeq );
        free( pnSurveillanceYearSeq );
        free( pTrapData );
        return NULL;
    }

    /* Read in kmap */
    pKMapRaster = createRasterFromFile( pszKMap );
    if( pKMapRaster == NULL )
    {
        PyErr_SetString( POFError, "unable to read kmap file" );
        free( pnYearSeq );
        free( pnSurveillanceYearSeq );
        free( pTrapData );
        destroyMaskRaster( pMaskRaster );
        return NULL;
    }    

    /* run it */
	maskKMap( pTrapData, nTraps, pnYearSeq, nYears, pKMapRaster, pMaskRaster, nMinK, dDistance );   

	/* write out */
	maskRasterWriteToFile( pMaskRaster, pszOutMask);
    rasterWriteToFile( pKMapRaster, pszOutKMap);

    /* free memory */
    free( pTrapData );
	free( pnSurveillanceYearSeq );
	free(pnYearSeq);
	destroyMaskRaster(pMaskRaster);
	destroyRaster( pKMapRaster);

    Py_RETURN_NONE;
}

static PyObject*
wlif_pof_combine_sens(PyObject *self, PyObject *args)
{
PyObject *pInputList, *pListItem;
const char *pszOutput, *pszMask;
char *pszFilename;
int nItems, n, j, x, y;
struct sRaster **pInRasters, *pOutRaster;
struct sMaskRaster *pMaskRaster;
double prod;

    /* get the arguments out of the passed in tuple */
    if( !PyArg_ParseTuple(args, "Oss", &pInputList, &pszMask, &pszOutput ) )
    {
        PyErr_SetString( POFError, "Must pass a list and 2 strings" );
        return NULL;
    }

    /* check the list of sensitivity rasters is indeed a list */
    if( !PyList_Check( pInputList ) )
    {
        PyErr_SetString( POFError, "First argument must be list" );
        return NULL;
    }

    /* Read in the rasters */
    nItems = PyList_Size( pInputList );
    pInRasters = (struct sRaster **)calloc(nItems, sizeof(struct sRaster *));
    for( n = 0; n < nItems; n++ )
    {
        pListItem = PyList_GetItem(pInputList, n);
        if( !PyString_Check(pListItem) )
        {
            PyErr_SetString( POFError, "list must contain strings" );
            for( j = 0; j < n; j++ )
                destroyRaster(pInRasters[j]);
            free(pInRasters);
            return NULL;
        }
        
        pszFilename = PyString_AS_STRING(pListItem);
        pInRasters[n] = createRasterFromFile( pszFilename );
        if( pInRasters[n] == NULL )
        {
            PyErr_Format( POFError, "unable to read %s", pszFilename );
            for( j = 0; j < n; j++ )
                destroyRaster(pInRasters[j]);
            free(pInRasters);
            return NULL;
        }
    
    }
    
    /* Read in the mask */
    pMaskRaster = createMaskRasterFromFile( pszMask );
    if( pMaskRaster == NULL )
    {
        PyErr_Format( POFError, "unable to read %s", pszMask );
        for( j = 0; j < nItems; j++ )
            destroyRaster(pInRasters[j]);
        free(pInRasters);
        return NULL;
    }
    
    /* Check all same size etc */
    if( (pInRasters[0]->nColumns != pMaskRaster->nColumns ) ||
        ( pInRasters[0]->nRows != pMaskRaster->nRows ) ||
        ( pInRasters[0]->xllcorner != pMaskRaster->xllcorner ) || 
        ( pInRasters[0]->yllcorner != pMaskRaster->yllcorner ) ||
        ( pInRasters[0]->resolution != pMaskRaster->resolution ) )
    {
        PyErr_SetString( POFError, "Input mask raster doesn't match" );
        for( j = 0; j < nItems; j++ )
            destroyRaster(pInRasters[j]);
        free(pInRasters);
        destroyMaskRaster( pMaskRaster );
        return NULL;
    }


    for( n = 1; n < nItems; n++ )
    {
        if( (pInRasters[0]->nColumns != pInRasters[n]->nColumns ) ||
            ( pInRasters[0]->nRows != pInRasters[n]->nRows ) ||
            ( pInRasters[0]->xllcorner != pInRasters[n]->xllcorner ) || 
            ( pInRasters[0]->yllcorner != pInRasters[n]->yllcorner ) ||
            ( pInRasters[0]->resolution != pInRasters[n]->resolution ) )
        {
            PyErr_SetString( POFError, "Input rasters don't match" );
            for( j = 0; j < nItems; j++ )
                destroyRaster(pInRasters[j]);
            free(pInRasters);
            destroyMaskRaster( pMaskRaster );
            return NULL;
        }
    }
    
    /* Create output */
    pOutRaster = createRaster( pInRasters[0]->nColumns, pInRasters[0]->nRows,
                                pInRasters[0]->xllcorner, pInRasters[0]->yllcorner,
                                pInRasters[0]->resolution );
    
    /* C_Se = 1-product(1-Sei) */
    for( y = 0; y < pOutRaster->nRows; y++ )
    {
        for( x = 0; x < pOutRaster->nColumns; x++ )
        {
            if( maskRasterGetValue(pMaskRaster, x, y ) != 0 )
            {
                prod = 1.0;
                for( n = 0; n < nItems; n++ )
                {
                    prod *= (1.0 - rasterGetValue( pInRasters[n], x, y));
                }
                rasterSetValue( pOutRaster, x, y, 1.0 - prod);
            }
        }
    }
    
    /* Write out */
    rasterWriteToFile( pOutRaster, pszOutput );
    
    /* cleanup */
    destroyRaster(pOutRaster);
    destroyMaskRaster( pMaskRaster );
    for( n = 0; n < nItems; n++ )
    {
        destroyRaster(pInRasters[n]);
    }
    free(pInRasters);
    
    Py_RETURN_NONE;
}

static PyObject*
wlif_pof_add_const(PyObject *self, PyObject *args)
{
const char *pszInput, *pszOutput;
double dConst;
struct sRaster *pRaster;

    /* get the arguments out of the passed in tuple */
    if( !PyArg_ParseTuple(args, "ssd", &pszInput, &pszOutput, &dConst ) )
    {
        PyErr_SetString( POFError, "Must pass 2 strings and a number" );
        return NULL;
    }
    
    pRaster = createRasterFromFile( pszInput );
    if( pRaster == NULL )
    {
        PyErr_Format( POFError, "unable to read %s", pszInput );
        return NULL;
    }
    
    addConstant(pRaster, dConst);
    
    rasterWriteToFile( pRaster, pszOutput );

    destroyRaster(pRaster);

    Py_RETURN_NONE;
}

static PyObject*
wlif_pof_mask_raster(PyObject *self, PyObject *args)
{
const char *pszInput, *pszOutput, *pszMask;
struct sRaster *pRaster;
struct sMaskRaster *pMaskRaster;

    /* get the arguments out of the passed in tuple */
    if( !PyArg_ParseTuple(args, "sss", &pszInput, &pszOutput, &pszMask ) )
    {
        PyErr_SetString( POFError, "Must pass 3 strings" );
        return NULL;
    }

    pRaster = createRasterFromFile( pszInput );
    if( pRaster == NULL )
    {
        PyErr_Format( POFError, "unable to read %s", pszInput );
        return NULL;
    }

    pMaskRaster = createMaskRasterFromFile( pszMask );
    if( pMaskRaster == NULL )
    {
        destroyRaster(pRaster);
        PyErr_Format( POFError, "unable to read %s", pszMask );
        return NULL;
    }
    
    maskRaster(pRaster, pMaskRaster);

    rasterWriteToFile( pRaster, pszOutput );

    destroyRaster(pRaster);
    destroyMaskRaster(pMaskRaster);
    
    Py_RETURN_NONE;
}

static PyMethodDef module_methods[] = {
    {"proffreedom", wlife_pof_proffreedom, METH_VARARGS,
        "Perform the Probability of Freedom Calculations. Call signature:\n"
        "proffreedom(yearList, callbackObj, parameterObj, csv, mask, kmap, sse, pof, seui)\n"
        "where:\n"
        "yearList     A list of years\n"
        "callbackObj  A Python object with 2 functions: 'progress' and 'newValues'\n"
        "parameterObj A Python object of type wlife_pof.Parameters that contains the parameters for this run\n"
        "csv          Path to the csv file that defines the traps\n"
        "mask         Path to the ascii grid that contains the mask of valid data\n"
        "kmap         Path to the ascii grid that contains the kmap. None if not available\n"
        "sse          Path to output csv containing the sensitivity numbers of the total system\n"
        "pof          Path to output csv containing the probability of freedom\n"
        "seui         A list of output ascii grid file names which will contain the sensitivity numbers for each pixel\n"
        "               Should be the same length as yearList\n"},
    {"maskbyK", wlife_pof_maskbyK, METH_VARARGS,
        "Mask by K and distance from habitat. Call signature:\n"
        "maskbyK(yearList, csv, mask, kmap, minK, distance, outmask)\n"
        "where:\n"
        "yearList     A list of years\n"
        "csv          Path to the csv file that defines the traps\n"
        "mask         Path to the ascii grid that contains the mask of valid data\n"
        "kmap         Path to the ascii grid that contains the kmap. None if not available\n"
        "minK         minimum value of K. Mask is set to 0 for values less than this\n"
        "distance     distance from trap. Mask set to 1 for cells less than this distance\n"
        "outmask      Path to output mask file\n"},
    {"combine_sens", wlif_pof_combine_sens, METH_VARARGS,
        "Combine sensitivity rasters. Call signature:\n"
        "combine_sens(seui, mask, outsens)\n"
        "where:\n"
        "seui         A list of sensitivity rasters\n"
        "mask         Path to the ascii grid that contains the mask of valid data\n"
        "outsens      Path to output combined rasters"},
    {"add_const", wlif_pof_add_const, METH_VARARGS,
        "Add a constant to a raster. Call signature:\n"
        "add_const(inraster, outraster, constant)\n"
        "where:\n"
        "inraster       Path to the input ascii grid\n"
        "outraster      Path to the output ascii grid\n"
        "constant   Value"},
    {"mask_raster", wlif_pof_mask_raster, METH_VARARGS,
        "Mask a raster. Call signature:\n"
        "mask_raster(inraster, outraster, maskraster)\n"
        "where:\n"
        "inraster       Path to the input ascii grid\n"
        "outraster      Path to the output ascii grid\n"
        "maskraster     Path to mask raster"},
    {NULL}  /* Sentinel */
};

/* the 'init' function */
/* register our type */
#ifndef PyMODINIT_FUNC  /* declarations for DLL import/export */
#define PyMODINIT_FUNC void
#endif
PyMODINIT_FUNC
initwlife_pof(void) 
{
    PyObject* m, *version;

    /* initialize our new type */
    pof_ParametersType.tp_new = PyType_GenericNew;
    if (PyType_Ready(&pof_ParametersType) < 0)
        return;

    /* Initialize this module */
    m = Py_InitModule3("wlife_pof", module_methods,
                       "Module containing interface onto Probability of Freedom calculations");

    /* Add our type to the module */
    Py_INCREF(&pof_ParametersType);
    PyModule_AddObject(m, "Parameters", (PyObject *)&pof_ParametersType);

    /* Create and add our exception type */
    POFError = PyErr_NewException("wlife_pof.error", NULL, NULL);
    Py_INCREF(POFError);
    PyModule_AddObject(m, "error", POFError);

    /* Add some constants that define the species */
    /* The values match that in our eSpecies enumeration */
    PyModule_AddIntConstant(m, "POSSUM", possum);
    PyModule_AddIntConstant(m, "POSSTRAP", posstrap);
    PyModule_AddIntConstant(m, "CHEWCARD", chewcard);
    PyModule_AddIntConstant(m, "FERRET", ferret);
    PyModule_AddIntConstant(m, "PIG", pig);
    PyModule_AddIntConstant(m, "REDDEER", reddeer);

    /* Allow app to ask for the version of this module */
    /* doesn't seem to be a PyModule_AddFloatConstant... */
    version = PyFloat_FromDouble( POF_VERSION );
    if( version != NULL )
        PyModule_AddObject(m, "VERSION", version); /* steals a reference */
}


