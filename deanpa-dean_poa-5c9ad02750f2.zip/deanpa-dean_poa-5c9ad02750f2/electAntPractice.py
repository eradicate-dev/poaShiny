#!/usr/bin/env python

########################################
########################################
# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

import os
import pickle

from proofofabsence import preProcessing
from proofofabsence import params
from proofofabsence import calculation

######################
# Main function
def main():
    ############################################################
    ###################################### USER MODIFY HERE ONLY
    #################################
    # set paths to scripts and data
#    inputDataPath = os.getenv('POFPROJDIR') + '/poa/EAPractice/EAPracticeData'
    inputDataPath = os.path.join(os.getenv('POFPROJDIR'), 'poa', 'EAPractice', 'EAPracticeData')

#    outputDataPath = os.getenv('POFPROJDIR') + '/poa/EAPractice/EAPracticeResults'
    outputDataPath = os.path.join(os.getenv('POFPROJDIR'), 'poa', 'EAPractice', 'EAPracticeResults')
    if not os.path.isdir(outputDataPath):
        os.mkdir(outputDataPath)

    # set INPUT extent and relative risk file names
    extentShapeFName = os.path.join(inputDataPath, 'EAModelExtent.shp')
    relativeRiskFName = os.path.join(inputDataPath, 'revisedRRMap.tif')
    gridSurvey = os.path.join(inputDataPath, 'practiceGrids.csv')
    # set OUTPUT names for mask and relative risk map
    extentMaskOutFName = os.path.join(outputDataPath, 'extentMask.tif')
    relRiskRasterOutFName = os.path.join(outputDataPath, 'relRiskRaster.tif')

    ############ IF FIRST RUN CONDITION
    # if True, do preprocessing, else skip to calculations
    firstRun = False

    # resolution for analysis
    Resolution = 10.0
    # EPSG - PROJECTION SYSTEM
    epsg = 28355    # GDA_1994_MGA_Zone_55
    # Surveillance data Name
#    surveyFName = os.path.join(inputDataPath, 'surveyData.csv')
    # Instance of POAParameters class
    myParams = params.POAParameters()
    # number of cpu's from SLURM
    ncpus = int(os.getenv('SLURM_CPUS_PER_TASK', '1'))
    myParams.setNumThreads(ncpus)
    # number of iterations
    myParams.setNumIterations(20)
#    myParams.setNumChewcardTraps(3)
#    myParams.setKTrapDistance(100.0)
    myParams.setYears([2017, 2018, 2019, 2020])
    # starting Pu and period rate of Pu increase
    startPu = 1.0
    PuIncreaseRate = 4.0
    myParams.setPu(startPu, PuIncreaseRate)

    #minimum RR value
    myParams.setMinK(1.0)

    myParams.setPrior(0.499999, 0.5, 0.500001)
    myParams.setIntro(0.009999, 0.01, 0.010001)
#    myParams.setSigma(params.POSSUM, 90.0, 0.000001)
#    myParams.setSigma(params.POSSTRAP, 90.0, 0.000001)
#    myParams.setSigma(params.CHEWCARD, 90.0, 0.000001)
#    myParams.setSigma(params.FERRET, 287.0, 0.000001)
#    myParams.setSigma(params.PIG, 910.0, 0.000001)
#    myParams.setSigma(params.REDDEER, 2500.0, 1.0)

#    myParams.setChewcard(params.CHEWCARD, 0.2, 0.000001)
#    myParams.setCapture(params.POSSUM, 0.13, 0.000001)
#    myParams.setCapture(params.POSSTRAP, 0.13, 0.000001)
#    myParams.setCapture(params.CHEWCARD, 0.13, 0.000001)

#    myParams.setTest(params.POSSUM, 0.95, 0.00001)
#    myParams.setTest(params.POSSTRAP, 0.95, 0.000001)
#    myParams.setTest(params.CHEWCARD, 0.95, 0.00001)
#    myParams.setTest(params.FERRET, 0.95, 0.00001)
#    myParams.setTest(params.PIG, 0.95, 0.000001)
#    myParams.setTest(params.REDDEER, 0.95, 0.00001)

#    myParams.setInfect(params.POSSUM, 1.0, 0.1)
#    myParams.setInfect(params.POSSTRAP, 1.0, 0.1)
#    myParams.setInfect(params.CHEWCARD, 1.0, 0.1)
#    myParams.setInfect(params.FERRET, 0.187, 0.01)
#    myParams.setInfect(params.PIG, 0.472, 0.000001)
#    myParams.setInfect(params.REDDEER, 0.009, 0.01)

    #####################################   END USER MODIFICATION
    #############################################################
    #############################################################

    print('firstRun = ', firstRun)

    if firstRun:
        # initiate instances of Classes
        rawdata = preProcessing.RawData(extentShapeFName, relativeRiskFName, 
                extentMaskOutFName, relRiskRasterOutFName, Resolution, epsg, 
                None, myParams, gridSurvey)

        print('finish preProcessing')

        myParams.setGridSurvey(rawdata.gridSurveyYears, rawdata.gridSurveyData,
            rawdata.gridSurveyMeans, rawdata.gridSurveySD, rawdata.gridSurveyCodes)



        # make object for pickling spatial data
        pickledat = preProcessing.PickleDat(rawdata)
        # pickle to output directory
        pickleName = os.path.join(outputDataPath, 'spatialData.pkl')
        fileobj = open(pickleName, 'wb')
        pickle.dump(pickledat, fileobj, protocol=4)
        fileobj.close()

    # If preProcessing has already been run (not first run)
    else:
        # unpickle results from preProcessing.py
        PKLFName = os.path.join(outputDataPath, 'spatialData.pkl')
        # unpickle preprocessing
        fileobj = open(PKLFName, 'rb')
        pickledat = pickle.load(fileobj)
        fileobj.close()

        myParams.setGridSurvey(pickledat.gridSurveyYears, pickledat.gridSurveyData,
            pickledat.gridSurveyMeans, pickledat.gridSurveySD, pickledat.gridSurveyCodes)

    
    result = calculation.calcProofOfAbsence(myParams, pickledat.survey, 
                pickledat.extMask, pickledat.relativeRiskRaster, 
                pickledat.match_geotrans, pickledat.wkt, outputDataPath)

    ################################################
    ####################
    # temp for debugging    
#    result.modifiedK = None
#    result.sensitivitiesPerYear = None
#    result.updatedMask = None
    ###################
    ################################################

    ## PRINT INTERMEDIATE RESULTS
#    print(result.intermediateResults)
    pickleName = os.path.join(outputDataPath, 'resultData.pkl')
    fileobj = open(pickleName, 'wb')
    pickle.dump(result, fileobj)
#    pickle.dump(result, fileobj, protocol=4)
    fileobj.close()
 
if __name__ == '__main__':
    main()


