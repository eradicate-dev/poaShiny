#!/usr/bin/env python

import os
from proofofabsence import postProcessing

######################
# Main function
def main():
    # datapath
    inOutDataPath = os.path.join(os.getenv('POFPROJDIR'), 'poa', 'EAScenario1')

    inputResultsPath = os.path.join(inOutDataPath, 'EA_ResultsScen2')

    ## Specify the label on y-axis of the probability of 'absence/below thres' plot
    probabilityName = 'Probability of absence'

    preProcessingResults = 'spatialData.pkl'
    calculationResults = 'resultData.pkl'
    extentLineFname = 'extentShape.shp'

    SSePoFResultTableName = 'PofSseResultTable.txt'
    pofSSeGraphName = 'PoF_SSe_Graph.png'
        
    results = postProcessing.ResultsProcessing(inputResultsPath, inputResultsPath, 
                preProcessingResults, calculationResults, extentLineFname,
                SSePoFResultTableName, pofSSeGraphName)

    # make results table and plot to screen
    results.makeTableFX()
    # write result table to directory
    results.writeToFileFX(SSePoFResultTableName)
    # plot pof and sse over time and write to directory
    results.plotFX(pofSSeGraphName, probabilityName)

    ##### OPTIONAL FUNCTIONS
    # get axis labels for 2-D plots (below)
#    results.getEastingsNorthings()
    # plot 2-d images of the yearly mean seu
#    results.plotMeanSeUTuiview()
    # plot updated relative risk map
#    OLD FX    self.plotRelRisk()
#    results.plotRelRiskTuiview()
    ##########################
    
if __name__ == '__main__':
    main()
                    