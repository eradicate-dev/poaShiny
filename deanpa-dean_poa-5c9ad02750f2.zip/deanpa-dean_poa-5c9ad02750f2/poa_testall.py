#!/usr/bin/env python

"""
Testing harness for Proof Of Absence. Runs a
scenario with very low standard deviation and checks
the results against a stored version.

Also runs a high standard deviation version and 
checks that the mean and standard deviation of PoF
and SSe match expected values.
"""

# This file is part of Proof of Absence
# Copyright (C) 2016 Dean Anderson and Sam Gillingham
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
########################################
########################################

from __future__ import print_function, division
import os
import pickle
import numpy as np
from osgeo import gdal

from proofofabsence import preProcessing
from proofofabsence import params
from proofofabsence import calculation

######################
# Main function
def main():
    testLowSD()
    testStochastic()
    print('Tests completed ok')

def testLowSD():
    """
    Test with low standard deviation and compare
    with known results.
    """
    print('testing with low standard deviation...')

    # set paths to scripts and data
    inputDataPath = 'validation/valid_data' # 'testdata' 
    outputDataPath = 'validation/valid_results_means'   # 'results1' # 
    if not os.path.isdir(outputDataPath):
        os.mkdir(outputDataPath)

    # set INPUT extent and relative risk file names
    extentShapeFName = os.path.join(inputDataPath, 'extentShape.shp')
    relativeRiskFName = os.path.join(inputDataPath, 'testRelRisk.asc')
    # set OUTPUT names for mask and relative risk map
    extentMaskOutFName = os.path.join(outputDataPath, 'extentMask.tif')
    relRiskRasterOutFName = os.path.join(outputDataPath, 'relRiskRaster.tif')
    # resolution for analysis
    Resolution = 100.0
    # EPSG - PROJECTION SYSTEM
    epsg = 2193 # NZTM
    # Surveillance data Name
    surveyFName = os.path.join(inputDataPath, 'surveyData.csv')
    # Instance of POAParameters class
    myParams = params.POAParameters()
    myParams.setNumIterations(5)
    myParams.setNumChewcardTraps(3)
    myParams.setKTrapDistance(100.0)
    myParams.setYears([2007, 2008, 2009, 2010, 2011])
    myParams.setPu(2.0)
    myParams.setMinK(5.0)

    myParams.setPrior(0.499999, 0.5, 0.500001)
    myParams.setIntro(0.009999, 0.01, 0.010001)
    myParams.setSigma(params.TYPE_POSSUM, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_POSSTRAP, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_CHEWCARD, 90.0, 0.000001)
    myParams.setSigma(params.TYPE_FERRET, 287.0, 0.000001)
    myParams.setSigma(params.TYPE_PIG, 910.0, 0.000001)
    myParams.setSigma(params.TYPE_REDDEER, 2500.0, 1.0)

    myParams.setChewcard(params.TYPE_CHEWCARD, 0.2, 0.000001)
    myParams.setCapture(params.TYPE_POSSUM, 0.13, 0.000001)
    myParams.setCapture(params.TYPE_POSSTRAP, 0.13, 0.000001)
    myParams.setCapture(params.TYPE_CHEWCARD, 0.13, 0.000001)

    myParams.setTest(params.TYPE_POSSUM, 0.95, 0.00001)
    myParams.setTest(params.TYPE_POSSTRAP, 0.95, 0.000001)
    myParams.setTest(params.TYPE_CHEWCARD, 0.95, 0.00001)
    myParams.setTest(params.TYPE_FERRET, 0.95, 0.00001)
    myParams.setTest(params.TYPE_PIG, 0.95, 0.000001)
    myParams.setTest(params.TYPE_REDDEER, 0.95, 0.00001)

    myParams.setInfect(params.TYPE_POSSUM, 1.0, 0.1)
    myParams.setInfect(params.TYPE_POSSTRAP, 1.0, 0.1)
    myParams.setInfect(params.TYPE_CHEWCARD, 1.0, 0.1)
    myParams.setInfect(params.TYPE_FERRET, 0.187, 0.01)
    myParams.setInfect(params.TYPE_PIG, 0.472, 0.000001)
    myParams.setInfect(params.TYPE_REDDEER, 0.009, 0.01)

    # initiate instances of Classes
    rawdata = preProcessing.RawData(extentShapeFName, relativeRiskFName, 
            extentMaskOutFName, relRiskRasterOutFName, Resolution, epsg, 
            surveyFName, myParams)

    # make object for pickling spatial data
    pickledat = preProcessing.PickleDat(rawdata)

    result = calculation.calcProofOfAbsence(myParams, pickledat.survey, 
                pickledat.extMask, pickledat.relativeRiskRaster, 
                pickledat.match_geotrans, pickledat.wkt, outputDataPath)

    pickleName = os.path.join(outputDataPath, 
            'resultData.pkl')
    fileobj = open(pickleName, "wb")
    pickle.dump(result, fileobj)
    fileobj.close()

    # read in the 'ideal' pickle
    pickleName = os.path.join(outputDataPath, 
            'resultData_ideal.pkl')
    fileobj = open(pickleName, 'rb')
    idealResult = pickle.load(fileobj)
    fileobj.close()

    # compare them
    for arrayName, tol in (('sensitivityMatrix', 8e-07) , ('poFMatrix', 1.5e-05), 
            ('proportionSearched', 0)):
        oldArray = getattr(idealResult, arrayName)
        newArray = getattr(result, arrayName)

        diff = np.absolute(oldArray - newArray).sum()
        if diff > tol:
            msg = 'Difference (%.10f) is greater than tolerance (%.10f) for result %s'
            msg = msg % (diff, tol, arrayName)
            raise SystemExit(msg)

    # special handling for intermediateResults
    for field, tol in (('sumAR', 0), ('averageSeu', 5e-06), ('searchedCells', 0), 
            ('totalCells', 0)):
        diff = np.absolute(idealResult.intermediateResults[field] -
                    result.intermediateResults[field]).sum()
        if diff > tol:
            msg = ('For intermediateResults, the difference (%.10f) is greater ' +
                    'than tolerance (%.10f) for field %s') % (diff, tol, field)
            raise SystemExit(msg)

    # now compare rasters
    for name, maxDiff in [('meanSeuAllYears', 0.025), ('updatedExtentMask', 0), 
                ('updatedRelRisk', 0)]:
        inFilename = os.path.join(outputDataPath, name + '.tif')
        idealFilename = os.path.join(outputDataPath, 
                name + '_ideal.tif')
                
        diffList = getImageDifferences(inFilename, idealFilename)
        layer = 0
        for diff in diffList:
            if diff > maxDiff:
                msg = ('for %s the difference (%.10f) is greater ' +
                    'than tolerance (%.10f) for year %s') % (name, diff, 
                        maxDiff, layer)
                raise SystemExit(msg)
            layer += 1

def testStochastic():
    """
    Run with high standard deviation and check outputs
    have expected range. 
    """
    print('Testing range of results with high standard deviation...')
    # set paths to scripts and data
    inputDataPath = 'validation/valid_data'
    outputDataPath = 'validation/valid_results_stochastic'
    if not os.path.isdir(outputDataPath):
        os.mkdir(outputDataPath)

    # set INPUT extent and relative risk file names
    extentShapeFName = os.path.join(inputDataPath, 'extentShape.shp')
    relativeRiskFName = os.path.join(inputDataPath, 'testRelRisk.asc')
    # set OUTPUT names for mask and relative risk map
    extentMaskOutFName = os.path.join(outputDataPath, 'extentMask.tif')
    relRiskRasterOutFName = os.path.join(outputDataPath, 'relRiskRaster.tif')
    # resolution for analysis
    Resolution = 100.0
    # EPSG - PROJECTION SYSTEM
    epsg = 2193 # NZTM
    # Surveillance data Name
    surveyFName = os.path.join(inputDataPath, 'surveyData.csv')

    myParams = params.POAParameters()
    myParams.setNumIterations(200)
    myParams.setNumChewcardTraps(3)
    myParams.setYears([2007, 2008, 2009, 2010, 2011])
    myParams.setPu(2.0)
    myParams.setMinK(5)
    myParams.setKTrapDistance(100.0)
    myParams.setPrior(0.2, 0.5, 0.8)
    myParams.setIntro(0.0001, 0.01, 0.02)
    myParams.setSigma(params.TYPE_POSSUM, 90.0, 8.0)
    myParams.setSigma(params.TYPE_POSSTRAP, 90.0, 8.0)
    myParams.setSigma(params.TYPE_CHEWCARD, 90.0, 8.0)
    myParams.setSigma(params.TYPE_FERRET, 287.0, 10.0)
    myParams.setSigma(params.TYPE_PIG, 910.0, 25.0)
    myParams.setSigma(params.TYPE_REDDEER, 2500.0, 15.0)

    myParams.setChewcard(params.TYPE_CHEWCARD, 0.2, 0.05)

    myParams.setCapture(params.TYPE_POSSUM, 0.13, 0.05)
    myParams.setCapture(params.TYPE_POSSTRAP, 0.13, 0.05)
    myParams.setCapture(params.TYPE_CHEWCARD, 0.13, 0.05)

    myParams.setTest(params.TYPE_POSSUM, 0.95, 0.1)
    myParams.setTest(params.TYPE_POSSTRAP, 0.95, 0.1)
    myParams.setTest(params.TYPE_CHEWCARD, 0.95, 0.1)
    myParams.setTest(params.TYPE_FERRET, 0.95, 0.1)
    myParams.setTest(params.TYPE_PIG, 0.95, 0.1)
    myParams.setTest(params.TYPE_REDDEER, 0.95, 0.1)

    myParams.setInfect(params.TYPE_POSSUM, 1.0, 0.1)
    myParams.setInfect(params.TYPE_POSSTRAP, 1.0, 0.1)
    myParams.setInfect(params.TYPE_CHEWCARD, 1.0, 0.1)
    myParams.setInfect(params.TYPE_FERRET, 0.187, 0.05)
    myParams.setInfect(params.TYPE_PIG, 0.472, 0.1)
    myParams.setInfect(params.TYPE_REDDEER, 0.009, 0.002)

    # initiate instances of Classes
    rawdata = preProcessing.RawData(extentShapeFName, relativeRiskFName, 
            extentMaskOutFName, relRiskRasterOutFName, Resolution, epsg, 
            surveyFName, myParams)

    # make object for pickling spatial data
    pickledat = preProcessing.PickleDat(rawdata)

    result = calculation.calcProofOfAbsence(myParams, pickledat.survey, 
                pickledat.extMask, pickledat.relativeRiskRaster, 
                pickledat.match_geotrans, pickledat.wkt, outputDataPath)

    # check spread of results
    sensitivityIdealSD = np.array([1.27601090e-04, 7.65490529e-05, 1.79597648e-03,
         1.87735682e-03, 1.33410320e-03])
    PoFIdealSD = np.array([0.10668255, 0.10546779, 0.10281594, 0.03049535, 
         0.00592535])

    for arrayName, idealSD, tol in (('sensitivityMatrix', sensitivityIdealSD, 0.0006), 
                ('poFMatrix', PoFIdealSD, 0.05)):
        data = getattr(result, arrayName)
        sdData = data.std(axis=1)
        diff = np.absolute(sdData - idealSD).sum()
        if diff > tol:
            msg = ('Difference from the expected standard devation (%.10f) ' + 
                'is greater than the tolerance (%.10f) for %s') % (diff, tol, arrayName)
            raise SystemExit(msg)

def getImageDifferences(file1, file2):
    """
    For comparing images. Returns a list of differences for each layer
    """
    diffs = []
    file1ds = gdal.Open(file1)
    file2ds = gdal.Open(file2)
    if file1ds.RasterCount != file2ds.RasterCount:
        msg = '%s and %s have different number of layers' % (file1, file2)
        raise SystemExit(msg)
        
    for count in range(file1ds.RasterCount):
        file1data = file1ds.GetRasterBand(count+1).ReadAsArray()
        file2data = file2ds.GetRasterBand(count+1).ReadAsArray()
        diff = np.absolute(file1data - file2data).sum()
        diffs.append(diff)
        
    del file1ds
    del file2ds
    return diffs

if __name__ == '__main__':
    main()


